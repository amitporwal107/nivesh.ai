import type { Recommendation } from "@/types/recommendation";

export const mockRecommendations: Recommendation[] = [
  {
    id: "rec-switch-axis-bluechip",
    action: "reduce",
    title: "Sell Axis Bluechip · 71% overlaps with ICICI Pru Bluechip",
    why:
      "You hold three large-cap funds with nearly identical top stocks. You're paying 3× the expense ratio for the same exposure.",
    benefit: "Saves ₹14,200 / year in hidden fund fees.",
    riskImpact: "None — you keep the same companies through ICICI Pru.",
    suggestedAction: "Switch ₹1.2L to ICICI Pru Bluechip",
    estAnnualGain: 14_200_00,
    estHealthDelta: 8,
    affectedFundIds: ["axis-bluechip", "icici-pru-bluechip"],
  },
  {
    id: "rec-emergency-topup",
    action: "add",
    title: "Top up your emergency fund · ₹4.6L to reach 6 months",
    why:
      "You hold 1.4 months of expenses in safe cash. Six months is the usual target before investing further.",
    benefit: "Peace of mind in a job loss; earns 6.8% in a liquid fund.",
    riskImpact: "Lower overall risk.",
    suggestedAction: "Buy Quant Liquid · ₹4.6L (SIP if needed)",
    estHealthDelta: 4,
    affectedFundIds: ["quant-liquid"],
  },
  {
    id: "rec-trim-hdfcbank",
    action: "reduce",
    title: "Trim HDFC Bank from 8.0% to 5.0% of portfolio",
    why: "One stock is 8% of your money. The safer maximum for a single name is 5%.",
    benefit: "Lower risk · ₹3,500 / year safer in a bad bank year.",
    riskImpact: "Slightly less upside if HDFC outperforms.",
    suggestedAction: "Sell ₹74,000 of HDFC Bank",
    estAnnualGain: 3_500_00,
    estHealthDelta: 3,
    affectedFundIds: [],
  },
  {
    id: "rec-keep-ppfas",
    action: "keep",
    title: "Keep Parag Parikh Flexi Cap · top quartile, low overlap",
    why:
      "Outperformed category by 3.4% over 3 years. Holds 30% international stocks — a useful diversifier.",
    benefit: "Continues to anchor the portfolio.",
    riskImpact: "Unchanged — moderate.",
    suggestedAction: "No change",
    affectedFundIds: ["ppfas-flexi"],
  },
  {
    id: "rec-add-gold",
    action: "add",
    title: "Add a gold ETF · ₹70,000 to reach 8% allocation",
    why:
      "Gold is currently 6% of your portfolio. A small extra slice softens equity falls and hedges currency.",
    benefit: "Lower swings; ₹1.4L less loss in a 2008-style year.",
    riskImpact: "Lower.",
    suggestedAction: "Buy Nippon Gold ETF · ₹70,000",
    estHealthDelta: 2,
    affectedFundIds: ["nippon-gold-etf"],
  },
];
