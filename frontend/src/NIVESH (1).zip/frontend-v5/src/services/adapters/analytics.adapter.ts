/**
 * Analytics adapter — concentration, intelligence, fund performance.
 *
 *   GET /api/portfolio/exposure/concentration
 *   GET /api/intelligence/portfolio?narrate=
 *   GET /api/portfolio/fund-performance
 *   GET /api/portfolio/deep-analytics
 *
 * For diversification (correlation matrix) and risk (VaR/drawdown), backend
 * doesn't yet expose dedicated endpoints — those still resolve from mocks
 * until the v4 dashboard composites or a dedicated analytics service ship.
 */
import { http } from "@/services/api/http";
import { ApiError } from "@/services/api/errors";
import { ConcentrationBreakdownC } from "@/services/contracts/portfolio.contract";
import type { ConcentrationSnapshot, SectorAllocation } from "@/types/concentration";

export interface AnalyticsAdapter {
  concentration(): Promise<ConcentrationSnapshot>;
}

export const realAnalyticsAdapter: AnalyticsAdapter = {
  async concentration() {
    const res = await http({ path: "/api/portfolio/exposure/concentration" });
    const parsed = ConcentrationBreakdownC.safeParse(res.data);
    if (!parsed.success) throw ApiError.contractDrift(`analytics.concentration: ${parsed.error.message}`);
    return mapConcentration(parsed.data);
  },
};

/**
 * Backend `sector` payload is an opaque object — we expect a `breakdown`
 * array of `{ name, pct, cap_pct }`. If shape differs we render with empty
 * sectors[] rather than throw (req #14 — partial-data rendering).
 */
function mapConcentration(body: import("@/services/contracts/portfolio.contract").ConcentrationBreakdownC): ConcentrationSnapshot {
  const sector = (body.sector ?? {}) as { breakdown?: unknown; top_stock?: { name?: string; pct?: number }; herfindahl?: number; sectors_over_cap?: number };
  const breakdown = Array.isArray(sector.breakdown) ? sector.breakdown as Array<{ name: string; pct: number; cap_pct?: number }> : [];

  const sectors: SectorAllocation[] = breakdown.map((s) => ({
    name: s.name,
    pct: s.pct,
    capPct: s.cap_pct ?? 25,
    isOverCap: (s.pct ?? 0) > (s.cap_pct ?? 25),
  }));

  return {
    asOf: new Date().toISOString().slice(0, 10),
    topStockPct: sector.top_stock?.pct ?? 0,
    topStockName: sector.top_stock?.name ?? "",
    sectorOverCount: sector.sectors_over_cap ?? sectors.filter((s) => s.isOverCap).length,
    sectors,
    herfindahl: sector.herfindahl ?? 0,
  };
}
