/**
 * Mock insights adapter.
 */
import type { InsightsAdapter } from "../adapters/insights.adapter";
import { mockPortfolio } from "@/mock-data/portfolio";

const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export const mockInsightsAdapter: InsightsAdapter = {
  async v3Portfolio() { await delay(200); return { score: mockPortfolio.healthScore, grade: "B+", etag: 'sha1:"mock-1"' }; },
  async list() { await delay(220); return structuredClone(mockPortfolio.topInsights); },
  async generate() { await delay(380); return { ok: true }; },
};
