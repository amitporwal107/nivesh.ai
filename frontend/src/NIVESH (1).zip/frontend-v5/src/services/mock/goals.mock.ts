/**
 * Mock goals adapter.
 */
import type { GoalsAdapter } from "../adapters/goals.adapter";
import { mockGoals } from "@/mock-data/goals";

const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export const mockGoalsAdapter: GoalsAdapter = {
  async list() { await delay(280); return structuredClone(mockGoals); },
  async create() { await delay(380); return structuredClone(mockGoals[0]); },
  async getSnapshot() { await delay(180); return {}; },
  async upsertSnapshot(body) { await delay(220); return body; },
  async simulate() { await delay(420); return { on_track_pct: 0.62 }; },
  async whatIf() { await delay(220); return { on_track_pct: 0.78 }; },
};
