/**
 * Mock analytics adapter — concentration only (correlation/risk stay in legacy hooks).
 */
import type { AnalyticsAdapter } from "../adapters/analytics.adapter";
import { mockConcentration } from "@/mock-data/concentration";

const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export const mockAnalyticsAdapter: AnalyticsAdapter = {
  async concentration() { await delay(260); return structuredClone(mockConcentration); },
};
