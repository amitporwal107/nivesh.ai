/**
 * Mock plans adapter.
 */
import type { PlansAdapter } from "../adapters/plans.adapter";
import { mockRecommendations } from "@/mock-data/recommendations";

const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

const stubPlan = {
  plan_id: "plan-mock-1",
  version: "v1",
  status: "active" as const,
  actions: [],
  created_at: new Date().toISOString(),
};

export const mockPlansAdapter: PlansAdapter = {
  async getActive() {
    await delay(280);
    return { plan: stubPlan, hasPlan: true };
  },
  async generate() {
    await delay(420);
    return stubPlan;
  },
  async refresh() {
    await delay(360);
    return stubPlan;
  },
  async getRecommendations(sourceDomain) {
    await delay(260);
    const all = structuredClone(mockRecommendations);
    if (!sourceDomain) return all;
    // mock list isn't tagged by domain — filter by action label heuristic
    return all;
  },
  async updateActionStatus() {
    await delay(180);
    return stubPlan;
  },
};
