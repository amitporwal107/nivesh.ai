/**
 * Mock portfolio adapter — wraps existing mock-data with a small delay.
 * Matches `realPortfolioAdapter` signature exactly.
 */
import type { PortfolioAdapter } from "../adapters/portfolio.adapter";
import { mockPortfolio, mockNavHistory } from "@/mock-data/portfolio";
import { mockHoldings } from "@/mock-data/holdings";

const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export const mockPortfolioAdapter: PortfolioAdapter = {
  async listHoldings() {
    await delay(280);
    return structuredClone(mockHoldings);
  },
  async getSummary() {
    await delay(320);
    return structuredClone(mockPortfolio);
  },
  async getNavHistory() {
    await delay(220);
    return structuredClone(mockNavHistory);
  },
};
