/**
 * Mock adapters for scenarios + intelligence.
 */
import type { ScenariosAdapter } from "../adapters/scenarios.adapter";
import type { IntelligenceAdapter } from "../adapters/intelligence.adapter";

const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export const mockScenariosAdapter: ScenariosAdapter = {
  async suggest() {
    await delay(220);
    return [
      { scenario_id: "s_trim_financials", name: "Trim financials to 24%", description: "Lower bank-stock concentration" },
      { scenario_id: "s_switch_direct",   name: "Switch to direct plans",  description: "Save ~₹14k/yr in fund fees" },
      { scenario_id: "s_balance_midcap",  name: "Rebalance mid-cap tilt",  description: "Bring mid+small below 25%" },
    ];
  },
  async simulate() {
    await delay(420);
    return { health_score_delta: 5, expected_return_pp: 0.4, risk_delta_pp: -0.6 };
  },
  async rebalancePlan() {
    await delay(420);
    return { actions: [], summary: "3 trades, ₹1.2L moved, net positive ₹2.1k/yr" };
  },
  async save() { await delay(220); return { saved_id: "scn_mock_1" }; },
  async listSaved() { await delay(180); return []; },
  async deleteSaved() { await delay(120); },
  async apply() { await delay(380); return { plan_id: "plan_mock_applied" }; },
  async listPending() { await delay(180); return []; },
  async completePending() { await delay(220); },
  async deletePending() { await delay(120); },
};

export const mockIntelligenceAdapter: IntelligenceAdapter = {
  async portfolio() {
    await delay(280);
    return {
      look_through: { sectors: [], top_stocks: [] },
      stock_overlap: { hot_pairs: [] },
      narrative: "Your portfolio is moderately concentrated with one redundant fund pair.",
    };
  },
  async simulate() { await delay(380); return { score: 82, change_pp: 8 }; },
  async v3Score() { await delay(220); return { score: 76, primitives: {} }; },
};
