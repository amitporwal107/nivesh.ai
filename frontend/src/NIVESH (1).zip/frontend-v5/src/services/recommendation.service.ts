import { mockGet } from "./api";
import { mockRecommendations } from "@/mock-data/recommendations";
import type { Recommendation, RecAction } from "@/types/recommendation";

/**
 * API contract — Recommendations
 *
 *   GET   /api/v1/recommendations?action=keep|reduce|add  → Recommendation[]
 *   POST  /api/v1/recommendations/:id/apply               → { appliedAt: ISO }
 *   POST  /api/v1/recommendations/:id/dismiss             → { dismissedAt: ISO }
 */
export const recommendationService = {
  async list(action?: RecAction): Promise<Recommendation[]> {
    const all = await mockGet("recs.list", mockRecommendations);
    return action ? all.filter((r) => r.action === action) : all;
  },
  async apply(id: string): Promise<{ appliedAt: string }> {
    return mockGet("recs.apply", { appliedAt: new Date().toISOString() });
  },
};
