/**
 * CAS Ingestion service — high-level orchestration that mirrors the V4
 * frontend's `runCasIngestion(mode, { onStatus })` API.
 *
 * Loads the @cas-parser/connect widget lazily, mints a token, runs the user
 * flow, and ships the widget output to /api/cas/sdk-callback. Returns a
 * uniform result shape regardless of mode:
 *
 *   { ok: true,  response, mode }
 *   { ok: false, error: ApiError | Error }
 *   { cancelled: true }                          ← user closed widget
 *
 * Loading is dynamic so the widget bundle doesn't bloat the main chunk.
 */
import { casUploadService } from "@/services";
import { ApiError } from "@/services/api/errors";
import type { CasMode } from "@/services/adapters/cas-upload.adapter";

export interface IngestionResult {
  ok?: boolean;
  cancelled?: boolean;
  response?: unknown;
  error?: ApiError | Error;
  mode?: CasMode;
}

export interface IngestionOptions {
  mode: CasMode;
  portfolioId?: string;
  onStatus?: (message: string) => void;
}

interface CasParserConnectModule {
  default?: CasConnectFactory;
  CasConnect?: CasConnectFactory;
}

interface CasConnectFactory {
  (config: {
    token: string;
    mode: CasMode;
    onSuccess: (payload: unknown) => void;
    onError: (err: { message?: string } | unknown) => void;
    onClose?: () => void;
  }): { open: () => void; close: () => void };
}

let widgetModulePromise: Promise<CasConnectFactory> | null = null;

async function loadWidget(): Promise<CasConnectFactory> {
  if (widgetModulePromise) return widgetModulePromise;
  widgetModulePromise = (async () => {
    // Dynamic import keeps the @cas-parser/connect bundle out of the main chunk.
    // The package is expected to be present (declared in package.json), but if
    // unresolved at runtime we surface a clear error.
    try {
      const mod = (await import("@cas-parser/connect")) as CasParserConnectModule;
      const factory = mod.default ?? mod.CasConnect;
      if (!factory) throw new Error("CasConnect factory not found in @cas-parser/connect");
      return factory;
    } catch (err) {
      widgetModulePromise = null;
      throw err;
    }
  })();
  return widgetModulePromise;
}

/**
 * Drive a complete CAS ingestion for the chosen mode.
 *
 * Steps:
 *   1. Mint a widget access token
 *   2. Load the @cas-parser/connect SDK (lazy)
 *   3. Open the widget; the user does the rest (file pick / Gmail OAuth / CDSL OTP)
 *   4. On widget success, POST the parsed payload to /api/cas/sdk-callback
 *   5. Resolve with a uniform `{ ok | cancelled | error }` envelope
 */
export async function runCasIngestion(opts: IngestionOptions): Promise<IngestionResult> {
  const { mode, portfolioId, onStatus } = opts;
  try {
    onStatus?.("Authorising secure session…");
    const { access_token } = await casUploadService.getConnectToken();
    if (!access_token) throw new Error("Could not mint a CAS Connect token");

    onStatus?.("Opening secure widget…");
    const factory = await loadWidget();

    return await new Promise<IngestionResult>((resolve) => {
      let settled = false;
      const widget = factory({
        token: access_token,
        mode,
        onSuccess: async (payload) => {
          if (settled) return;
          settled = true;
          try {
            onStatus?.("Saving your portfolio…");
            const response = await casUploadService.sdkCallback({
              mode,
              payload,
              portfolio_id: portfolioId,
              idempotencyKey: cryptoRandomId(),
            });
            resolve({ ok: true, response, mode });
          } catch (err) {
            resolve({ ok: false, error: err instanceof Error ? err : new Error(String(err)) });
          }
        },
        onError: (err) => {
          if (settled) return;
          settled = true;
          const msg = (err && typeof err === "object" && "message" in err) ? String((err as { message?: string }).message) : "CAS Connect widget error";
          resolve({ ok: false, error: new Error(msg) });
        },
        onClose: () => {
          if (settled) return;
          settled = true;
          resolve({ cancelled: true });
        },
      });
      widget.open();
    });
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err : new Error(String(err)) };
  }
}

function cryptoRandomId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return (crypto as Crypto & { randomUUID(): string }).randomUUID();
  }
  return Math.random().toString(36).slice(2);
}
