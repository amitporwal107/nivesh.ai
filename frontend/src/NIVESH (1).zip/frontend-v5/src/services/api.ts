/**
 * api.ts — mock API layer.
 *
 * Each endpoint resolves after an artificial network delay so React Query's
 * loading states actually exercise. Replace each function body with a real
 * `fetch()` call when the backend lands; the public signature stays the same.
 */

const NETWORK_LATENCY_MS = 320;
const JITTER_MS = 240;

/** % chance any given request fails — set higher to test error UI. */
let _failureRate = 0;

export function __setFailureRate(rate: number) {
  _failureRate = Math.max(0, Math.min(1, rate));
}

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = "ApiError";
  }
}

export async function mockGet<T>(name: string, payload: T): Promise<T> {
  const delay = NETWORK_LATENCY_MS + Math.random() * JITTER_MS;
  await new Promise((r) => setTimeout(r, delay));
  if (Math.random() < _failureRate) {
    throw new ApiError(503, `[${name}] simulated failure`);
  }
  // structuredClone so consumers can't mutate the mock store
  return structuredClone(payload);
}
