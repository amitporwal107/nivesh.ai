import { mockGet } from "./api";
import { ALLOWED_DOMAINS, type User } from "@/types/user";

/**
 * API contract — Auth
 *
 *   POST /api/v1/auth/google/start    → { url: string }   (OAuth start URL)
 *   POST /api/v1/auth/email/magic     → { sentTo: string } (whitelisted only)
 *   GET  /api/v1/auth/me              → User
 *   POST /api/v1/auth/logout
 */
export const authService = {
  isAllowedDomain(email: string): boolean {
    const domain = email.split("@")[1]?.toLowerCase();
    return !!domain && ALLOWED_DOMAINS.includes(domain);
  },

  async me(): Promise<User> {
    return mockGet("auth.me", {
      id: "u_1",
      email: "aarav.k@gmail.com",
      name: "Aarav Kumar",
      emailDomain: "gmail.com",
      isWhitelisted: true,
    });
  },

  async startGoogleOAuth(): Promise<{ url: string }> {
    return mockGet("auth.google.start", { url: "/oauth/google/callback?stub=1" });
  },

  async sendMagicLink(email: string): Promise<{ sentTo: string }> {
    if (!this.isAllowedDomain(email)) {
      throw new Error("Email domain not whitelisted");
    }
    return mockGet("auth.magic", { sentTo: email });
  },
};
