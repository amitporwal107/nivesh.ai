import { mockGet } from "./api";
import { mockConcentration } from "@/mock-data/concentration";
import { mockCorrelation, mockOverlap } from "@/mock-data/diversification";
import { mockRisk } from "@/mock-data/risk";
import type { ConcentrationSnapshot } from "@/types/concentration";
import type { CorrelationMatrix, FundOverlapPair } from "@/types/diversification";
import type { RiskSnapshot } from "@/types/risk";

/**
 * API contract — Analytics
 *
 *   GET /api/v1/analytics/concentration   → ConcentrationSnapshot
 *   GET /api/v1/analytics/correlation     → CorrelationMatrix
 *   GET /api/v1/analytics/overlap         → FundOverlapPair[]
 *   GET /api/v1/analytics/risk            → RiskSnapshot
 */
export const analyticsService = {
  async concentration(): Promise<ConcentrationSnapshot> {
    return mockGet("analytics.concentration", mockConcentration);
  },
  async correlation(): Promise<CorrelationMatrix> {
    return mockGet("analytics.correlation", mockCorrelation);
  },
  async overlap(): Promise<FundOverlapPair[]> {
    return mockGet("analytics.overlap", mockOverlap);
  },
  async risk(): Promise<RiskSnapshot> {
    return mockGet("analytics.risk", mockRisk);
  },
};
