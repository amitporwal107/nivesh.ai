import { mockGet } from "./api";
import { mockPortfolio, mockNavHistory } from "@/mock-data/portfolio";
import { mockHoldings } from "@/mock-data/holdings";
import type { PortfolioSummary, NavPoint } from "@/types/portfolio";
import type { Holding } from "@/types/fund";

/**
 * API contract — Portfolio service
 *
 *   GET  /api/v1/portfolio/summary              → PortfolioSummary
 *   GET  /api/v1/portfolio/nav-history?range=1y → NavPoint[]
 *   GET  /api/v1/portfolio/holdings             → Holding[]
 *
 * Auth: bearer JWT on Authorization header.
 * Errors: 401 (re-login), 403 (no entitlement), 5xx (retry).
 */
export const portfolioService = {
  async getSummary(): Promise<PortfolioSummary> {
    return mockGet("portfolio.summary", mockPortfolio);
  },
  async getNavHistory(_range: "1m" | "3m" | "6m" | "1y" | "all" = "1y"): Promise<NavPoint[]> {
    return mockGet("portfolio.navHistory", mockNavHistory);
  },
  async getHoldings(): Promise<Holding[]> {
    return mockGet("portfolio.holdings", mockHoldings);
  },
};
