import { Routes, Route, Navigate } from "react-router-dom";
import AppLayout from "./components/layout/AppLayout";
import DashboardPage from "./pages/Dashboard";
import PortfolioPage from "./pages/Portfolio";
import ConcentrationPage from "./pages/Concentration";
import DiversificationPage from "./pages/Diversification";
import RecommendationsPage from "./pages/Recommendations";
import RiskPage from "./pages/Risk";
import FundDetailsPage from "./pages/FundDetails";
import SettingsPage from "./pages/Settings";
import ChatPage from "./pages/Chat";
import LoginPage from "./pages/Login";
import OnboardingPage from "./pages/Onboarding";

export function AppRoutes() {
  return (
    <Routes>
      {/* outside the AppLayout — full-bleed auth */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/onboarding" element={<OnboardingPage />} />

      <Route element={<AppLayout />}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard"        element={<DashboardPage />} />
        <Route path="/portfolio"        element={<PortfolioPage />} />
        <Route path="/funds/:id"        element={<FundDetailsPage />} />
        <Route path="/concentration"    element={<ConcentrationPage />} />
        <Route path="/diversification"  element={<DiversificationPage />} />
        <Route path="/risk"             element={<RiskPage />} />
        <Route path="/recommendations"  element={<RecommendationsPage />} />
        <Route path="/chat"             element={<ChatPage />} />
        <Route path="/settings"         element={<SettingsPage />} />
      </Route>

      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
