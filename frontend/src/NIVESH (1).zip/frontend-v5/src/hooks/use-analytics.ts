/**
 * use-analytics — concentration via real adapter; correlation/risk stay
 * on the legacy mock-service path (no backend endpoints yet).
 */
import { useQuery } from "@tanstack/react-query";
import { analyticsService } from "@/services";
import { analyticsService as legacyAnalytics } from "@/services/analytics.service";

export function useConcentration() {
  return useQuery({
    queryKey: ["analytics", "concentration"],
    queryFn: () => analyticsService.concentration(),
  });
}

export function useCorrelation() {
  return useQuery({
    queryKey: ["analytics", "correlation"],
    queryFn: () => legacyAnalytics.correlation(),
  });
}

export function useOverlap() {
  return useQuery({
    queryKey: ["analytics", "overlap"],
    queryFn: () => legacyAnalytics.overlap(),
  });
}

export function useRisk() {
  return useQuery({
    queryKey: ["analytics", "risk"],
    queryFn: () => legacyAnalytics.risk(),
  });
}
