/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Persona } from './types';

export const PERSONAS_CONFIG = [
  { id: Persona.NEW_INVESTOR, icon: 'Users', description: 'Start your investment journey' },
  { id: Persona.RETAIL_INVESTOR, icon: 'TrendingUp', description: 'Optimize your wealth' },
  { id: Persona.TRADER, icon: 'Zap', description: 'High probability trade setups' },
  { id: Persona.MF_INVESTOR, icon: 'PieChart', description: 'Mutual fund focused growth' },
  { id: Persona.MFD, icon: 'Briefcase', description: 'Manage client portfolios' },
  { id: Persona.ADVISOR, icon: 'ShieldCheck', description: 'Holistic financial advice' },
  { id: Persona.PORTFOLIO_ANALYST, icon: 'Search', description: 'Deep portfolio attribution' },
  { id: Persona.PORTFOLIO_MANAGER, icon: 'Layers', description: 'Active fund management' },
  { id: Persona.RISK_ANALYST, icon: 'Activity', description: 'Institutional grade risk monitoring' },
  { id: Persona.MARKET_ANALYST, icon: 'Globe', description: 'Macro regime analysis' },
  { id: Persona.RESEARCH_ANALYST, icon: 'FlaskConical', description: 'Fundamental conviction' },
  { id: Persona.WEALTH_MANAGER, icon: 'Gem', description: 'Family office management' },
];

export const MOCK_MARKETS = [
  { symbol: 'Nifty 50', price: '22,456.80', change: '+124.50', changePercent: 0.56, isUp: true },
  { symbol: 'Sensex', price: '73,924.30', change: '+382.10', changePercent: 0.52, isUp: true },
  { symbol: 'Bank Nifty', price: '48,125.60', change: '-45.20', changePercent: -0.09, isUp: false },
  { symbol: 'Gold', price: '72,450.00', change: '+150.00', changePercent: 0.21, isUp: true },
];

export const COLORS = {
  primary: '#4F46E5', // Indigo 600
  success: '#16A34A', // Green 600
  warning: '#F59E0B', // Amber 500
  danger: '#DC2626', // Red 600
  info: '#2563EB',    // Blue 600
};

export const PERSONA_SUGGESTIONS: Record<Persona, string[]> = {
  [Persona.TRADER]: [
    "Analyze Nifty breakout probability",
    "Show HDFC Bank order flow dynamics",
    "Identify top 5 high-velocity setups",
    "Check VWAP deviation for high-caps"
  ],
  [Persona.ADVISOR]: [
    "Show clients with >10% portfolio drift",
    "Draft quarterly review for high-NWIs",
    "Analyze tax-loss harvesting for my book",
    "Summarize IT sector rotation risk"
  ],
  [Persona.WEALTH_MANAGER]: [
    "Which clients are eligible for new IPOs?",
    "Generate asset allocation health report",
    "Check goal feasibility for growth accounts",
    "Identify rebalance opportunities in Smallcaps"
  ],
  [Persona.RETAIL_INVESTOR]: [
    "Is my portfolio risk-aligned?",
    "How can I save ₹1.5L in taxes?",
    "Explain the dip in my Equity funds",
    "What's my estimated dividend for FY24?"
  ],
  [Persona.NEW_INVESTOR]: [
    "How do I start my first SIP?",
    "Explain difference between Direct & Regular funds",
    "Create a low-risk starter portfolio",
    "How to track my investment goals?"
  ],
  [Persona.MF_INVESTOR]: [
    "Compare top 5 Multicap funds",
    "Show overlap between my current MF holdings",
    "Identify funds with style drift in my portfolio",
    "Analyze expense ratio impact on long-term returns"
  ],
  [Persona.MFD]: [
    "Top performing funds in Midcap category",
    "Generate AUM growth report for this month",
    "Identify clients with pending KYC",
    "Compare expense ratios of top 5 AMC funds"
  ],
  [Persona.PORTFOLIO_ANALYST]: [
    "Run attribution analysis for our main fund",
    "Show factor exposure: Value vs Growth",
    "Compare alternatives for the underperforming Smallcap slice",
    "Export quarterly health report for PM review"
  ],
  [Persona.PORTFOLIO_MANAGER]: [
    "Backtest 20/40 momentum strategy",
    "Show attribution analysis for Alpha fund",
    "Calculate beta exposure of current universe",
    "Identify liquidity bottlenecks in Small-mid"
  ],
  [Persona.RISK_ANALYST]: [
    "Run Stress Test: 20% Market Crash",
    "Calculate Value-at-Risk (VaR) for Alpha book",
    "Show correlation matrix for top 10 holdings",
    "Identify tail risk exposure in derivatives"
  ],
  [Persona.MARKET_ANALYST]: [
    "Summarize RBI policy impact on yields",
    "Analyze FII/DII flow trends this week",
    "Identify sectors with positive earnings surprise",
    "Show long-term mean reversion for Sensex"
  ],
  [Persona.RESEARCH_ANALYST]: [
    "Screen for ROCE > 20% with rising momentum",
    "Analyze earnings revision trend for IT sector",
    "Show valuation percentile for top 50 stocks",
    "Compare peer fundamental metrics for Banks"
  ]
};

export interface PersonaTemplate {
  heroScore: { label: string; value: number };
  coreMetrics: { label: string; value: string }[];
  keySections: { title: string; items: string[] }[];
  actions: string[];
}

export const PERSONA_TEMPLATES: Record<Persona, PersonaTemplate> = {
  [Persona.NEW_INVESTOR]: {
    heroScore: { label: 'Investor Readiness Score', value: 72 },
    coreMetrics: [
      { label: 'Monthly Surplus', value: '₹45,000' },
      { label: 'Emergency Fund Adequacy', value: '4.2 Months' },
      { label: 'Goal Probability', value: '88%' }
    ],
    keySections: [
      { title: 'Beginner Plan', items: ['Focus on Index funds', 'Build 6-month buffer', 'Tax-saving ELSS'] },
      { title: 'SIP Allocation', items: ['Growth: 60%', 'Stability: 30%', 'Liquid: 10%'] },
      { title: '90-Day Action Plan', items: ['Automate SIPs', 'Critical Illness Cover', 'KYC Completion'] }
    ],
    actions: ['Start SIP', 'Set Goals', 'Build Emergency Fund', 'Beginner Guide']
  },
  [Persona.RETAIL_INVESTOR]: {
    heroScore: { label: 'Portfolio Health Score', value: 84 },
    coreMetrics: [
      { label: 'XIRR (LTM)', value: '18.4%' },
      { label: 'Drawdown', value: '-4.2%' },
      { label: 'Tax Impact', value: '₹12,400' }
    ],
    keySections: [
      { title: 'Asset Allocation', items: ['Equity: 72%', 'Debt: 20%', 'Gold: 8%'] },
      { title: 'Sector Concentration', items: ['Financials: High', 'Tech: Neutral', 'Auto: Overweight'] },
      { title: 'Fund Overlap', items: ['22% overlap in Largecap segment'] }
    ],
    actions: ['Simulate Rebalance', 'Optimize Tax', 'Generate Report']
  },
  [Persona.TRADER]: {
    heroScore: { label: 'Signal Strength Score', value: 91 },
    coreMetrics: [
      { label: 'Entry Range', value: '23,450 - 23,500' },
      { label: 'Stop Loss', value: '23,320' },
      { label: 'Risk-Reward', value: '1:2.4' }
    ],
    keySections: [
      { title: 'Technical Setup', items: ['Bullish Crossover 20/50 EMA', 'RSI Divergence on 15m', 'Volume Breakout'] },
      { title: 'Options Sentiment', items: ['PCR: 1.15', 'High Call Unwinding at 23500'] },
      { title: 'Position Sizing', items: ['Risk 1% of Capital', 'Max 3 Lots Nifty'] }
    ],
    actions: ['View Chart', 'Set Alert', 'Paper Trade', 'Place Order']
  },
  [Persona.MF_INVESTOR]: {
    heroScore: { label: 'Fund Suitability Score', value: 78 },
    coreMetrics: [
      { label: 'Rolling Returns', value: '14.2%' },
      { label: 'Expense Ratio', value: '0.62%' },
      { label: 'Risk Rating', value: 'Moderate High' }
    ],
    keySections: [
      { title: 'Fund Comparison', items: ['Alpha Fund vs Peers', 'Style Drift Detection', 'Capture Ratios'] },
      { title: 'Holdings Analysis', items: ['Concentration Risk', 'Midcap Exposure', 'Cash Levels'] }
    ],
    actions: ['Compare Funds', 'Replace Fund', 'Start SIP']
  },
  [Persona.MFD]: {
    heroScore: { label: 'Client Suitability Score', value: 89 },
    coreMetrics: [
      { label: 'Client AUM', value: '₹4.2 Cr' },
      { label: 'SIP Book', value: '₹12.5L/mo' },
      { label: 'Goal Probability', value: '92%' }
    ],
    keySections: [
      { title: 'Recommended Funds', items: ['Multicap Focus', 'Target Maturity Debt', 'Sectoral Tilt: Tech'] },
      { title: 'Proposal Summary', items: ['Diversification benefits', 'Long term CAGR projections'] }
    ],
    actions: ['Generate Proposal', 'Simulate SIP', 'Share with Client', 'Execute']
  },
  [Persona.ADVISOR]: {
    heroScore: { label: 'Advisory Recommendation Score', value: 95 },
    coreMetrics: [
      { label: 'Risk Alignment', value: 'Optimal' },
      { label: 'Insurance Gap', value: '₹50L shortfall' },
      { label: 'Goal Progress', value: 'Ahead by 14m' }
    ],
    keySections: [
      { title: 'IPS Summary', items: ['Horizon: 15Y', 'Target Return: 12% Inflation Adjusted'] },
      { title: 'Suitability Checks', items: ['Compliant with Risk Profile', 'Mandatory Disclosures Ready'] }
    ],
    actions: ['Create IPS', 'Generate Review Report', 'Approve Recommendation']
  },
  [Persona.PORTFOLIO_ANALYST]: {
    heroScore: { label: 'Portfolio Health Score', value: 81 },
    coreMetrics: [
      { label: 'Alpha (LTM)', value: '+2.4%' },
      { label: 'Sharpe Ratio', value: '1.42' },
      { label: 'Overlap', value: 'Low' }
    ],
    keySections: [
      { title: 'Attribution', items: ['Sector Selection: +1.2%', 'Stock Pick: +0.8%', 'Timing: +0.4%'] },
      { title: 'Optimization', items: ['Reduce Banks', 'Add Tech exposure', 'Hedge midcap slice'] }
    ],
    actions: ['Simulate Rebalance', 'Compare Alternatives', 'Export Report']
  },
  [Persona.PORTFOLIO_MANAGER]: {
    heroScore: { label: 'Alpha & Risk Score', value: 88 },
    coreMetrics: [
      { label: 'Beta Exposure', value: '0.92' },
      { label: 'Sector Exposure', value: 'Diversified' },
      { label: 'Contribution to Risk', value: 'Top 3 stocks: 42%' }
    ],
    keySections: [
      { title: 'Exposure Monitor', items: ['Limit check: Passed', 'Drift alert: Smallcaps'] },
      { title: 'Order Basket', items: ['IT rebalance', 'Pharma trimming', 'Auto accumulation'] }
    ],
    actions: ['Rebalance Portfolio', 'Run Scenarios', 'Generate Order Basket']
  },
  [Persona.RISK_ANALYST]: {
    heroScore: { label: 'Overall Risk Score', value: 65 },
    coreMetrics: [
      { label: 'VaR (95%)', value: '₹8.4L' },
      { label: 'Volatility (Ann)', value: '16.2%' },
      { label: 'Beta (Market)', value: '1.08' }
    ],
    keySections: [
      { title: 'Stress Testing', items: ['20% Crash: ₹42L loss', 'Interest Rate Hike: Neutral'] },
      { title: 'Correlation Analysis', items: ['Top 10 holdings correlation: 0.72'] }
    ],
    actions: ['Run Stress Test', 'Simulate Hedge', 'Generate Risk Report']
  },
  [Persona.MARKET_ANALYST]: {
    heroScore: { label: 'Market Regime Score', value: 74 },
    coreMetrics: [
      { label: 'Breadth (LTM)', value: 'Bullish' },
      { label: 'VIX', value: '14.2' },
      { label: 'FII/DII Flow', value: 'Net Long' }
    ],
    keySections: [
      { title: 'Macro Outlook', items: ['Interest rates steady', 'Inflation cooling', 'Manufacturing growth'] },
      { title: 'Sector Leadership', items: ['Banks turning', 'Auto peaking', 'IT recovering'] }
    ],
    actions: ['Generate Weekly Outlook', 'Set Alerts']
  },
  [Persona.RESEARCH_ANALYST]: {
    heroScore: { label: 'Research Conviction Score', value: 82 },
    coreMetrics: [
      { label: 'Earnings Momentum', value: 'Positive' },
      { label: 'ROCE Trend', value: 'Improving' },
      { label: 'Valuation Percentile', value: '62%' }
    ],
    keySections: [
      { title: 'Screening Results', items: ['5 candidates found', 'Quality filtering complete'] },
      { title: 'Factor Attribution', items: ['Growth: High', 'Value: Neutral', 'Momentum: High'] }
    ],
    actions: ['Screen Stocks', 'Compare Peers', 'Export Research']
  },
  [Persona.WEALTH_MANAGER]: {
    heroScore: { label: 'Family Health Score', value: 92 },
    coreMetrics: [
      { label: 'Net Worth', value: '₹145 Cr' },
      { label: 'Goal Funding', value: '98%' },
      { label: 'Tax Efficiency', value: 'High' }
    ],
    keySections: [
      { title: 'Family Balance Sheet', items: ['Real Estate: 40%', 'Financial: 55%', 'Alternatives: 5%'] },
      { title: 'Estate Planning', items: ['Trust execution complete', 'Philanthropy allocation: 2%'] }
    ],
    actions: ['Optimize Allocation', 'Generate Family Report']
  }
};
