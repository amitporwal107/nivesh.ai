/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { LayoutDashboard, MessageSquare, Briefcase, BarChart3, User, ChevronDown, Zap, Target, Users } from 'lucide-react';
import { Screen, Persona } from '../types';
import { cn } from '../lib/utils';

interface NavProps {
  activeScreen: Screen;
  setScreen: (screen: Screen) => void;
  activePersona: Persona | null;
  onOpenSwitcher: () => void;
}

export function BottomNav({ 
  activeScreen, 
  setScreen, 
  persona 
}: { 
  activeScreen: Screen; 
  setScreen: (screen: Screen) => void;
  persona: Persona | null;
}) {
  const getNavItems = () => {
    const baseItems = [
      { id: 'profile' as Screen, label: 'Profile', icon: User },
    ];

    switch (persona) {
      case Persona.TRADER:
        return [
          { id: 'home' as Screen, label: 'Terminal', icon: Zap },
          { id: 'markets' as Screen, label: 'Signals', icon: BarChart3 },
          { id: 'copilot' as Screen, label: 'AI Bot', icon: MessageSquare },
          ...baseItems
        ];
      case Persona.MFD:
      case Persona.ADVISOR:
        return [
          { id: 'home' as Screen, label: 'Practice', icon: LayoutDashboard },
          { id: 'portfolio' as Screen, label: 'Clients', icon: Briefcase },
          { id: 'goals' as Screen, label: 'Goals', icon: Target },
          { id: 'copilot' as Screen, label: 'Advisory', icon: MessageSquare },
          ...baseItems
        ];
      default:
        return [
          { id: 'home' as Screen, label: 'Home', icon: LayoutDashboard },
          { id: 'portfolio' as Screen, label: 'Portfolio', icon: Briefcase },
          { id: 'goals' as Screen, label: 'Goals', icon: Target },
          { id: 'family' as Screen, label: 'Family', icon: Users },
          { id: 'profile' as Screen, label: 'Profile', icon: User },
        ];
    }
  };

  const items = getNavItems();

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 pb-safe md:hidden z-40">
      <div className="flex justify-around items-center h-16 max-w-lg mx-auto">
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => setScreen(item.id)}
            className={cn(
              "flex flex-col items-center justify-center w-full h-full transition-colors",
              activeScreen === item.id ? 'text-indigo-600' : 'text-slate-400'
            )}
          >
            <item.icon className="w-5 h-5" />
            <span className="text-[10px] font-bold mt-1 tracking-tight">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

export function Sidebar({ 
  activeScreen, 
  setScreen, 
  persona 
}: { 
  activeScreen: Screen; 
  setScreen: (screen: Screen) => void;
  persona: Persona | null;
}) {
  const getNavItems = () => {
    switch (persona) {
      case Persona.TRADER:
        return [
          { id: 'home' as Screen, label: 'Trade Terminal', icon: Zap },
          { id: 'markets' as Screen, label: 'Alpha Signals', icon: BarChart3 },
          { id: 'portfolio' as Screen, label: 'Positions', icon: Briefcase },
          { id: 'goals' as Screen, label: 'Risk Budget', icon: Target },
          { id: 'copilot' as Screen, label: 'Strategy Copilot', icon: MessageSquare },
          { id: 'profile' as Screen, label: 'Settings', icon: User },
        ];
      case Persona.MFD:
      case Persona.ADVISOR:
        return [
          { id: 'home' as Screen, label: 'Practice Overview', icon: LayoutDashboard },
          { id: 'portfolio' as Screen, label: 'Client Portfolios', icon: Briefcase },
          { id: 'goals' as Screen, label: 'Client Goals', icon: Target },
          { id: 'markets' as Screen, label: 'Product Research', icon: BarChart3 },
          { id: 'copilot' as Screen, label: 'Advisory Engine', icon: MessageSquare },
          { id: 'profile' as Screen, label: 'Profile & KYB', icon: User },
        ];
      default:
        return [
          { id: 'home' as Screen, label: 'Dashboard', icon: LayoutDashboard },
          { id: 'portfolio' as Screen, label: 'My Portfolio', icon: Briefcase },
          { id: 'goals' as Screen, label: 'My Goals', icon: Target },
          { id: 'family' as Screen, label: 'Family Hub', icon: Users },
          { id: 'markets' as Screen, label: 'Market Insights', icon: BarChart3 },
          { id: 'copilot' as Screen, label: 'AI Copilot', icon: MessageSquare },
          { id: 'profile' as Screen, label: 'My Profile', icon: User },
        ];
    }
  };

  const items = getNavItems();

  return (
    <aside className="hidden md:flex w-64 bg-white border-r border-slate-200 p-6 flex-col space-y-8 shrink-0 h-[calc(100vh-4rem-2.5rem)]">
      <div className="space-y-1">
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">
          {persona === Persona.ADVISOR || persona === Persona.MFD ? 'Business Console' : 'Navigation'}
        </p>
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => setScreen(item.id)}
            className={cn(
              "sidebar-link w-full",
              activeScreen === item.id ? "sidebar-link-active" : "sidebar-link-inactive"
            )}
          >
            <item.icon className="w-5 h-5" />
            <span>{item.label}</span>
          </button>
        ))}
      </div>

      <div className="mt-auto p-4 bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-2xl text-white shadow-lg overflow-hidden relative">
        <div className="relative z-10">
          <p className="text-[10px] font-bold uppercase tracking-widest opacity-70 mb-1">
            {persona === Persona.TRADER ? 'Daily P&L Target' : 'Goal Progress'}
          </p>
          <p className="text-sm font-bold tracking-tight">
            {persona === Persona.TRADER ? 'Intraday Alpha' : 'Retirement 2045'}
          </p>
          <div className="mt-3 bg-white/20 rounded-full h-1.5 w-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: "64%" }}
              transition={{ duration: 1, delay: 0.5 }}
              className="bg-white h-full rounded-full" 
            />
          </div>
          <p className="text-[10px] mt-2 opacity-80 font-bold uppercase tracking-tight">
            {persona === Persona.TRADER ? '₹45,200 / ₹70,000' : '₹1.2 Cr / ₹1.8 Cr'}
          </p>
        </div>
        {/* Background Accent */}
        <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -mr-12 -mt-12 blur-2xl" />
      </div>
    </aside>
  );
}

export function TopBar({ activePersona, onOpenSwitcher }: { activePersona: Persona | null; onOpenSwitcher: () => void }) {
  return (
    <nav className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 shrink-0 sticky top-0 z-50">
      <div className="flex items-center space-x-3">
        <div className="bg-indigo-600 text-white p-2 rounded-lg shadow-sm">
          <Zap className="w-5 h-5" fill="white" />
        </div>
        <h1 className="text-xl font-bold tracking-tight text-slate-800">
          Nivesh AI <span className="text-indigo-600">Copilot</span>
        </h1>
      </div>
      
      <div className="flex items-center space-x-6">
        <button 
          onClick={onOpenSwitcher}
          className="hidden sm:flex bg-slate-100 px-3 py-1.5 rounded-full border border-slate-200 items-center space-x-2 cursor-pointer hover:bg-slate-200 transition-colors"
        >
          <span className="text-xs font-bold uppercase text-slate-500 tracking-wider">Workspace:</span>
          <span className="text-sm font-bold text-slate-700">{activePersona}</span>
          <ChevronDown className="w-4 h-4 text-slate-400" />
        </button>
        
        <div className="flex items-center space-x-3">
          <div className="hidden lg:block text-right">
            <p className="text-sm font-bold text-slate-800">Amit Sharma</p>
            <p className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest">Premium Member</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-indigo-100 border-2 border-white shadow-sm flex items-center justify-center text-indigo-700 font-bold italic tracking-tighter">
            AS
          </div>
        </div>
      </div>
    </nav>
  );
}

export function MarketTicker() {
  return (
    <footer className="h-10 bg-slate-900 text-white flex items-center px-6 overflow-hidden shrink-0 z-50">
      <div className="flex items-center space-x-8 text-[10px] font-mono whitespace-nowrap">
        <div className="flex items-center space-x-2">
          <span className="text-slate-500">NIFTY 50</span>
          <span className="font-bold">22,430.15</span>
          <span className="text-emerald-400 font-bold">+1.24%</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-slate-500">SENSEX</span>
          <span className="font-bold">73,806.15</span>
          <span className="text-emerald-400 font-bold">+0.88%</span>
        </div>
        <div className="flex items-center space-x-2 border-l border-slate-700 pl-8">
          <span className="text-slate-500">GOLD 24K</span>
          <span className="font-bold">66,240</span>
          <span className="text-rose-400 font-bold">-0.12%</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-slate-500">USD/INR</span>
          <span className="font-bold">82.94</span>
          <span className="text-slate-400 font-bold">0.00%</span>
        </div>
      </div>
      <div className="ml-auto hidden sm:flex items-center space-x-4">
        <div className="flex items-center space-x-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)] animate-pulse"></div>
          <span className="text-[9px] font-bold uppercase tracking-widest text-slate-400">System Operational</span>
        </div>
      </div>
    </footer>
  );
}
