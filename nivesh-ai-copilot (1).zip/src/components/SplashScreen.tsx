/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect } from 'react';
import { motion } from 'motion/react';
import { Zap } from 'lucide-react';

export default function SplashScreen({ onComplete }: { onComplete: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onComplete, 3000);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 bg-slate-900 flex flex-col items-center justify-center z-[100] overflow-hidden">
      {/* Background Grid Pattern */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
           style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '32px 32px' }} />
      
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative"
      >
        <div className="bg-gradient-to-br from-indigo-500 to-indigo-700 w-24 h-24 rounded-[2rem] flex items-center justify-center shadow-[0_20px_50px_rgba(79,70,229,0.3)] border border-white/20">
          <Zap className="w-12 h-12 text-white" fill="white" />
        </div>
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          className="absolute -inset-4 border border-indigo-500/20 rounded-[2.5rem]"
        />
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
          className="absolute -inset-8 border border-white/5 rounded-[3rem]"
        />
      </motion.div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.8 }}
        className="mt-12 text-center"
      >
        <h1 className="text-4xl font-bold text-white tracking-tighter mb-2">
          Nivesh AI <span className="text-indigo-400">Copilot</span>
        </h1>
        <div className="flex items-center justify-center space-x-2">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <p className="text-xs font-bold text-slate-400 uppercase tracking-[0.2em]">Neural Market Intelligence</p>
        </div>
      </motion.div>

      <div className="absolute bottom-12 w-64 h-1 bg-white/5 rounded-full overflow-hidden">
        <motion.div
          initial={{ x: "-100%" }}
          animate={{ x: "0%" }}
          transition={{ duration: 3, ease: "easeInOut" }}
          className="h-full bg-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.8)]"
        />
      </div>
      
      <p className="absolute bottom-6 text-[10px] font-bold text-slate-600 uppercase tracking-widest">
        Enterprise Security Verified • ISO 27001
      </p>
    </div>
  );
}
