import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { fetchMarketIntelligence, MarketIntelligence } from '../../services/aiService';
import { 
  TrendingUp, 
  TrendingDown, 
  Shield, 
  Zap, 
  AlertTriangle, 
  Activity, 
  BarChart3, 
  Clock, 
  ArrowUpRight, 
  Filter, 
  RotateCcw, 
  LayoutGrid, 
  List,
  ChevronDown,
  ChevronRight, 
  ChevronUp,
  GripVertical,
  RefreshCw,
  Target,
  FlaskConical,
  BookOpen,
  Info,
  ExternalLink,
  Flame,
  Sparkles
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { Persona } from '../../types';

interface SectionProps {
  id: string;
  number: string;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  isOpen: boolean;
  onToggle: () => void;
}

const Section = ({ number, title, subtitle, children, isOpen, onToggle }: SectionProps) => (
  <div className="bg-[#1A1A1A] border border-white/5 rounded-[1.5rem] overflow-hidden shadow-2xl mb-6">
    <div 
      onClick={onToggle}
      className="px-6 py-4 flex items-center justify-between cursor-pointer hover:bg-white/[0.02] transition-colors"
    >
      <div className="flex items-center gap-4">
        <GripVertical className="w-4 h-4 text-white/10 cursor-grab" />
        <span className="text-[10px] font-black text-white/30 font-mono tracking-tighter">§{number}</span>
        <div>
          <h3 className="text-sm font-black text-white uppercase tracking-wider">{title}</h3>
          {subtitle && <p className="text-[10px] text-white/30 font-medium tracking-tight">{subtitle}</p>}
        </div>
      </div>
      {isOpen ? <ChevronUp className="w-4 h-4 text-white/20" /> : <ChevronDown className="w-4 h-4 text-white/20" />}
    </div>
    <AnimatePresence initial={false}>
      {isOpen && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.3, ease: 'easeInOut' }}
        >
          <div className="p-6 border-t border-white/5 bg-white/[0.01]">
            {children}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  </div>
);

export default function MarketDashboard({ persona }: { persona: Persona }) {
  const [marketData, setMarketData] = useState<MarketIntelligence | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadMarketData = async () => {
      const data = await fetchMarketIntelligence();
      setMarketData(data);
      setLoading(false);
    };
    loadMarketData();
  }, []);

  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    'market': true,
    'strategy': true,
    'events': false,
    'sectors': true,
    'trades': true,
    'journal': true
  });

  const toggleSection = (id: string) => {
    setOpenSections(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-700">
      {/* Top Quick Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className={cn(
          "border p-5 rounded-2xl flex items-center gap-4",
          marketData?.bias === 'Risk-off' ? "bg-rose-500/5 border-rose-500/10" : "bg-emerald-500/5 border-emerald-500/10"
        )}>
          <div className={cn(
            "w-10 h-10 rounded-xl flex items-center justify-center border",
            marketData?.bias === 'Risk-off' ? "bg-rose-500/10 border-rose-500/20" : "bg-emerald-500/10 border-emerald-500/20"
          )}>
            {marketData?.bias === 'Risk-off' ? (
              <TrendingDown className="w-5 h-5 text-rose-500" />
            ) : (
              <TrendingUp className="w-5 h-5 text-emerald-500" />
            )}
          </div>
          <div>
            <p className={cn(
              "text-[9px] font-black uppercase tracking-widest",
              marketData?.bias === 'Risk-off' ? "text-rose-500/50" : "text-emerald-500/50"
            )}>Bias</p>
            <p className="text-xs font-bold text-white tracking-tight">
              {loading ? "Calculating..." : `${marketData?.bias} • ${marketData?.bias === 'Risk-off' ? 'trim leverage' : 'buy alpha'}`}
            </p>
          </div>
        </div>

        <div className="bg-[#1A1A1A] border border-white/5 p-5 rounded-2xl flex items-center gap-4">
          <div className="w-10 h-10 bg-indigo-500/10 rounded-xl flex items-center justify-center border border-indigo-500/20">
            <Activity className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <p className="text-[9px] font-black text-indigo-500/50 uppercase tracking-widest">Regime</p>
            <p className="text-xs font-bold text-white tracking-tight italic">
              {loading ? "Sensing..." : marketData?.regime}
            </p>
          </div>
        </div>

        <div className={cn(
          "border p-5 rounded-2xl flex items-center gap-4",
          marketData && marketData.vix > 18 ? "bg-amber-500/5 border-amber-500/10" : "bg-white/5 border-white/10"
        )}>
          <div className={cn(
            "w-10 h-10 rounded-xl flex items-center justify-center border",
            marketData && marketData.vix > 18 ? "bg-amber-500/10 border-amber-500/20" : "bg-white/5 border-white/10"
          )}>
            <Zap className={cn(
              "w-5 h-5",
              marketData && marketData.vix > 18 ? "text-amber-500" : "text-indigo-400"
            )} />
          </div>
          <div>
            <p className="text-[9px] font-black text-white/20 uppercase tracking-widest">Alpha VIX</p>
            <p className="text-xs font-bold text-white tracking-tight">
              {loading ? "--" : marketData?.vix} <span className="text-[10px] text-white/30 font-medium ml-1">volatility {marketData && marketData.vix > 18 ? 'elevated' : 'stable'}</span>
            </p>
          </div>
        </div>
      </div>

      {/* Sub Nav */}
      <div className="flex items-center gap-8 py-2 px-2 overflow-x-auto no-scrollbar border-b border-white/5">
        {['The Market', 'The Strategy', 'Live Events', 'The Sectors', 'The Trades', 'Trade Journal'].map((nav, i) => (
          <button key={nav} className={cn(
            "text-[10px] font-bold uppercase tracking-widest whitespace-nowrap transition-colors",
            i === 0 ? "text-indigo-400" : "text-white/30 hover:text-white/60"
          )}>
            {nav}
          </button>
        ))}
        <button className="ml-auto p-1 text-white/20 hover:text-white transition-colors">
          <RotateCcw className="w-3 h-3" />
        </button>
      </div>

      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mt-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(79,70,229,0.3)]">
            <Activity className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white tracking-tighter italic">Market Dashboard</h1>
            <p className="text-[10px] text-white/30 font-medium">Drag sections to reorder • click a header to collapse</p>
          </div>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/10 text-emerald-400 text-[10px] font-black rounded-lg border border-emerald-500/20 uppercase tracking-widest">
          MACRO V1
        </div>
      </div>

      {/* SECTION 1: THE MARKET */}
      <Section 
        id="market" 
        number="1" 
        title="The Market" 
        subtitle="Today's regime — what the macro is doing"
        isOpen={openSections.market}
        onToggle={() => toggleSection('market')}
      >
        <div className="space-y-6">
          {/* Main Status Banner */}
          <div className="bg-rose-600 rounded-2xl p-8 relative overflow-hidden group shadow-2xl">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16 group-hover:bg-white/20 transition-all" />
            <div className="flex items-center gap-6 relative z-10">
              <div className="w-16 h-16 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center border border-white/20">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-1">
                  <span className="text-[10px] font-black text-white/60 uppercase tracking-widest">DEPLOY VERDICT • Markets closed • 16:24 IST</span>
                  <button className="flex items-center gap-1 text-[10px] font-black text-white/60 hover:text-white transition-opacity ml-auto">
                    <RefreshCw className="w-3 h-3" /> refresh
                  </button>
                </div>
                <h2 className="text-4xl font-black text-white tracking-tighter mb-2 italic">DEFENSIVE • RED</h2>
                <p className="text-sm font-bold text-white/80">Macro risk HIGH — keep cash, hedge longs, avoid new positions</p>
              </div>
            </div>
          </div>

          {/* KPI Grid */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {[
              { label: 'NIFTY 50 • LIVE', value: '23379.55', change: '-1.8% • trend DOWN', color: 'text-rose-500' },
              { label: 'BREADTH', value: '80.0%', change: 'above 20EMA • A/D 2.32', color: 'text-emerald-500' },
              { label: '52W HIGHS / LOWS', value: '296 / 7', change: '1760 adv • 759 dec', color: 'text-emerald-500' },
              { label: 'INDIA VIX', value: '19.28', change: 'RISING', color: 'text-rose-500' },
              { label: 'MACRO RISK', value: 'HIGH', change: 'multiplier 0.80x', color: 'text-rose-500' },
            ].map((kpi, i) => (
              <div key={i} className="p-4 rounded-xl border border-white/5 bg-white/[0.01]">
                <p className="text-[9px] font-black text-white/30 uppercase tracking-tighter mb-3">{kpi.label}</p>
                <p className="text-xl font-black text-white tracking-tight mb-1">{kpi.value}</p>
                <p className={cn("text-[9px] font-bold uppercase tracking-tight", kpi.color)}>{kpi.change}</p>
              </div>
            ))}
          </div>

          {/* Sector Bar */}
          <div className="flex items-center gap-6 px-4 py-3 bg-white/[0.01] border border-white/5 rounded-xl overflow-x-auto no-scrollbar">
            <span className="text-[9px] font-black text-white/20 uppercase tracking-widest shrink-0">Sectors</span>
            {[
              { name: 'Metal', val: '+1.5%', up: true },
              { name: 'PSU Bank', val: '+0.7%', up: true },
              { name: 'Energy', val: '+0.6%', up: true },
              { name: 'Realty', val: '-2.3%', up: false },
              { name: 'IT', val: '-1.9%', up: false },
              { name: 'Media', val: '-0.9%', up: false },
            ].map(s => (
              <div key={s.name} className="flex items-center gap-2 shrink-0">
                <div className={cn("w-1.5 h-1.5 rounded-full", s.up ? "bg-emerald-500" : "bg-rose-500")} />
                <span className="text-[10px] font-bold text-white/60">{s.name} <span className={s.up ? "text-emerald-400" : "text-rose-400"}>{s.val}</span></span>
              </div>
            ))}
          </div>

          {/* Macro Context Bar */}
          <div className="bg-white/[0.02] border border-white/5 rounded-xl p-4 flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2 mr-4">
              <Activity className="w-4 h-4 text-white/40" />
              <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Macro Context</span>
              <span className="text-[9px] font-mono text-white/20">2026-05-12</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-500 text-[9px] font-black uppercase tracking-widest">
              <TrendingDown className="w-3 h-3" /> Market: Bear
            </div>
            <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[9px] font-black uppercase tracking-widest">
              <TrendingUp className="w-3 h-3" /> Inflation: Rising
            </div>
            <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-500 text-[9px] font-black uppercase tracking-widest">
              <AlertTriangle className="w-3 h-3" /> Liquidity: Tight
            </div>
            <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-500 text-[9px] font-black uppercase tracking-widest">
              <Shield className="w-3 h-3" /> Risk: High
            </div>
            <span className="text-[10px] font-mono text-white/40">×0.80</span>
          </div>

          {/* Pre-open Ticker */}
          <div className="flex items-center gap-6 px-4 py-2 border border-white/5 rounded-lg bg-white/[0.01]">
             <Info className="w-3.5 h-3.5 text-white/40" />
             <p className="text-[10px] font-medium text-white/40">High-risk regime • Avoid consumption/aviation; prefer IT/Oil exporters.</p>
             <div className="ml-auto flex items-center gap-4 text-[9px] font-mono text-white/30 uppercase tracking-tighter">
                <span>Pre-open</span>
                <span>S&P -0.13%</span>
                <span>Nasdaq -0.16%</span>
                <span>Asia +0.23%</span>
                <span className="text-white/60">Composite +0.16</span>
             </div>
          </div>
        </div>
      </Section>

      {/* SECTION 2: THE STRATEGY */}
      <Section 
        id="strategy" 
        number="2" 
        title="The Strategy" 
        subtitle="Translated into bias, sizing, and the sectors to favour or avoid"
        isOpen={openSections.strategy}
        onToggle={() => toggleSection('strategy')}
      >
        <div className="space-y-6">
          <div className="flex items-center gap-2 p-3 bg-rose-500/5 border border-rose-500/10 rounded-xl text-rose-500 text-[10px] font-black uppercase tracking-widest">
             <Flame className="w-4 h-4" /> HIGH risk regime — trim aggressive sizing and avoid weak sectors.
          </div>
          
          <div className="bg-indigo-600/5 border border-indigo-600/10 rounded-2xl p-6 relative overflow-hidden">
             <div className="absolute top-0 right-0 p-4">
                <div className="flex items-center gap-2 px-3 py-1 bg-indigo-500/20 rounded-full border border-indigo-500/20 text-indigo-400 text-[9px] font-black uppercase">
                   Confidence: 58% • Moderate
                </div>
             </div>
             <div className="flex items-center gap-3 mb-6">
                <FlaskConical className="w-5 h-5 text-indigo-400" />
                <h4 className="text-[10px] font-black text-white/40 uppercase tracking-widest">Today's Strategy</h4>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-12">
                <div className="flex items-start gap-4">
                   <span className="text-[10px] font-black text-white/20 uppercase w-20 pt-1 shrink-0">Bias:</span>
                   <span className="text-sm font-bold text-white italic">Defensive — survive first</span>
                </div>
                <div className="flex items-start gap-4">
                   <span className="text-[10px] font-black text-white/20 uppercase w-20 pt-1 shrink-0">Aggression:</span>
                   <span className="text-sm font-bold text-white">Low • 0.8x position size</span>
                </div>
                <div className="flex items-start gap-4">
                   <span className="text-[10px] font-black text-white/20 uppercase w-20 pt-1 shrink-0">Focus:</span>
                   <div className="flex flex-wrap gap-2">
                      {['AVIATION', 'PAINT', 'TYRES'].map(f => (
                        <div key={f} className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[9px] font-black">
                           <TrendingUp className="w-2.5 h-2.5" /> {f}
                        </div>
                      ))}
                   </div>
                </div>
                <div className="flex items-start gap-4">
                   <span className="text-[10px] font-black text-white/20 uppercase w-20 pt-1 shrink-0">Avoid:</span>
                   <div className="flex flex-wrap gap-2">
                      {['OIL GAS', 'REFINERY'].map(a => (
                        <div key={a} className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[9px] font-black">
                           <TrendingDown className="w-2.5 h-2.5" /> {a}
                        </div>
                      ))}
                   </div>
                </div>
             </div>

             <div className="mt-8 flex items-start gap-3 p-4 bg-white/[0.02] border border-white/5 rounded-xl">
                <BookOpen className="w-4 h-4 text-white/20 shrink-0 mt-0.5" />
                <p className="text-[10px] text-white/40 leading-relaxed font-medium">Interpretation: Rising input costs + USD strength compress margins. Importers + discretionary spend hurt; exporters insulated.</p>
             </div>
          </div>
        </div>
      </Section>

      {/* SECTION 4: THE SECTORS */}
      <Section 
        id="sectors" 
        number="4" 
        title="The Sectors" 
        subtitle="Macro tailwinds and headwinds with stock-level setups"
        isOpen={openSections.sectors}
        onToggle={() => toggleSection('sectors')}
      >
        <div className="space-y-6">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-3">
              <LayoutGrid className="w-4 h-4 text-white/40" />
              <h4 className="text-[10px] font-black text-white/40 uppercase tracking-widest">Sector Macro Tilt</h4>
              <span className="text-[9px] font-mono text-white/20">2026-05-12</span>
            </div>
            <button className="flex items-center gap-1.5 text-[9px] font-black text-white/30 hover:text-white transition-colors">
               <RefreshCw className="w-3 h-3" /> Refresh
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div className="bg-emerald-500/5 border border-emerald-500/10 rounded-2xl p-6">
                <div className="flex items-center gap-2 mb-4">
                   <Flame className="w-3.5 h-3.5 text-emerald-500" />
                   <h5 className="text-[9px] font-black text-emerald-500/60 uppercase tracking-widest">Top Macro Sectors Today</h5>
                </div>
                <div className="space-y-3">
                   {['AVIATION (+5.1)', 'PAINT (+5.1)', 'TYRES (+3.5)', 'FMCG (+2.5)'].map((sect, i) => (
                      <div key={i} className="flex items-center gap-3">
                         <span className="text-[10px] font-black text-white/20 font-mono">{i+1}.</span>
                         <span className="text-sm font-black text-white tracking-widest italic">{sect}</span>
                      </div>
                   ))}
                </div>
             </div>
             <div className="bg-rose-500/5 border border-rose-500/10 rounded-2xl p-6">
                <div className="flex items-center gap-2 mb-4">
                   <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                   <h5 className="text-[9px] font-black text-rose-500/60 uppercase tracking-widest">Weak Sectors Today</h5>
                </div>
                <div className="space-y-3">
                   {['OIL GAS (-5.1)', 'REFINERY (-2.5)', 'METAL (-1.8)', 'PSU BANK (-0.9)'].map((sect, i) => (
                      <div key={i} className="flex items-center gap-3">
                         <span className="text-[10px] font-black text-white/20 font-mono">{i+1}.</span>
                         <span className="text-sm font-black text-white tracking-widest italic">{sect}</span>
                      </div>
                   ))}
                </div>
             </div>
          </div>
        </div>
      </Section>

      {/* SECTION 5: THE TRADES */}
      <Section 
        id="trades" 
        number="5" 
        title="The Trades" 
        subtitle="Today's positional picks ranked by conviction • 5–30 day timeframe"
        isOpen={openSections.trades}
        onToggle={() => toggleSection('trades')}
      >
        <div className="space-y-8">
           <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                 <Target className="w-6 h-6 text-emerald-500" />
                 <div>
                    <h4 className="text-xl font-black text-white tracking-tighter italic">Positional Picks</h4>
                    <p className="text-[10px] font-mono text-white/20 uppercase tracking-widest">2026-05-11</p>
                 </div>
              </div>
              <div className="flex items-center gap-2 bg-white/[0.02] p-1.5 rounded-xl border border-white/10">
                 <button className="flex items-center gap-2 px-6 py-2 bg-indigo-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest shadow-xl">
                    <Zap className="w-3.5 h-3.5" /> Run engine
                 </button>
                 <div className="h-6 w-px bg-white/10 mx-1" />
                 <button className="p-2 text-white/20 hover:text-white transition-colors">
                    <LayoutGrid className="w-4 h-4" />
                 </button>
                 <button className="p-2 text-white/20 hover:text-white transition-colors">
                    <List className="w-4 h-4" />
                 </button>
              </div>
           </div>

           <div>
              <p className="text-[10px] font-black text-amber-400 uppercase tracking-[0.3em] font-mono mb-6">🪟 Tomorrow's Watch <span className="text-white/20 ml-2">PRE-BREAKOUT • SET GTT TONIGHT • 2 STOCKS</span></p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 {[
                   { ticker: 'SUNDROP', score: 71, status: 'EARLY BREAKOUT', timing: 'WAIT', price: '670.25', change: '-2.6%', entry: '688.19', sl: '656.3', tgt: '751.97' },
                   { ticker: 'MAXHEALTH', score: 69, status: 'EARLY BREAKOUT', timing: 'NEAR', price: '1,017.7', change: '-1.2%', entry: '1,030.13', sl: '987.42', tgt: '1,115.54' },
                 ].map(stock => (
                   <div key={stock.ticker} className="bg-white/[0.02] border border-white/5 rounded-[2rem] p-6 hover:border-white/10 transition-all group overflow-hidden relative">
                      <div className="absolute top-0 right-0 w-24 h-24 bg-white/5 rounded-full blur-2xl -mr-12 -mt-12 group-hover:bg-white/10 transition-colors" />
                      <div className="flex justify-between items-start mb-8 relative z-10">
                         <div>
                            <h5 className="text-xl font-black text-white tracking-widest italic">{stock.ticker}</h5>
                            <div className="flex items-center gap-3 mt-2">
                               <span className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[8px] font-black uppercase tracking-widest rounded-md">{stock.status}</span>
                               <span className="px-2 py-0.5 bg-white/5 border border-white/10 text-white/40 text-[8px] font-black uppercase tracking-widest rounded-md">{stock.timing}</span>
                               <span className="text-[9px] font-mono text-white/30 italic">₹{stock.price} <span className="text-rose-400">{stock.change}</span></span>
                            </div>
                         </div>
                         <div className="flex flex-col items-end">
                            <div className="bg-emerald-500 text-black text-[9px] font-black px-2 py-0.5 rounded-md mb-1 uppercase tracking-tighter">HC {stock.score}</div>
                            <div className="w-12 h-1 bg-white/5 rounded-full overflow-hidden">
                               <div className="h-full bg-emerald-500" style={{ width: `${stock.score}%` }} />
                            </div>
                         </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-6 relative z-10 py-4 border-y border-white/5 mb-4">
                         <div>
                            <p className="text-[8px] font-black text-white/20 uppercase tracking-widest mb-1.5">Entry</p>
                            <p className="text-xs font-black text-white">₹{stock.entry}</p>
                         </div>
                         <div>
                            <p className="text-[8px] font-black text-white/20 uppercase tracking-widest mb-1.5">SL</p>
                            <p className="text-xs font-black text-rose-500">₹{stock.sl}</p>
                         </div>
                         <div>
                            <p className="text-[8px] font-black text-white/20 uppercase tracking-widest mb-1.5">TGT</p>
                            <p className="text-xs font-black text-emerald-400">₹{stock.tgt}</p>
                         </div>
                      </div>

                      <div className="flex items-center justify-between text-[8px] font-black text-white/20 uppercase tracking-widest">
                         <span>RR 1:2.0 • 7–20d</span>
                         <ChevronDown className="w-3 h-3 group-hover:text-white transition-colors" />
                      </div>
                   </div>
                 ))}
              </div>
           </div>

           <div>
              <p className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.3em] font-mono mb-6 flex items-center gap-2">
                 <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /> HIGH CONVICTION <span className="text-white/20 ml-2">TRIGGER FIRED • PLAN READY • 7 STOCKS</span>
              </p>
              <div className="flex gap-6 overflow-x-auto no-scrollbar pb-4 pr-12">
                 {[
                   { ticker: 'BIOCON', score: 75, price: '402.45', change: '+4.1%', entry: '386.69', sl: '371.97', tgt: '416.13' },
                   { ticker: 'MUNJALAU', score: 77, price: '87.79', change: '+0.3%', entry: '87.57', sl: '83.32', tgt: '96.05' },
                   { ticker: 'ICICIGI', score: 72, price: '1,910.81', change: '-6.7%', entry: '1,910.81', sl: '1,838.72', tgt: '2,054.99' },
                 ].map(stock => (
                   <div key={stock.ticker} className="min-w-[280px] bg-white/[0.02] border border-white/5 rounded-[2rem] p-6 hover:border-white/10 transition-all flex flex-col group relative">
                      <div className="flex justify-between items-start mb-6">
                         <div>
                            <h5 className="text-lg font-black text-white tracking-widest italic">{stock.ticker}</h5>
                            <div className="flex items-center gap-2 mt-2">
                               <span className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[7px] font-black uppercase tracking-widest rounded-md">EARLY BREAKOUT</span>
                               <span className="px-2 py-0.5 bg-indigo-600 text-white text-[7px] font-black uppercase tracking-widest rounded-md">TRIG</span>
                            </div>
                         </div>
                         <div className="flex flex-col items-end">
                            <div className="bg-emerald-500/20 text-emerald-400 text-[8px] font-black px-2 py-0.5 rounded-md mb-1 uppercase tracking-tighter">HC {stock.score}</div>
                         </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 py-3 border-y border-white/5 mb-4">
                         <div><p className="text-[7px] font-black text-white/20 uppercase mb-1">Entry</p><p className="text-[10px] font-black text-white">₹{stock.entry}</p></div>
                         <div><p className="text-[7px] font-black text-white/20 uppercase mb-1">SL</p><p className="text-[10px] font-black text-rose-500">₹{stock.sl}</p></div>
                         <div><p className="text-[7px] font-black text-white/20 uppercase mb-1">TGT</p><p className="text-[10px] font-black text-emerald-400">₹{stock.tgt}</p></div>
                      </div>

                      <div className="flex items-center justify-between text-[7px] font-black text-white/20 uppercase tracking-widest mt-auto">
                         <span>RR 1:2.0 • 7–20d</span>
                         <ArrowUpRight className="w-3 h-3 group-hover:text-indigo-400" />
                      </div>
                   </div>
                 ))}
                 <div className="min-w-[80px] flex items-center justify-center cursor-pointer group">
                    <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/5 group-hover:bg-white/10 transition-all">
                       <ChevronRight className="w-5 h-5 text-white/20" />
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </Section>

      {/* SECTION 6: TRADE JOURNAL */}
      <Section 
        id="journal" 
        number="6" 
        title="Trade Journal" 
        subtitle="Staged entries • exit ladder • live P&L • hedge guidance"
        isOpen={openSections.journal}
        onToggle={() => toggleSection('journal')}
      >
        <div className="space-y-8">
           <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {[
                { label: 'OPEN TRADES', value: '1' },
                { label: 'GROSS LONG', value: '₹0' },
                { label: 'REALIZED P&L', value: '+₹0' },
                { label: 'WIN RATE', value: '—', sub: 'OW • OL' },
              ].map((stat, i) => (
                <div key={i} className="p-6 bg-white/[0.01] border border-white/5 rounded-2xl">
                   <p className="text-[8px] font-black text-white/20 uppercase tracking-[0.2em] mb-4 font-mono">{stat.label}</p>
                   <p className="text-2xl font-black text-white tracking-tighter italic">{stat.value}</p>
                   {stat.sub && <p className="text-[8px] font-black text-white/10 uppercase mt-2">{stat.sub}</p>}
                </div>
              ))}
           </div>

           <div className="space-y-4">
              <div className="flex items-center gap-4 px-2 w-full">
                 <button className="text-[9px] font-black text-indigo-400 border-b-2 border-indigo-500 pb-1 uppercase tracking-widest">Open</button>
                 <button className="text-[9px] font-black text-white/20 pb-1 uppercase tracking-widest hover:text-white transition-colors">Closed</button>
                 <button className="text-[9px] font-black text-white/20 pb-1 uppercase tracking-widest hover:text-white transition-colors">All</button>
                 <button className="ml-auto flex items-center gap-2 bg-[#10B981] text-black px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-[0_4px_12px_rgba(16,185,129,0.3)]">
                    + New Trade
                 </button>
              </div>

              <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-6 group cursor-pointer hover:bg-white/[0.04] transition-all">
                 <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="flex items-center gap-5">
                       <ChevronRight className="w-4 h-4 text-white/10" />
                       <h5 className="text-lg font-black text-white italic tracking-widest">PETRONET</h5>
                       <span className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[8px] font-black uppercase tracking-widest rounded-md">OPEN</span>
                       <span className="text-[8px] font-black text-indigo-400 uppercase tracking-widest">next: PILOT</span>
                    </div>
                    <div className="flex items-center gap-12">
                       <div className="text-right">
                          <p className="text-[8px] font-black text-white/10 uppercase mb-1 tracking-widest">—</p>
                          <p className="text-xs font-black text-white/30 tracking-tight">OW • OL</p>
                       </div>
                       <button className="flex items-center gap-2 px-6 py-2 bg-white/5 border border-white/10 rounded-xl text-white text-[9px] font-black uppercase tracking-widest hover:bg-white/10">
                          + Fill
                       </button>
                    </div>
                 </div>
                 <div className="mt-4 flex items-center gap-6 px-11">
                    <p className="text-[10px] font-medium text-white/30">cap ₹1,00,000 • invested ₹0 (0%)</p>
                    <p className="text-[10px] font-medium text-white/30">+₹0 (+0.0%)</p>
                 </div>
              </div>
           </div>
        </div>
      </Section>

      {/* Floating Copilot Button */}
      <div className="fixed bottom-10 right-10 z-[100]">
        <button className="bg-[#059669] text-white px-8 py-4 rounded-full flex items-center gap-3 shadow-[0_8px_32px_rgba(5,150,105,0.4)] border border-emerald-400/20 hover:scale-[1.02] transition-all active:scale-95">
          <Sparkles className="w-5 h-5 fill-white" />
          <span className="text-sm font-black italic tracking-tight">Nivesh Copilot</span>
        </button>
      </div>
    </div>
  );
}
