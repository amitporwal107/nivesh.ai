/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Mic, 
  Paperclip, 
  Sparkles, 
  History,
  ShieldCheck,
  Zap,
  TrendingUp,
  LayoutDashboard,
  User,
  Users,
  PieChart,
  Globe,
  Settings,
  Plus,
  Search,
  MessageSquare,
  Menu,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Trash2,
  Share2,
  MoreVertical,
  PlusCircle,
  FileText,
  BarChart2
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { Persona, ChatMessage } from '../../types';

// Import existing screens for "widget" mode
import HomeDashboard from './HomeDashboard';
import TradeTerminal from './TradeTerminal';
import PortfolioDashboard from './PortfolioDashboard';
import AdvisorDashboard from './AdvisorDashboard';

type ViewMode = 'CHAT' | 'DASHBOARD' | 'HYBRID';

export default function CopilotTerminal({ 
  persona, 
  messages, 
  onSend 
}: { 
  persona: Persona; 
  messages: ChatMessage[];
  onSend: (text: string) => void;
}) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex-1 overflow-y-auto pr-2 space-y-8 scroll-smooth pb-10">
        <AnimatePresence initial={false}>
          {messages.map((m) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={cn(
                "max-w-[85%] rounded-[1.5rem] p-5 shadow-sm group relative",
                m.role === 'user' 
                ? 'bg-indigo-600 text-white font-medium' 
                : 'bg-[#2f2f2f] border border-white/10 text-[#ECECF1]'
              )}>
                {m.role === 'assistant' && (
                  <div className="flex items-center gap-2 mb-3">
                     <div className="p-1.5 bg-indigo-500 rounded-lg text-white">
                        <Sparkles className="w-3 h-3" />
                     </div>
                     <span className="text-[10px] font-bold uppercase tracking-widest text-white/30">Nivesh Copilot</span>
                  </div>
                )}
                
                <div className="text-[15px] leading-relaxed whitespace-pre-wrap font-medium">
                  {m.content}
                </div>

                <div className="mt-4 flex items-center justify-between">
                   <span className={cn("text-[9px] font-bold uppercase tracking-wider", m.role === 'user' ? 'text-white/50' : 'text-white/20')}>
                      {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                   </span>
                   <div className="flex gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-1 hover:text-white transition-colors"><Trash2 className="w-3 h-3" /></button>
                      <button className="p-1 hover:text-white transition-colors"><Share2 className="w-3 h-3" /></button>
                   </div>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
}
