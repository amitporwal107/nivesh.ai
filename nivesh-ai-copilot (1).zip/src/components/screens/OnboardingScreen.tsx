/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, 
  Zap, 
  Briefcase, 
  TrendingUp, 
  ArrowRight, 
  CheckCircle2, 
  Smartphone,
  Globe,
  MessageSquare,
  BarChart3,
  Mail,
  Lock,
  Upload,
  Link,
  ChevronRight,
  Info,
  Loader2,
  FileText
} from 'lucide-react';
import { Persona } from '../../types';
import { cn } from '../../lib/utils';
import { uploadCasFile, syncGmailCas } from '../../services/aiService';

type OnboardingStep = 'WELCOME' | 'OTP' | 'DATA_SYNC' | 'CONSENT' | 'PARSING_RESULT';

export default function OnboardingScreen({ 
  persona, 
  onComplete 
}: { 
  persona: Persona; 
  onComplete: () => void;
}) {
  const [currentStep, setCurrentStep] = useState<OnboardingStep>('WELCOME');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [dataMethod, setDataMethod] = useState<'CAS' | 'BROKER' | null>(null);
  const [casSource, setCasSource] = useState<'GMAIL' | 'NSDL' | 'CDSL' | null>(null);
  const [consents, setConsents] = useState({ data: false, terms: false, advisory: false });
  const [isSyncing, setIsSyncing] = useState(false);
  const [parsedData, setParsedData] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Google Login Hook simulation
  const handleGmailLogin = () => {
    setIsSyncing(true);
    // @ts-ignore
    const client = google.accounts.oauth2.initTokenClient({
      client_id: (import.meta as any).env.VITE_GOOGLE_CLIENT_ID || 'GOOGLE_CLIENT_ID_PLACEHOLDER',
      scope: 'https://www.googleapis.com/auth/gmail.readonly',
      callback: async (response: any) => {
        if (response.access_token) {
          const result = await syncGmailCas(response.access_token);
          if (result && result.success) {
            setParsedData(result);
            setCurrentStep('PARSING_RESULT');
          }
        }
        setIsSyncing(false);
      },
    });
    client.requestAccessToken();
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsSyncing(true);
      const result = await uploadCasFile(file);
      if (result && result.success) {
        setParsedData(result);
        setCurrentStep('PARSING_RESULT');
      }
      setIsSyncing(false);
    }
  };

  const getWelcomeContent = () => {
    switch (persona) {
      case Persona.TRADER:
        return {
          title: 'Neural Terminal Calibration',
          desc: 'Before accessing the high-frequency alpha signals, we need to verify your credentials and sync your primary trading accounts.',
          icon: Zap,
          color: 'bg-amber-50 text-amber-600'
        };
      case Persona.MFD:
      case Persona.ADVISOR:
        return {
          title: 'Practice Digitalization',
          desc: 'Onboard your practice to Nivesh AI. We will help you sync client portfolios and establish a secure advisory perimeter.',
          icon: Globe,
          color: 'bg-indigo-50 text-indigo-600'
        };
      default:
        return {
          title: 'Welcome to Nivesh AI',
          desc: 'Your journey towards neural wealth management begins with a secure setup of your financial identity.',
          icon: Briefcase,
          color: 'bg-emerald-50 text-emerald-600'
        };
    }
  };

  const welcome = getWelcomeContent();

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    
    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const isOtpComplete = otp.every(v => v !== '');
  const isConsentComplete = consents.data && consents.terms;

  return (
    <div className="fixed inset-0 bg-white z-[60] flex flex-col items-center justify-center p-6 sm:p-12 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-50 rounded-full blur-3xl -mr-48 -mt-48 opacity-50" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-50 rounded-full blur-3xl -ml-48 -mb-48 opacity-50" />

      <div className="max-w-md w-full relative z-10 flex flex-col items-center">
        {/* Progress Timeline */}
        <div className="flex items-center justify-center gap-2 mb-12 w-full px-8">
          {['WELCOME', 'OTP', 'DATA_SYNC', 'CONSENT'].map((s, i) => (
            <div key={s} className="flex-1 flex items-center gap-2">
              <div className={cn(
                "w-2 h-2 rounded-full transition-all duration-500",
                (currentStep === s || (currentStep === 'PARSING_RESULT' && s === 'DATA_SYNC')) ? "bg-indigo-600 scale-125" : 
                ['WELCOME', 'OTP', 'DATA_SYNC', 'CONSENT'].indexOf(currentStep as any) > i || currentStep === 'PARSING_RESULT' ? "bg-emerald-500" : "bg-slate-200"
              )} />
              {i < 3 && <div className="flex-1 h-0.5 bg-slate-100" />}
            </div>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {currentStep === 'WELCOME' && (
            <motion.div
              key="welcome"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="text-center"
            >
              <div className={cn("w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-lg rotate-3", welcome.color)}>
                <welcome.icon className="w-10 h-10" />
              </div>
              <h2 className="text-3xl font-bold text-slate-900 tracking-tight mb-4">{welcome.title}</h2>
              <p className="text-slate-500 font-medium leading-relaxed mb-10">{welcome.desc}</p>
              <button
                onClick={() => setCurrentStep('DATA_SYNC')}
                className="w-full h-14 bg-slate-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition-all active:scale-[0.98]"
              >
                Secure Verification <ArrowRight className="w-5 h-5" />
              </button>
            </motion.div>
          )}

          {currentStep === 'OTP' && (
            <motion.div
              key="otp"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="w-full"
            >
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Verify Identity</h2>
              <p className="text-sm text-slate-500 mb-8">We've sent a 6-digit secure code to your registered mobile and email.</p>
              
              <div className="flex justify-between gap-2 mb-8">
                {otp.map((digit, i) => (
                  <input
                    key={i}
                    id={`otp-${i}`}
                    type="text"
                    value={digit}
                    onChange={(e) => handleOtpChange(i, e.target.value)}
                    className="w-12 h-14 bg-slate-50 border-2 border-slate-100 rounded-xl text-center text-xl font-bold focus:border-indigo-500 outline-none transition-colors"
                  />
                ))}
              </div>

              <button
                disabled={!isOtpComplete}
                onClick={() => setCurrentStep('DATA_SYNC')}
                className={cn(
                  "w-full h-14 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-[0.98]",
                  isOtpComplete ? "bg-slate-900 text-white shadow-lg shadow-slate-100" : "bg-slate-100 text-slate-400 cursor-not-allowed"
                )}
              >
                Continue <ArrowRight className="w-5 h-5" />
              </button>
              <button onClick={() => setOtp(['', '', '', '', '', ''])} className="w-full mt-4 text-xs font-bold text-indigo-600 uppercase tracking-widest hover:underline">
                Resend Code
              </button>
            </motion.div>
          )}

          {currentStep === 'DATA_SYNC' && (
            <motion.div
              key="data"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="w-full"
            >
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Connect Portfolio</h2>
              <p className="text-sm text-slate-500 mb-6">Choose how Nivesh should ingest your holding data.</p>
              
              <div className="space-y-3 mb-8">
                <button 
                  onClick={() => setDataMethod('CAS')}
                  className={cn(
                    "w-full p-4 rounded-2xl border flex items-center gap-4 transition-all text-left group",
                    dataMethod === 'CAS' ? "bg-indigo-50 border-indigo-200" : "bg-white border-slate-100 hover:border-indigo-100"
                  )}
                >
                  <div className={cn("p-2 rounded-xl", dataMethod === 'CAS' ? "bg-indigo-600 text-white" : "bg-slate-50 text-slate-400 group-hover:text-indigo-600")}>
                    <Upload className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-slate-800 text-sm">Upload CAS Statement</p>
                    <p className="text-[10px] text-slate-400 font-medium">Automatic PDF parsing (NSDL/CDSL)</p>
                  </div>
                  {dataMethod === 'CAS' && <CheckCircle2 className="w-5 h-5 text-indigo-600" />}
                </button>

                <button 
                  onClick={() => setDataMethod('BROKER')}
                  className={cn(
                    "w-full p-4 rounded-2xl border flex items-center gap-4 transition-all text-left group",
                    dataMethod === 'BROKER' ? "bg-indigo-50 border-indigo-200" : "bg-white border-slate-100 hover:border-indigo-100"
                  )}
                >
                  <div className={cn("p-2 rounded-xl", dataMethod === 'BROKER' ? "bg-indigo-600 text-white" : "bg-slate-50 text-slate-400 group-hover:text-indigo-600")}>
                    <Link className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-slate-800 text-sm">Direct Broker Sync</p>
                    <p className="text-[10px] text-slate-400 font-medium">Connect via API (Zerodha, Upstox, etc.)</p>
                  </div>
                  {dataMethod === 'BROKER' && <CheckCircle2 className="w-5 h-5 text-indigo-600" />}
                </button>
              </div>

              {dataMethod === 'CAS' && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} className="mb-8 space-y-4">
                  <div className="grid grid-cols-3 gap-2">
                    {['GMAIL', 'NSDL', 'CDSL'].map(s => (
                      <button 
                        key={s}
                        onClick={() => {
                          setCasSource(s as any);
                          if (s === 'GMAIL') handleGmailLogin();
                        }}
                        className={cn(
                          "py-2 text-[10px] font-bold border rounded-lg transition-all flex items-center justify-center gap-2",
                          casSource === s ? "bg-slate-900 text-white border-slate-900" : "bg-slate-50 border-slate-100 text-slate-400"
                        )}
                      >
                        {s === 'GMAIL' && isSyncing && casSource === 'GMAIL' ? <Loader2 className="w-3 h-3 animate-spin" /> : s}
                      </button>
                    ))}
                  </div>
                  
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept=".pdf" 
                    onChange={handleFileUpload} 
                  />
                  
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl p-6 text-center cursor-pointer hover:bg-slate-100 transition-colors group"
                  >
                    {isSyncing && casSource !== 'GMAIL' ? (
                      <Loader2 className="w-8 h-8 text-indigo-500 mx-auto mb-2 animate-spin" />
                    ) : (
                      <Upload className="w-8 h-8 text-slate-300 mx-auto mb-2 group-hover:text-indigo-400 transition-colors" />
                    )}
                    <p className="text-xs font-bold text-slate-500">Drop your CAS PDF here</p>
                    <p className="text-[10px] text-slate-400">Statement must be password protected</p>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      type="password" 
                      placeholder="Enter PDF Password" 
                      className="w-full h-11 bg-slate-50 border border-slate-100 rounded-xl pl-10 pr-4 text-sm font-medium outline-none focus:border-indigo-200"
                    />
                  </div>
                </motion.div>
              )}

              <button
                disabled={!dataMethod || (dataMethod === 'CAS' && !casSource) || isSyncing}
                onClick={() => setCurrentStep('CONSENT')}
                className={cn(
                  "w-full h-14 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-[0.98]",
                  dataMethod ? "bg-slate-900 text-white shadow-lg shadow-slate-100" : "bg-slate-100 text-slate-400 cursor-not-allowed"
                )}
              >
                {dataMethod === 'BROKER' ? 'Select Broker' : 'Verify & Continue'}
                <ArrowRight className="w-5 h-5" />
              </button>
            </motion.div>
          )}

          {currentStep === 'PARSING_RESULT' && (
            <motion.div
              key="result"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="w-full"
            >
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 className="w-8 h-8 text-emerald-600" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 text-center mb-2">Sync Successful</h2>
              <p className="text-sm text-slate-500 text-center mb-8">Nivesh Alpha AI has ingested your {parsedData.holdings.length} holdings from {parsedData.source}.</p>
              
              <div className="bg-slate-50 rounded-2xl p-4 mb-8 max-h-[200px] overflow-y-auto space-y-2">
                {parsedData.holdings.map((h: any, i: number) => (
                  <div key={i} className="flex items-center justify-between p-2 bg-white rounded-lg border border-slate-100">
                    <div>
                      <p className="text-[10px] font-bold text-slate-800">{h.name}</p>
                      <p className="text-[9px] text-slate-400">Units: {h.units}</p>
                    </div>
                    <p className="text-[10px] font-black text-emerald-600 italic">₹{h.value.toLocaleString()}</p>
                  </div>
                ))}
              </div>

              <button
                onClick={() => setCurrentStep('CONSENT')}
                className="w-full h-14 bg-slate-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition-all shadow-lg active:scale-[0.98]"
              >
                Continue to Consent <ArrowRight className="w-5 h-5" />
              </button>
            </motion.div>
          )}

          {currentStep === 'CONSENT' && (
            <motion.div
              key="consent"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="w-full"
            >
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Final Consent</h2>
              <p className="text-sm text-slate-500 mb-8">Nivesh AI requires your explicit permission to process data and provide advisory services.</p>
              
              <div className="space-y-4 mb-10">
                {[
                  { key: 'data', label: 'Data Usage Permission', desc: 'Allow Nivesh to analyze my CAS and broker data for rebalancing.' },
                  { key: 'terms', label: 'Terms of Service', desc: 'I agree to the Enterprise Master Service Agreement.' },
                  { key: 'advisory', label: 'AI Advisory Consent', desc: 'Understand that AI insights are subject to market risks.' },
                ].map(item => (
                  <button 
                    key={item.key}
                    onClick={() => setConsents(prev => ({ ...prev, [item.key]: !prev[item.key as keyof typeof consents] }))}
                    className="flex items-start gap-4 text-left group"
                  >
                    <div className={cn(
                      "w-5 h-5 rounded border-2 shrink-0 transition-all flex items-center justify-center",
                      consents[item.key as keyof typeof consents] ? "bg-indigo-600 border-indigo-600" : "border-slate-200"
                    )}>
                      {consents[item.key as keyof typeof consents] && <CheckCircle2 className="w-4 h-4 text-white" />}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-800 leading-none mb-1">{item.label}</p>
                      <p className="text-xs text-slate-400 font-medium">{item.desc}</p>
                    </div>
                  </button>
                ))}
              </div>

              <div className="bg-amber-50 rounded-xl p-4 mb-8 flex gap-3 text-amber-800">
                <Info className="w-5 h-5 shrink-0" />
                <p className="text-[10px] font-bold leading-relaxed">
                  NOTE: By clicking the button below, you confirm that you have read and understood the risk disclosure documents related to Neural Advisory.
                </p>
              </div>

              <button
                disabled={!isConsentComplete}
                onClick={onComplete}
                className={cn(
                  "w-full h-14 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-[0.98]",
                  isConsentComplete ? "bg-slate-900 text-white shadow-lg shadow-slate-100" : "bg-slate-100 text-slate-400 cursor-not-allowed"
                )}
              >
                Finalize Onboarding <ArrowRight className="w-5 h-5" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="mt-8 flex items-center justify-center gap-2 text-slate-400">
          <Shield className="w-4 h-4 text-emerald-500" />
          <span className="text-[10px] font-bold uppercase tracking-widest leading-none">ISO 27001 Certified Security</span>
        </div>
      </div>
    </div>
  );
}

