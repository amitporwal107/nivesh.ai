/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Users, 
  User, 
  Heart, 
  TrendingUp, 
  ArrowUpRight,
  ShieldCheck,
  Plus,
  Share2,
  PieChart as PieIcon
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { Persona } from '../../types';
import { cn } from '../../lib/utils';

const DATA = [
  { name: 'Amit (Self)', value: 45, color: '#4F46E5' },
  { name: 'Sneha (Spouse)', value: 30, color: '#10B981' },
  { name: 'Parents', value: 25, color: '#F59E0B' },
];

export default function FamilyDashboard({ persona }: { persona: Persona }) {
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'MEMBERS'>('OVERVIEW');

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Family Wealth Hub</h2>
          <p className="text-slate-500 font-medium tracking-tight">Consolidated view of all linked family portfolios.</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="p-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 transition-colors">
            <Share2 className="w-5 h-5 text-slate-500" />
          </button>
          <button className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-md hover:bg-indigo-700 transition-all">
            <Plus className="w-4 h-4" /> Link Member
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="dashboard-card p-6 bg-gradient-to-br from-indigo-50/50 to-white">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Consolidated Wealth</p>
              <h3 className="text-3xl font-bold text-slate-900 mb-2">₹1.42 Cr</h3>
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-600">
                <ArrowUpRight className="w-4 h-4" /> +₹12.4L (This Year)
              </div>
            </div>
            <div className="dashboard-card p-6">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Family Health Score</p>
              <div className="flex items-end gap-3 mb-2">
                 <h3 className="text-3xl font-bold text-slate-900">82</h3>
                 <span className="text-xs font-bold text-slate-400 mb-1">/ 100</span>
              </div>
              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                <div className="bg-emerald-500 h-full w-[82%]" />
              </div>
            </div>
          </div>

          <div className="dashboard-card p-6">
             <h4 className="font-bold text-slate-900 mb-6 flex items-center gap-2">
               <PieIcon className="w-5 h-5 text-indigo-600" />
               Wealth Distribution
             </h4>
             <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={DATA}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {DATA.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
             </div>
             <div className="grid grid-cols-3 gap-4 mt-6">
                {DATA.map(item => (
                  <div key={item.name} className="text-center">
                    <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">{item.name}</p>
                    <div className="flex items-center justify-center gap-2">
                       <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                       <span className="text-sm font-bold text-slate-800">{item.value}%</span>
                    </div>
                  </div>
                ))}
             </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="dashboard-card p-6">
             <h4 className="font-bold text-slate-900 mb-4">Linked Members</h4>
             <div className="space-y-4">
                {[
                  { name: 'Amit Sharma', role: 'Self/Head', assets: '₹64L', color: 'bg-indigo-100 text-indigo-600' },
                  { name: 'Sneha Sharma', role: 'Spouse', assets: '₹42L', color: 'bg-emerald-100 text-emerald-600' },
                  { name: 'Vijay Sharma', role: 'Father', assets: '₹36L', color: 'bg-amber-100 text-amber-600' },
                ].map(member => (
                  <div key={member.name} className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100">
                    <div className={cn("w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs", member.color)}>
                       {member.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-slate-900 truncate">{member.name}</p>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{member.role}</p>
                    </div>
                    <p className="text-sm font-bold text-slate-900">{member.assets}</p>
                  </div>
                ))}
             </div>
             <button className="w-full mt-6 py-2.5 rounded-xl border border-slate-100 text-xs font-bold text-slate-500 uppercase tracking-widest hover:bg-slate-50 transition-all">
                Manage Permissions
             </button>
          </div>

          <div className="bg-indigo-600 rounded-[20px] p-6 text-white text-center">
             <Users className="w-10 h-10 mx-auto mb-4 opacity-50" />
             <h4 className="text-lg font-bold mb-2">Family Protection</h4>
             <p className="text-indigo-100 text-xs font-medium mb-6">Consolidated insurance cover of ₹5.0 Cr across all members.</p>
             <button className="w-full py-2.5 bg-white text-indigo-600 rounded-xl font-bold text-sm hover:bg-indigo-50 transition-all">
                Review Coverage
             </button>
          </div>
        </div>
      </div>
    </div>
  );
}
