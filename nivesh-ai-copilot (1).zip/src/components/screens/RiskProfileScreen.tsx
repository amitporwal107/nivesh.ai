/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, 
  TrendingUp, 
  ArrowRight,
  Target,
  CheckCircle2,
  ChevronLeft,
  Info,
  Clock,
  PieChart,
  Brain
} from 'lucide-react';
import { Persona } from '../../types';
import { cn } from '../../lib/utils';

interface Question {
  id: number;
  text: string;
  category: 'stability' | 'goals' | 'attitude' | 'knowledge';
  options: { text: string; score: number }[];
}

const QUESTIONS: Question[] = [
  {
    id: 1,
    text: 'Age Group',
    category: 'stability',
    options: [
      { text: 'Below 30 years', score: 4 },
      { text: '30–45 years', score: 3 },
      { text: '46–60 years', score: 2 },
      { text: 'Above 60 years', score: 1 },
    ],
  },
  {
    id: 2,
    text: 'Marital Status',
    category: 'stability',
    options: [
      { text: 'Single', score: 4 },
      { text: 'Married with no dependents', score: 3 },
      { text: 'Married with dependents', score: 2 },
      { text: 'Retired', score: 1 },
    ],
  },
  {
    id: 3,
    text: 'Number of Financial Dependents',
    category: 'stability',
    options: [
      { text: 'None', score: 4 },
      { text: '1–2', score: 3 },
      { text: '3–4', score: 2 },
      { text: 'More than 4', score: 1 },
    ],
  },
  {
    id: 4,
    text: 'Employment Type',
    category: 'stability',
    options: [
      { text: 'Salaried', score: 3 },
      { text: 'Self-employed', score: 3 },
      { text: 'Business owner', score: 4 },
      { text: 'Retired', score: 1 },
    ],
  },
  {
    id: 5,
    text: 'Annual Household Income',
    category: 'stability',
    options: [
      { text: 'Less than ₹5 lakh', score: 1 },
      { text: '₹5–15 lakh', score: 2 },
      { text: '₹15–50 lakh', score: 3 },
      { text: 'More than ₹50 lakh', score: 4 },
    ],
  },
  {
    id: 6,
    text: 'Income Stability',
    category: 'stability',
    options: [
      { text: 'Highly stable and predictable', score: 4 },
      { text: 'Mostly stable', score: 3 },
      { text: 'Somewhat variable', score: 2 },
      { text: 'Highly irregular', score: 1 },
    ],
  },
  {
    id: 7,
    text: 'Emergency Fund Availability',
    category: 'stability',
    options: [
      { text: 'Less than 3 months of expenses', score: 1 },
      { text: '3–6 months', score: 2 },
      { text: '6–12 months', score: 3 },
      { text: 'More than 12 months', score: 4 },
    ],
  },
  {
    id: 8,
    text: 'Existing Debt Obligations',
    category: 'stability',
    options: [
      { text: 'Very high EMI burden', score: 1 },
      { text: 'Moderate EMI burden', score: 2 },
      { text: 'Low EMI burden', score: 3 },
      { text: 'No debt', score: 4 },
    ],
  },
  {
    id: 9,
    text: 'Primary Investment Objective',
    category: 'goals',
    options: [
      { text: 'Capital preservation', score: 1 },
      { text: 'Regular income', score: 2 },
      { text: 'Wealth creation', score: 3 },
      { text: 'Maximum capital appreciation', score: 4 },
    ],
  },
  {
    id: 10,
    text: 'Investment Horizon',
    category: 'goals',
    options: [
      { text: 'Less than 3 years', score: 1 },
      { text: '3–5 years', score: 2 },
      { text: '5–10 years', score: 3 },
      { text: 'More than 10 years', score: 4 },
    ],
  },
  {
    id: 11,
    text: 'Experience with Investments',
    category: 'knowledge',
    options: [
      { text: 'Savings account / Fixed deposits only', score: 1 },
      { text: 'Mutual funds', score: 2 },
      { text: 'Stocks', score: 3 },
      { text: 'Derivatives / Active trading', score: 4 },
    ],
  },
  {
    id: 12,
    text: 'Knowledge of Financial Markets',
    category: 'knowledge',
    options: [
      { text: 'Very limited', score: 1 },
      { text: 'Basic understanding', score: 2 },
      { text: 'Good understanding', score: 3 },
      { text: 'Advanced knowledge', score: 4 },
    ],
  },
  {
    id: 13,
    text: 'Reaction to a 20% Portfolio Decline',
    category: 'attitude',
    options: [
      { text: 'Sell all investments', score: 1 },
      { text: 'Sell some investments', score: 2 },
      { text: 'Hold investments', score: 3 },
      { text: 'Invest more', score: 4 },
    ],
  },
  {
    id: 14,
    text: 'Percentage of Income Available for Investing',
    category: 'knowledge',
    options: [
      { text: 'Less than 10%', score: 1 },
      { text: '10–20%', score: 2 },
      { text: '20–40%', score: 3 },
      { text: 'More than 40%', score: 4 },
    ],
  },
  {
    id: 15,
    text: 'Expected Annual Return',
    category: 'knowledge',
    options: [
      { text: '6–8%', score: 1 },
      { text: '8–12%', score: 2 },
      { text: '12–18%', score: 3 },
      { text: 'Above 18%', score: 4 },
    ],
  },
];

export default function RiskProfileScreen({ 
  persona, 
  onComplete 
}: { 
  persona: Persona; 
  onComplete: (profile: string) => void;
}) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [showResult, setShowResult] = useState(false);

  const currentQuestion = QUESTIONS[currentQuestionIndex];

  const handleSelect = (score: number) => {
    setAnswers(prev => ({ ...prev, [currentQuestion.id]: score }));
    if (currentQuestionIndex < QUESTIONS.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      setShowResult(true);
    }
  };

  const calculateResult = () => {
    // Weighted scoring
    const scoresByCategory = {
      stability: 0,
      goals: 0,
      attitude: 0,
      knowledge: 0
    };

    const countsByCategory = {
      stability: 0,
      goals: 0,
      attitude: 0,
      knowledge: 0
    };

    QUESTIONS.forEach(q => {
      scoresByCategory[q.category] += answers[q.id] || 0;
      countsByCategory[q.category] += 1;
    });

    // Normalize to 1-4 range for each category
    const normalized = {
      stability: scoresByCategory.stability / countsByCategory.stability,
      goals: scoresByCategory.goals / countsByCategory.goals,
      attitude: scoresByCategory.attitude / countsByCategory.attitude,
      knowledge: scoresByCategory.knowledge / countsByCategory.knowledge,
    };

    // Apply weights
    const finalScore = (
      (normalized.stability * 0.25) +
      (normalized.goals * 0.25) +
      (normalized.attitude * 0.30) +
      (normalized.knowledge * 0.20)
    );

    if (finalScore <= 1.5) return { 
      id: 'Conservative', 
      label: 'Conservative', 
      desc: 'Focus on maximum safety and capital preservation.', 
      color: 'text-blue-600 bg-blue-50', 
      icon: Shield,
      allocation: { equity: 25, debt: 55, gold: 10, cash: 10 },
      equitySplit: { large: 100, mid: 0, small: 0, international: 0 }
    };
    if (finalScore <= 2.2) return { 
      id: 'Moderately Conservative', 
      label: 'Moderately Conservative', 
      desc: 'Slightly higher risk for yield while maintaining stability.', 
      color: 'text-indigo-500 bg-indigo-50', 
      icon: Target,
      allocation: { equity: 40, debt: 40, gold: 10, cash: 10 },
      equitySplit: { large: 80, mid: 10, small: 5, international: 5 }
    };
    if (finalScore <= 2.8) return { 
      id: 'Moderate', 
      label: 'Moderate', 
      desc: 'Balanced approach seeking growth over 3-5 years.', 
      color: 'text-indigo-600 bg-indigo-50', 
      icon: PieChart,
      allocation: { equity: 60, debt: 25, gold: 10, cash: 5 },
      equitySplit: { large: 60, mid: 25, small: 10, international: 5 }
    };
    if (finalScore <= 3.5) return { 
      id: 'Aggressive', 
      label: 'Aggressive', 
      desc: 'Focused on wealth creation with tolerance for volatility.', 
      color: 'text-emerald-600 bg-emerald-50', 
      icon: TrendingUp,
      allocation: { equity: 80, debt: 10, gold: 5, cash: 5 },
      equitySplit: { large: 45, mid: 30, small: 15, international: 10 }
    };
    return { 
      id: 'Very Aggressive', 
      label: 'Very Aggressive', 
      desc: 'Maximum growth seeking over long term (10+ years).', 
      color: 'text-amber-600 bg-amber-50', 
      icon: Brain,
      allocation: { equity: 95, debt: 0, gold: 2, cash: 3 },
      equitySplit: { large: 35, mid: 30, small: 20, international: 15 }
    };
  };

  const result = calculateResult();

  if (showResult) {
    return (
      <div className="fixed inset-0 bg-white z-[70] flex flex-col items-center justify-center p-6 md:p-12 overflow-y-auto">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="max-w-2xl w-full text-center"
        >
          <div className={cn("inline-flex p-6 rounded-[2.5rem] mb-8 shadow-xl rotate-3", result.color)}>
            <result.icon className="w-12 h-12" />
          </div>
          <h2 className="text-sm font-bold text-slate-400 uppercase tracking-[0.2em] mb-2">Neural Risk Profile</h2>
          <h3 className="text-4xl font-bold text-slate-900 tracking-tight mb-8">{result.label}</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10 text-left">
            <div className="dashboard-card p-6">
              <h4 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                <PieChart className="w-4 h-4 text-indigo-600" />
                Asset Allocation
              </h4>
              <div className="space-y-4">
                {[
                  { label: 'Equity', value: result.allocation.equity, color: 'bg-indigo-600' },
                  { label: 'Debt', value: result.allocation.debt, color: 'bg-emerald-500' },
                  { label: 'Gold', value: result.allocation.gold, color: 'bg-amber-500' },
                  { label: 'Cash', value: result.allocation.cash, color: 'bg-slate-300' },
                ].map(item => (
                  <div key={item.label} className="space-y-1.5">
                    <div className="flex justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                      <span>{item.label}</span>
                      <span>{item.value}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                      <div className={cn("h-full rounded-full transition-all duration-1000", item.color)} style={{ width: `${item.value}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="dashboard-card p-6">
              <h4 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                <Brain className="w-4 h-4 text-emerald-600" />
                Equity Breakdown
              </h4>
              <div className="space-y-4">
                {[
                  { label: 'Large Cap', value: result.equitySplit.large, color: 'bg-indigo-400' },
                  { label: 'Mid Cap', value: result.equitySplit.mid, color: 'bg-indigo-500' },
                  { label: 'Small Cap', value: result.equitySplit.small, color: 'bg-indigo-600' },
                  { label: 'International', value: result.equitySplit.international, color: 'bg-indigo-700' },
                ].map(item => (
                  <div key={item.label} className="space-y-1.5">
                    <div className="flex justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                      <span>{item.label}</span>
                      <span>{item.value}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-50 rounded-full overflow-hidden">
                      <div className={cn("h-full rounded-full transition-all duration-1000", item.color)} style={{ width: `${item.value}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-amber-50 rounded-2xl p-5 mb-10 flex gap-4 text-left border border-amber-100">
            <Info className="w-6 h-6 text-amber-600 shrink-0" />
            <div>
              <p className="text-xs font-bold text-amber-900 uppercase tracking-widest mb-1">AI Rebalancing Policy</p>
              <p className="text-xs text-amber-800 leading-relaxed font-medium">
                Review every 6–12 months. Automatic alerts when any asset class deviates by more than 5%.
                Current recommendation optimized for <b>{result.label}</b> profile.
              </p>
            </div>
          </div>

          <button
            onClick={() => onComplete(result.id)}
            className="w-full h-14 bg-slate-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition-all active:scale-[0.98] shadow-lg shadow-slate-200"
          >
            Deploy My Strategy <ArrowRight className="w-5 h-5" />
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-white z-[70] flex flex-col p-6 md:p-12">
      <div className="max-w-xl w-full mx-auto flex-1 flex flex-col">
        <header className="mb-12">
          <div className="flex items-center justify-between mb-8">
            <button 
              onClick={() => currentQuestionIndex > 0 && setCurrentQuestionIndex(prev => prev - 1)}
              className={cn(
                "p-2 rounded-lg hover:bg-slate-100 transition-colors",
                currentQuestionIndex === 0 && "opacity-0 pointer-events-none"
              )}
            >
              <ChevronLeft className="w-6 h-6 text-slate-600" />
            </button>
            <div className="flex flex-col items-center gap-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">{currentQuestionIndex + 1} of 15</span>
              <div className="flex gap-1">
                {Array.from({ length: 15 }).map((_, i) => (
                  <div key={i} className={cn(
                    "w-3 h-1 rounded-full transition-all duration-500",
                    i === currentQuestionIndex ? "bg-indigo-600 w-6" : 
                    i < currentQuestionIndex ? "bg-emerald-400" : "bg-slate-100"
                  )} />
                ))}
              </div>
            </div>
            <div className="w-10" />
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={currentQuestionIndex}
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="text-center"
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-100 rounded-full text-slate-600 text-[10px] font-bold uppercase tracking-widest mb-6">
                {currentQuestion.category.replace('_', ' ')} Assessment
              </div>
              <h2 className="text-3xl font-bold text-slate-900 tracking-tight leading-tight">
                {currentQuestion.text}
              </h2>
            </motion.div>
          </AnimatePresence>
        </header>

        <div className="flex-1 space-y-3">
          {currentQuestion.options.map((option, idx) => (
            <button
              key={idx}
              onClick={() => handleSelect(option.score)}
              className="w-full p-6 text-left border-2 border-slate-100 rounded-2xl hover:border-indigo-600 hover:bg-indigo-50/10 transition-all flex items-center justify-between group active:scale-[0.99]"
            >
              <span className="font-bold text-slate-700 group-hover:text-indigo-700">{option.text}</span>
              <div className="w-6 h-6 rounded-full border-2 border-slate-200 flex items-center justify-center group-hover:border-indigo-600 transition-colors">
                 <div className="w-2.5 h-2.5 bg-indigo-600 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </button>
          ))}
        </div>

        <footer className="mt-12 pt-8 border-t border-slate-100">
          <div className="flex gap-4 items-start p-4 bg-slate-50 rounded-2xl text-slate-500">
            <Info className="w-5 h-5 shrink-0 mt-0.5" />
            <p className="text-xs font-medium leading-relaxed">
              Our Neural Risk Engine evaluates both your financial capacity and psychological temperament to suggest an optimal model portfolio.
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}

