/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Target, 
  Plus, 
  Home, 
  GraduationCap, 
  Car, 
  Plane, 
  Briefcase,
  ChevronRight,
  TrendingUp,
  Clock,
  CheckCircle2
} from 'lucide-react';
import { Persona } from '../../types';
import { cn } from '../../lib/utils';

export default function GoalSettingScreen({ persona }: { persona: Persona }) {
  const isBusiness = persona === Persona.MFD || persona === Persona.ADVISOR;

  const investorGoals = [
    { id: 1, title: 'Retirement 2045', target: '₹8.0 Cr', current: '₹1.2 Cr', progress: 15, icon: Briefcase, color: 'text-indigo-600 bg-indigo-50' },
    { id: 2, title: 'Child Education', target: '₹1.5 Cr', current: '₹45L', progress: 30, icon: GraduationCap, color: 'text-emerald-600 bg-emerald-50' },
    { id: 3, title: 'New Primary Home', target: '₹2.5 Cr', current: '₹15L', progress: 6, icon: Home, color: 'text-blue-600 bg-blue-50' },
  ];

  const clientGoals = [
    { id: 1, client: 'Rajesh Varma', goal: 'Wealth Growth', status: 'Priority', count: 4, icon: Target, color: 'text-indigo-600 bg-indigo-50' },
    { id: 2, client: 'Suman Rao', goal: 'Retirement Planning', status: 'On Track', count: 2, icon: Briefcase, color: 'text-emerald-600 bg-emerald-50' },
    { id: 3, client: 'Priya Singh', goal: 'Global Education', status: 'Needs Action', count: 1, icon: GraduationCap, color: 'text-amber-600 bg-amber-50' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
            {isBusiness ? 'Client Goals Tracking' : 'Financial Milestones'}
          </h2>
          <p className="text-slate-500 font-medium tracking-tight">
            {isBusiness ? 'Monitor and manage goals across your client practice.' : 'Define and track your primary financial life objectives.'}
          </p>
        </div>
        <button className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-md hover:bg-indigo-700 transition-all active:scale-95">
          <Plus className="w-4 h-4" /> {isBusiness ? 'Add Client Goal' : 'New Goal'}
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { label: isBusiness ? 'Active Client Goals' : 'Total Goal Target', value: isBusiness ? '42' : '₹12.0 Cr', icon: Target },
          { label: isBusiness ? 'Goals on Track' : 'Current Progress', value: isBusiness ? '38' : '₹1.8 Cr', icon: CheckCircle2 },
          { label: isBusiness ? 'New Goals (MoM)' : 'Neural Projection', value: isBusiness ? '+12' : '₹13.4 Cr', icon: TrendingUp },
        ].map((stat) => (
          <div key={stat.label} className="dashboard-card p-5">
            <div className="flex items-center justify-between mb-4">
               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{stat.label}</p>
               <stat.icon className="w-4 h-4 text-indigo-500" />
            </div>
            <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-bold text-slate-900">Active {isBusiness ? 'Client Priorities' : 'Portfolio Goals'}</h3>
        <div className="grid grid-cols-1 gap-3">
          {(isBusiness ? clientGoals : investorGoals).map((goal: any) => (
            <div key={goal.id} className="dashboard-card p-5 flex items-center gap-6 group hover:border-indigo-400 transition-all">
              <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center shrink-0", goal.color)}>
                <goal.icon className="w-7 h-7" />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-slate-900 truncate">{isBusiness ? goal.client : goal.title}</h4>
                  <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest bg-indigo-50 px-2 py-1 rounded-md">
                     {isBusiness ? goal.status : `${goal.progress}% Linked`}
                  </span>
                </div>
                
                {isBusiness ? (
                   <p className="text-sm text-slate-500 font-medium">{goal.goal} • {goal.count} sub-goals</p>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs font-bold text-slate-400 uppercase tracking-tight">
                        <span>{goal.current}</span>
                        <span>Target: {goal.target}</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${goal.progress}%` }}
                        className="bg-indigo-600 h-full rounded-full"
                      />
                    </div>
                  </div>
                )}
              </div>

              <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-indigo-600 transition-colors" />
            </div>
          ))}
        </div>
      </div>

      {!isBusiness && (
        <div className="bg-slate-900 rounded-[20px] p-6 text-white overflow-hidden relative">
          <div className="relative z-10">
            <h3 className="text-lg font-bold mb-2">AI Optimization Suggestion</h3>
            <p className="text-slate-400 text-sm font-medium mb-6">Redirecting ₹12,000 monthly from 'Idle Assets' to 'Child Education' will reach target 14 months early.</p>
            <button className="px-6 py-2.5 bg-amber-500 text-slate-900 rounded-xl font-bold text-sm hover:bg-amber-400 transition-all">
               Apply Scenario
            </button>
          </div>
          <Target className="absolute top-0 right-0 w-32 h-32 text-white/5 -mr-8 -mt-8 rotate-12" />
        </div>
      )}
    </div>
  );
}
