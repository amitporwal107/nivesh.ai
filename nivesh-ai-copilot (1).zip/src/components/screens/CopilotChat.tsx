/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Persona, ChatMessage } from '../../types';
import { PERSONA_SUGGESTIONS, PERSONA_TEMPLATES } from '../../constants';
import { getPortfolioScore } from '../../services/aiService';
import { 
  Send, 
  Mic, 
  Paperclip, 
  Sparkles, 
  History,
  ArrowUpRight,
  ShieldCheck,
  Zap,
  Info,
  TrendingUp,
  User,
  LayoutDashboard,
  CheckCircle2,
  ChevronRight,
  TrendingDown,
  Target,
  BarChart3,
  Search
} from 'lucide-react';
import { cn } from '../../lib/utils';

interface CopilotChatProps {
  persona: Persona;
  messages: ChatMessage[];
  setMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
}

export default function CopilotChat({ persona, messages, setMessages }: CopilotChatProps) {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const personaSuggestions = PERSONA_SUGGESTIONS[persona] || PERSONA_SUGGESTIONS[Persona.RETAIL_INVESTOR];
  const template = PERSONA_TEMPLATES[persona] || PERSONA_TEMPLATES[Persona.RETAIL_INVESTOR];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMsg]);
    setInput('');

    // Simulate AI Response with dynamic backend data if relevant
    setTimeout(async () => {
      let finalPayload = template;
      let finalContent = `I've analyzed your request for "${input}". Here's the Nivesh AI insight for your persona as a ${persona}.`;

      if (input.toLowerCase().includes('score') || input.toLowerCase().includes('health') || input.toLowerCase().includes('portfolio')) {
        const backendData = await getPortfolioScore([]);
        if (backendData) {
          finalPayload = {
            ...template,
            heroScore: { label: 'Portfolio Alpha Score', value: backendData.portfolioScore },
            coreMetrics: [
              { label: 'Alpha', value: backendData.metrics.alpha },
              { label: 'Max Drawdown', value: backendData.metrics.drawdown },
              { label: 'Tax Impact', value: backendData.metrics.taxImpact }
            ]
          };
          finalContent = "I've run the V3 Composite Engine against your current holdings. The portfolio alpha remains robust despite recent volatility.";
        }
      }

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: finalContent,
        timestamp: new Date(),
        type: 'template',
        payload: finalPayload
      };
      setMessages(prev => [...prev, aiMsg]);
    }, 1000);
  };

  return (
    <div className="max-w-3xl mx-auto w-full min-h-[calc(100vh-12rem)] flex flex-col pt-10 pb-32">
      {/* Intro section if no real history yet */}
      {messages.length <= 1 && (
        <div className="flex flex-col items-center justify-center mb-12 text-center px-4">
           <div className="w-20 h-20 bg-[#1A1A1A] rounded-[2rem] flex items-center justify-center shadow-2xl border border-white/5 mb-8 relative group">
              <div className="absolute inset-0 bg-indigo-500/20 blur-2xl rounded-full opacity-50 group-hover:opacity-100 transition-opacity" />
              <Sparkles className="w-10 h-10 text-indigo-400 relative z-10" />
           </div>
           <h2 className="text-3xl font-black text-white mb-4 tracking-tighter italic">How can I assist your practice today?</h2>
           <p className="text-white/30 text-sm max-w-sm font-medium mb-12">Nivesh Alpha AI is synced with your client holdings and real-time market order flow.</p>
           
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-2xl">
              {personaSuggestions.map((suggestion, i) => (
                <button
                  key={i}
                  onClick={() => {
                    const userMsg: ChatMessage = {
                      id: Date.now().toString(),
                      role: 'user',
                      content: suggestion,
                      timestamp: new Date()
                    };
                    setMessages(prev => [...prev, userMsg]);
                    
                    // Simulate AI Response (same as handleSend)
                    setTimeout(() => {
                      const aiMsg: ChatMessage = {
                        id: (Date.now() + 1).toString(),
                        role: 'assistant',
                        content: `Analyzing "${suggestion}" for your persona: ${persona}. I'm processing the latest market data and your portfolio state to generate a customized insight...`,
                        timestamp: new Date(),
                        type: 'template',
                        payload: template
                      };
                      setMessages(prev => [...prev, aiMsg]);
                    }, 1000);
                  }}
                  className="p-6 bg-[#1A1A1A] border border-white/5 rounded-3xl text-left hover:border-indigo-500/50 hover:bg-white/[0.02] transition-all group relative overflow-hidden shadow-xl"
                >
                  <div className="absolute top-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity">
                    <ArrowUpRight className="w-4 h-4 text-indigo-400" />
                  </div>
                  <p className="text-sm font-bold text-white/80 pr-4 leading-snug">{suggestion}</p>
                  <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest mt-3">Quick Action</p>
                </button>
              ))}
           </div>
        </div>
      )}

      {/* Chat Messages */}
      <div className="space-y-10">
        <AnimatePresence initial={false}>
          {messages.map((m) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-start gap-5 group"
            >
              <div className={cn(
                "w-10 h-10 rounded-lg flex items-center justify-center shrink-0 border",
                m.role === 'assistant' 
                  ? 'bg-indigo-600/10 text-indigo-400 border-indigo-500/20' 
                  : 'bg-white/10 text-white/40 border-white/5'
              )}>
                {m.role === 'assistant' ? <Sparkles className="w-5 h-5" /> : <User className="w-5 h-5" />}
              </div>
              
              <div className="flex-1 space-y-4 pt-1">
                <div className="flex items-center gap-3">
                   <p className="text-sm font-bold text-white/90">
                     {m.role === 'assistant' ? 'Nivesh AI Copilot' : 'Amit Sharma'}
                   </p>
                   <span className="text-[10px] font-bold text-white/20 uppercase tracking-widest">
                     {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                   </span>
                </div>
                
                <div className={cn(
                  "text-[15px] leading-relaxed font-medium transition-colors",
                  m.role === 'assistant' ? 'text-[#ECECF1]' : 'text-[#ECECF1]/70'
                )}>
                  {m.content}
                </div>

                {m.type === 'template' && m.payload && (
                  <div className="mt-6 space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
                    {/* Hero Score */}
                    <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-6 relative overflow-hidden group">
                      <div className="absolute top-0 right-0 p-4">
                        <div className="bg-indigo-500/20 text-indigo-400 text-[10px] font-black px-2 py-1 rounded-md uppercase tracking-tighter">
                          Confidence: 94%
                        </div>
                      </div>
                      <p className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] mb-2">{m.payload.heroScore.label}</p>
                      <div className="flex items-baseline gap-4">
                        <p className="text-4xl font-black text-white italic">{m.payload.heroScore.value}</p>
                        <div className="h-2 w-32 bg-white/5 rounded-full overflow-hidden">
                          <div className="h-full bg-indigo-500" style={{ width: `${m.payload.heroScore.value}%` }} />
                        </div>
                      </div>
                    </div>

                    {/* Core Metrics */}
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {m.payload.coreMetrics.map((metric: any, i: number) => (
                        <div key={i} className="bg-white/[0.02] border border-white/5 p-4 rounded-xl">
                          <p className="text-[9px] font-bold text-white/20 uppercase tracking-widest mb-1">{metric.label}</p>
                          <p className="text-sm font-black text-white">{metric.value}</p>
                        </div>
                      ))}
                    </div>

                    {/* Key Sections */}
                    <div className="space-y-4">
                      {m.payload.keySections.map((section: any, i: number) => (
                        <div key={i} className="bg-white/[0.01] border border-white/5 rounded-xl p-5">
                          <h4 className="text-[10px] font-black text-white/40 uppercase tracking-widest mb-4 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                            {section.title}
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {section.items.map((item: string, j: number) => (
                              <div key={j} className="flex items-center gap-3 text-sm text-white/70 font-medium">
                                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                                {item}
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Actions */}
                    <div className="flex flex-wrap gap-3 pt-4 border-t border-white/5">
                      {m.payload.actions.map((action: string, i: number) => (
                        <button key={i} className="px-4 py-2 bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 text-[10px] font-black uppercase tracking-widest rounded-lg hover:bg-indigo-600 transition-all hover:text-white">
                          {action}
                        </button>
                      ))}
                      <button className="px-4 py-2 bg-white/5 border border-white/5 text-white/40 text-[10px] font-black uppercase tracking-widest rounded-lg hover:bg-white/10 transition-all">
                        Deep Dive Analysis
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        </div>
    </div>
  );
}
