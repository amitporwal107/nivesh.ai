/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Zap, 
  Search, 
  Filter, 
  Plus, 
  ChevronRight, 
  BarChart3, 
  Play, 
  Shield, 
  Globe,
  TrendingUp,
  Flame,
  Snowflake,
  Wind,
  MessageSquare,
  Sparkles,
  Layers,
  Target,
  Send,
  CheckCircle2,
  ChevronLeft,
  AlertTriangle,
  Clock,
  Briefcase,
  PieChart
} from 'lucide-react';
import { cn } from '../../lib/utils';

type Step = 'Universe' | 'Strategy' | 'Screen' | 'Backtest' | 'Execute';

const STEPS: Step[] = ['Universe', 'Strategy', 'Screen', 'Backtest', 'Execute'];

const UNIVERSES = [
  { id: 1, name: 'IT & Financials', count: 3, status: 'BUILDING', signal: 'Warming up', icon: Globe, trend: 'warming' },
  { id: 2, name: 'Infra Growth', count: 12, status: 'STEADY', signal: 'Neutral flow', icon: Wind, trend: 'neutral' },
  { id: 3, name: 'Green Energy', count: 8, status: 'STRONG', signal: 'High interest', icon: Flame, trend: 'hot' },
  { id: 4, name: 'EV Thematic', count: 10, status: 'BUILDING', signal: 'Warming up', icon: Zap, trend: 'warming' },
  { id: 5, name: 'High Dividend', count: 20, status: 'BUILDING', signal: 'Warming up', icon: Shield, trend: 'warming' },
  { id: 6, name: 'Nifty 200', count: 200, status: 'BUILDING', signal: 'Warming up', icon: Layers, trend: 'warming' },
];

const STRATEGIES = [
  { id: 'no-filter', name: 'No Strategy Filter', desc: 'Screen purely by selected universe — no factor filters applied.', risk: 'Theme Only', icon: Globe },
  { id: 'contrarian', name: 'Contrarian', desc: 'Beaten-down stocks, near 52-week lows, mean reversion', risk: 'Medium-High Risk', icon: Sparkles },
  { id: 'quality', name: 'Deep Fundamental Quality', desc: 'Composite fundamental + operational + financial quality scores', risk: 'Low-Medium Risk', icon: Shield },
  { id: 'value', name: 'Deep Value', desc: 'Low P/E, P/B, high Yield, low debt', risk: 'Medium Risk', icon: Target },
  { id: 'dividend', name: 'Dividend Income', desc: 'High dividend yield, consistent payout, low volatility', risk: 'Low Risk', icon: PieChart },
];

export default function TradeTerminal() {
  const [activeStep, setActiveStep] = useState<Step>('Universe');
  const [isDashboard, setIsDashboard] = useState(false);
  const [activeTab, setActiveTab] = useState<'PUBLIC' | 'MY'>('PUBLIC');
  const [filter, setFilter] = useState('All');
  const [copilotActive, setCopilotActive] = useState(true);
  const [selectedUniverse, setSelectedUniverse] = useState<number | null>(null);
  const [selectedStrategy, setSelectedStrategy] = useState<string | null>(null);
  const [backtestConfig, setBacktestConfig] = useState({
    rebalance: 'Quarterly',
    stocks: 10,
    duration: '1Y',
    hedge: 'None',
    sort: 'Market Cap'
  });

  const nextStep = () => {
    const currentIndex = STEPS.indexOf(activeStep);
    if (currentIndex < STEPS.length - 1) {
      setActiveStep(STEPS[currentIndex + 1]);
    }
  };

  const prevStep = () => {
    const currentIndex = STEPS.indexOf(activeStep);
    if (currentIndex > 0) {
      setActiveStep(STEPS[currentIndex - 1]);
    }
  };

  const currentUniverseData = UNIVERSES.find(u => u.id === selectedUniverse);
  const currentStrategyData = STRATEGIES.find(s => s.id === selectedStrategy);

  if (isDashboard) {
    return (
      <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="flex items-center gap-3 bg-[#1A1A1A] border border-white/5 p-4 rounded-[2rem] shadow-xl">
          <MessageSquare className="w-5 h-5 text-amber-400" />
          <p className="text-xs font-bold text-amber-400/80">Alpha Plan — Unified AI Copilot active for this strategy session</p>
          <button className="ml-auto bg-emerald-500/10 text-emerald-400 text-[10px] font-bold px-4 py-2 rounded-xl border border-emerald-500/20 uppercase tracking-widest">Active Tier</button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
           {[
             { label: 'Portfolio Value', value: '₹9,93,491', color: 'border-l-indigo-500' },
             { label: 'Total Invested', value: '₹10,00,000', color: 'border-l-amber-500' },
             { label: 'Total P&L', value: '-₹6,509', subValue: '-0.65%', color: 'border-l-rose-500', isNegative: true },
             { label: "Today's P&L", value: '₹0', subValue: '+0.00%', color: 'border-l-emerald-500' },
           ].map(stat => (
             <div key={stat.label} className={cn("bg-[#1A1A1A] p-8 rounded-[2rem] border-l-4 border-y border-r border-white/5 shadow-2xl", stat.color)}>
                <p className="text-[10px] font-bold text-white/30 uppercase tracking-[0.2em] mb-4 font-mono">{stat.label}</p>
                <h4 className="text-3xl font-black text-white tracking-tighter mb-2">{stat.value}</h4>
                {stat.subValue && (
                  <p className={cn("text-xs font-bold font-mono tracking-widest", stat.isNegative ? "text-rose-500" : "text-emerald-500")}>{stat.subValue}</p>
                )}
             </div>
           ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-12">
            <div className="bg-[#1A1A1A] border border-white/5 rounded-[3rem] p-10 relative group overflow-hidden shadow-2xl">
               <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-indigo-500/5 rounded-full -mr-[200px] -mt-[200px] blur-[100px]" />
               <div className="relative z-10 flex flex-col md:flex-row justify-between items-start mb-12 gap-6">
                  <div>
                    <span className="text-[10px] font-black text-amber-400 uppercase tracking-[0.3em] font-mono block mb-3">Model Performance</span>
                    <h5 className="text-2xl font-black text-white tracking-tight mb-2">Contrarian — IT & Financials</h5>
                    <p className="text-sm text-white/30 font-medium">Strategy initiated on Oct 12, 2025 • High Conviction</p>
                  </div>
                  <div className="text-right">
                    <p className="text-4xl font-black text-rose-500 tracking-tighter mb-2">-0.65%</p>
                    <div className="px-3 py-1 bg-rose-500/10 text-rose-500 text-[10px] font-bold rounded-lg border border-rose-500/20 uppercase tracking-widest inline-block">
                       Trailing Alpha
                    </div>
                  </div>
               </div>
               
               <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-10 mb-12">
                  <div className="bg-white/5 p-6 rounded-[2rem] border border-white/5">
                    <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-3">Current Net Value</p>
                    <p className="text-2xl font-black text-white tracking-tight">₹9,93,491</p>
                  </div>
                  <div className="bg-white/5 p-6 rounded-[2rem] border border-white/5">
                    <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-3">Principal Capital</p>
                    <p className="text-2xl font-black text-white tracking-tight">₹10,00,000</p>
                  </div>
                  <div className="bg-white/5 p-6 rounded-[2rem] border border-rose-500/10">
                    <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-3">Unrealized P&L</p>
                    <p className="text-2xl font-black text-rose-500 tracking-tight">-₹6,509</p>
                  </div>
               </div>

               <div className="relative z-10 pt-10 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-6">
                  <div className="flex gap-8 text-[11px] font-bold uppercase tracking-widest">
                    <span className="text-white/20">Session <span className="text-emerald-500 ml-1">₹0 (0.00%)</span></span>
                    <span className="text-white/20">Realized <span className="text-rose-500 ml-1">-₹6,509</span></span>
                  </div>
                  <div className="flex items-center gap-3">
                     <div className="text-[10px] font-black text-indigo-400 bg-indigo-400/10 px-4 py-2 rounded-xl border border-indigo-400/20 uppercase tracking-widest">
                        5 Active Orders Pending
                     </div>
                     <button className="px-6 py-3 bg-white text-black font-black text-[11px] rounded-xl uppercase tracking-widest hover:bg-white/90 transition-all">
                        Execute Rebalance
                     </button>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Stepper */}
      <div className="bg-[#1A1A1A] border border-white/5 rounded-[3rem] p-10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-[80px] -ml-32 -mt-32" />
        <div className="flex items-center justify-between max-w-5xl mx-auto relative px-12 z-10">
          {/* Progress Line */}
          <div className="absolute top-1/2 left-[10%] right-[10%] h-[2px] bg-white/5 -translate-y-1/2 -z-0" />
          <div className="absolute top-1/2 left-[10%] right-[10%] h-[2px] bg-gradient-to-r from-amber-400/50 to-indigo-500/20 -translate-y-1/2 -z-0" style={{
            width: `${(STEPS.indexOf(activeStep) / (STEPS.length - 1)) * 80}%`,
            transition: 'width 0.8s cubic-bezier(0.4, 0, 0.2, 1)'
          }} />
          
          {STEPS.map((step, idx) => {
            const isActive = activeStep === step;
            const isCompleted = STEPS.indexOf(activeStep) > idx;
            
            return (
              <div key={step} className="relative z-10 flex flex-col items-center gap-4">
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-500 border-2",
                  isActive ? "bg-amber-400 border-amber-400 text-black shadow-[0_0_30px_rgba(251,191,36,0.3)] rotate-3" : 
                  isCompleted ? "bg-white border-white text-black" : 
                  "bg-[#1A1C20] border-white/5 text-white/20"
                )}>
                  {isCompleted ? <CheckCircle2 className="w-6 h-6" /> : <span className="font-black text-lg">{idx + 1}</span>}
                </div>
                <div className="text-center min-w-[100px]">
                  <p className={cn(
                    "text-[10px] font-black uppercase tracking-[0.2em] leading-none mb-1",
                    isActive ? "text-amber-400" : isCompleted ? "text-white" : "text-white/10"
                  )}>{step}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className={cn(
          "transition-all duration-700 ease-in-out",
          copilotActive ? "lg:col-span-8" : "lg:col-span-12"
        )}>
          {/* Sub-header Controls */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-8 px-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-white/5 flex items-center justify-center border border-white/10 text-[10px] font-black text-white">
                0{STEPS.indexOf(activeStep) + 1}
              </div>
              <p className="text-xs font-black text-white/30 uppercase tracking-[0.3em]">
                {activeStep === 'Universe' && 'Select Digital Stock Universe'}
                {activeStep === 'Strategy' && 'Define Quantitative Rules'}
                {activeStep === 'Screen' && 'Execute Real-time Screening'}
                {activeStep === 'Backtest' && 'Historical Alpha Simulation'}
                {activeStep === 'Execute' && 'Deploy to Broker Engine'}
              </p>
            </div>
            <div className="flex items-center gap-4">
              {activeStep !== 'Universe' && (
                <button onClick={prevStep} className="bg-white/5 border border-white/5 text-white/40 px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-white/10 transition-all">
                  <ChevronLeft className="w-4 h-4" /> Back
                </button>
              )}
              {activeStep !== 'Execute' && (
                <button 
                  onClick={nextStep} 
                  disabled={ (activeStep === 'Universe' && !selectedUniverse) || (activeStep === 'Strategy' && !selectedStrategy) }
                  className={cn(
                    "px-10 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all",
                    ((activeStep === 'Universe' && selectedUniverse) || (activeStep === 'Strategy' && selectedStrategy) || ['Screen', 'Backtest'].includes(activeStep))
                    ? "bg-indigo-600 text-white shadow-2xl shadow-indigo-600/20 hover:scale-[1.02]" 
                    : "bg-white/5 border border-white/5 text-white/10 opacity-50 cursor-not-allowed"
                  )}
                >
                  Proceed <ChevronRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          <AnimatePresence mode="wait">
            {activeStep === 'Universe' && (
              <motion.div key="universe" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                {/* Universe Content */}
                <div className="flex items-center justify-between mb-8">
                  <div className="flex bg-[#1A1A1A] p-1.5 rounded-xl border border-white/5 shadow-inner">
                    <button className={cn("px-6 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all", activeTab === 'PUBLIC' ? "bg-indigo-600 text-white shadow-lg" : "text-white/20 hover:text-white/40")}>
                      Digital Assets
                    </button>
                    <button className="px-6 py-2 rounded-lg text-[10px] font-black text-white/20 uppercase tracking-widest">
                      Custom Curations
                    </button>
                  </div>
                  <button className="bg-white/5 border border-white/10 text-white/60 px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-white/10 transition-all">
                    <Plus className="w-4 h-4" /> New Universe
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {UNIVERSES.map(u => (
                    <button
                      key={u.id}
                      onClick={() => setSelectedUniverse(u.id)}
                      className={cn("p-8 rounded-[2rem] border bg-[#1A1A1A] text-left transition-all relative group shadow-xl", selectedUniverse === u.id ? "border-amber-400 ring-2 ring-amber-400/10" : "border-white/5 hover:border-white/10")}
                    >
                       <div className="flex justify-between mb-6">
                         <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/5 group-hover:bg-white/10 transition-colors">
                           <u.icon className="w-6 h-6 text-white/40" />
                         </div>
                         <div className="text-right">
                            <p className={cn("text-[9px] font-black uppercase tracking-widest", u.status === 'STRONG' ? "text-emerald-400" : "text-amber-400")}>{u.status}</p>
                            <p className="text-[9px] font-black text-white/20 uppercase tracking-tighter mt-1">{u.signal}</p>
                         </div>
                       </div>
                       <h4 className="font-black text-white text-lg mb-2">{u.name}</h4>
                       <p className="text-[10px] text-white/30 font-bold uppercase tracking-tight">{u.count} Assets identified</p>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {activeStep === 'Strategy' && (
              <motion.div key="strategy" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                 <div className="flex bg-[#1A1A1A] p-1.5 rounded-xl border border-white/5 shadow-inner w-fit mb-10">
                    <button className="px-8 py-2 rounded-lg bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest shadow-lg">Public Quantitative 22</button>
                    <button className="px-8 py-2 rounded-lg text-white/20 text-[10px] font-black uppercase tracking-widest">My Algos</button>
                 </div>
                 
                 <div className="bg-[#1A1A1A] border border-white/5 rounded-[2rem] p-8 mb-10 flex items-center gap-8 group hover:border-amber-400/30 transition-all shadow-xl cursor-not-allowed opacity-50">
                    <div className="w-16 h-16 bg-white/5 rounded-[1.5rem] flex items-center justify-center border border-white/5">
                       <Globe className="w-8 h-8 text-white/20" />
                    </div>
                    <div className="flex-1">
                       <h4 className="font-black text-white text-lg mb-1 italic">No Quantitative Filter — Theme Only</h4>
                       <p className="text-xs text-white/20 font-medium tracking-tight">Strategy restricted for Premium Tiers. Screen purely by the selected thematic universe.</p>
                    </div>
                    <div className="w-7 h-7 rounded-full border-2 border-white/5 flex items-center justify-center">
                       <Shield className="w-3.5 h-3.5 text-white/10" />
                    </div>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {STRATEGIES.filter(s => s.id !== 'no-filter').map(s => (
                       <button 
                        key={s.id}
                        onClick={() => setSelectedStrategy(s.id)}
                        className={cn("p-8 rounded-[2rem] border bg-[#1A1A1A] text-left transition-all relative overflow-hidden shadow-xl", selectedStrategy === s.id ? "border-amber-400 ring-2 ring-amber-400/10 shadow-amber-400/5 scale-[1.02]" : "border-white/5 hover:border-white/10")}
                      >
                         <div className="flex justify-between items-start mb-8">
                            <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                               <s.icon className="w-8 h-8 text-indigo-400 transition-transform group-hover:scale-110" />
                            </div>
                            <span className="text-[9px] font-black text-amber-400 uppercase tracking-[0.2em]">{s.risk}</span>
                         </div>
                         <h4 className="font-black text-white text-xl mb-3 tracking-tighter">{s.name}</h4>
                         <p className="text-xs text-white/30 leading-relaxed font-medium">{s.desc}</p>
                       </button>
                    ))}
                 </div>
              </motion.div>
            )}

            {activeStep === 'Screen' && (
              <motion.div key="screen" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-20 text-center">
                 <div className="w-20 h-20 bg-rose-500/10 border border-rose-500/20 rounded-3xl flex items-center justify-center mx-auto mb-6 scale-animation">
                    <AlertTriangle className="w-10 h-10 text-rose-500" />
                 </div>
                 <h4 className="text-xl font-bold text-white mb-2">Screener error</h4>
                 <p className="text-slate-500 text-sm mb-6 font-medium">AI request limit reached for this session.</p>
                 <button className="text-rose-500 font-bold text-sm underline decoration-rose-500/30 underline-offset-4">Retry</button>
              </motion.div>
            )}

            {activeStep === 'Backtest' && (
              <motion.div key="backtest" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="dashboard-card border-none bg-transparent p-0">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10">
                    <div className="bg-[#111318] p-8 rounded-3xl border border-slate-800/50">
                       <div className="flex gap-12 mb-10">
                          <div>
                            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-2">Universe</p>
                            <p className="text-lg font-bold text-amber-400">{currentUniverseData?.name}</p>
                          </div>
                          <div>
                            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-2">Strategy</p>
                            <p className="text-lg font-bold text-indigo-400">{currentStrategyData?.name}</p>
                          </div>
                       </div>
                       
                       <div className="space-y-8">
                          <div>
                             <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2 mb-4">
                                <TrendingUp className="w-3 h-3" /> Rebalance
                             </label>
                             <div className="grid grid-cols-2 gap-2">
                               {['Monthly', 'Quarterly', 'Half-Yearly', 'Yearly'].map(r => (
                                 <button 
                                  key={r}
                                  onClick={() => setBacktestConfig(prev => ({ ...prev, rebalance: r }))}
                                  className={cn("px-4 py-2 rounded-xl text-xs font-bold border transition-all", backtestConfig.rebalance === r ? "bg-indigo-600/10 border-indigo-600 text-indigo-400" : "bg-[#1A1C20] border-slate-800 text-slate-500")}
                                 >
                                   {r} {backtestConfig.rebalance === r && <CheckCircle2 className="w-3 h-3 inline ml-2" />}
                                 </button>
                               ))}
                             </div>
                          </div>
                          
                          <div>
                             <div className="flex justify-between mb-4">
                               <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                                  <Briefcase className="w-3 h-3" /> Stocks — <span className="text-amber-400">{backtestConfig.stocks}</span>
                               </label>
                             </div>
                             <input 
                              type="range" min="1" max="50" step="1" 
                              value={backtestConfig.stocks}
                              onChange={(e) => setBacktestConfig(prev => ({ ...prev, stocks: parseInt(e.target.value) }))}
                              className="w-full accent-emerald-500" 
                             />
                             <div className="flex justify-between mt-2 text-[10px] font-bold text-slate-600">
                                <span>1</span>
                                <span>Concentrated — high conviction, higher vol</span>
                                <span>50</span>
                             </div>
                          </div>
                       </div>
                    </div>

                    <div className="bg-[#111318] p-8 rounded-3xl border border-slate-800/50 flex flex-col justify-between">
                       <div className="space-y-8">
                          <div>
                            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2 mb-4">
                               <Clock className="w-3 h-3" /> Duration
                            </label>
                            <div className="grid grid-cols-3 gap-2">
                               {['3M', '6M', '1Y', '2Y', '3Y', '5Y'].map(d => (
                                 <button 
                                  key={d}
                                  onClick={() => setBacktestConfig(prev => ({ ...prev, duration: d }))}
                                  className={cn("px-4 py-2 rounded-xl text-xs font-bold border transition-all", backtestConfig.duration === d ? "bg-amber-400/10 border-amber-400 text-amber-400" : "bg-[#1A1C20] border-slate-800 text-slate-500")}
                                 >
                                   {d}
                                 </button>
                               ))}
                            </div>
                          </div>
                          
                          <div className="flex gap-8">
                             <div className="flex-1">
                               <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4 block">Hedge</label>
                               <div className="grid grid-cols-2 gap-2">
                                  {['None', 'GOLDBEES'].map(h => (
                                    <button 
                                      key={h}
                                      onClick={() => setBacktestConfig(prev => ({ ...prev, hedge: h }))}
                                      className={cn("px-4 py-2 rounded-xl text-xs font-bold border transition-all", backtestConfig.hedge === h ? "bg-[#1A1C20] border-amber-400 text-white" : "bg-[#1A1C20] border-slate-800 text-slate-500")}
                                    >
                                      {h}
                                    </button>
                                  ))}
                               </div>
                             </div>
                             <div className="flex-1">
                               <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4 block">Sort By</label>
                               <select className="w-full bg-[#1A1C20] border border-slate-800 rounded-xl px-4 py-2 text-xs font-bold text-white outline-none">
                                  <option>Market Cap</option>
                                  <option>Alpha Signal</option>
                                  <option>Volume</option>
                               </select>
                             </div>
                          </div>
                       </div>

                       <button className="w-full mt-10 h-14 bg-gradient-to-r from-amber-400 to-amber-500 rounded-2xl text-slate-900 font-bold flex items-center justify-center gap-2 shadow-xl shadow-amber-900/10 hover:scale-[1.01] transition-all">
                          <Play className="w-5 h-5 fill-current" /> Run Simulation
                       </button>
                    </div>
                 </div>
              </motion.div>
            )}

            {activeStep === 'Execute' && (
              <motion.div key="execute" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="max-w-2xl">
                 <div className="dashboard-card p-10 bg-[#111318] border-slate-800/50">
                    <h4 className="text-xl font-bold text-white mb-8 flex items-center gap-3">
                       <Zap className="w-6 h-6 text-amber-400 fill-amber-400" /> Go Live
                    </h4>
                    <p className="text-sm text-slate-500 font-medium mb-10">Name this strategy to save it to your model portfolio dashboard.</p>
                    
                    <div className="grid grid-cols-2 gap-10 mb-12">
                       <div>
                          <p className="text-[10px] font-bold text-slate-600 uppercase tracking-widest mb-2">Universe</p>
                          <p className="text-lg font-bold text-amber-400">{currentUniverseData?.name}</p>
                       </div>
                       <div>
                          <p className="text-[10px] font-bold text-slate-600 uppercase tracking-widest mb-2">Strategy</p>
                          <p className="text-lg font-bold text-indigo-400">{currentStrategyData?.name}</p>
                       </div>
                    </div>

                    <div className="space-y-4 mb-12">
                       <label className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Portfolio Name</label>
                       <input 
                        type="text" 
                        defaultValue={`${currentStrategyData?.name || 'My Strategy'} — ${currentUniverseData?.name || 'Custom'}`}
                        className="w-full h-14 bg-[#1A1C20] border border-slate-800 rounded-2xl px-6 text-white font-medium focus:border-indigo-500 outline-none transition-all"
                       />
                    </div>

                    <button 
                      onClick={() => setIsDashboard(true)}
                      className="w-full h-14 bg-emerald-500 text-slate-900 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-emerald-400 transition-all shadow-xl shadow-emerald-900/20"
                    >
                       <Zap className="w-5 h-5 fill-current" /> Save & Go to Dashboard
                    </button>
                 </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* AI CoPilot Panel */}
        <AnimatePresence>
          {copilotActive && (
            <motion.div 
              initial={{ x: 300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 300, opacity: 0 }}
              className="lg:col-span-4 h-fit sticky top-6"
            >
              <div className="bg-[#111318] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
                <div className="p-6 border-b border-slate-800/50 flex items-center justify-between bg-[#1A1C20]/50">
                  <div className="flex items-center gap-3">
                     <div className="p-2 bg-amber-400/10 rounded-xl border border-amber-400/20">
                        <Sparkles className="w-5 h-5 text-amber-400" />
                     </div>
                     <div>
                        <h4 className="text-sm font-bold text-white mb-0.5">AI CoPilot</h4>
                        <div className="flex items-center gap-2">
                           <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                           <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest">Connected</span>
                        </div>
                     </div>
                  </div>
                </div>

                <div className="p-8 space-y-8">
                   {selectedStrategy ? (
                     <div className="animate-in fade-in slide-in-from-right-4">
                        <h5 className="text-amber-400 font-bold mb-4">{currentStrategyData?.name}</h5>
                        <div className="flex gap-4 p-4 bg-[#1A1C20] rounded-2xl border border-slate-800">
                           <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-1" />
                           <p className="text-xs text-slate-400 leading-relaxed font-medium">Ask me anything about <b>{currentStrategyData?.name}</b> — type below to chat.</p>
                        </div>
                     </div>
                   ) : (
                    <div className="space-y-10 py-10 text-center">
                       <div className="w-20 h-20 bg-[#1A1C20] rounded-3xl flex items-center justify-center mx-auto border border-slate-800 relative">
                          <BarChart3 className="w-10 h-10 text-slate-700" />
                          <div className="absolute inset-0 bg-amber-400/5 rounded-3xl animate-pulse" />
                       </div>
                       <div>
                          <h5 className="text-white font-bold mb-2">Alpha Signal Engine</h5>
                          <p className="text-xs text-slate-500 leading-relaxed font-medium max-w-[200px] mx-auto">Select a strategy to get real-time alpha signals and sentiment scoring.</p>
                       </div>
                    </div>
                   )}
                </div>

                <div className="p-6 bg-[#0A0B0D] border-t border-slate-800">
                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder="Ask about this step..."
                      className="w-full bg-[#111318] border border-slate-800 rounded-2xl py-4 pl-6 pr-14 text-xs font-bold text-white focus:border-amber-400/50 outline-none transition-all placeholder:text-slate-700 shadow-inner"
                    />
                    <button className="absolute right-2 top-1/2 -translate-y-1/2 p-2.5 bg-amber-400 rounded-xl text-slate-900 hover:bg-amber-300 transition-all shadow-lg active:scale-95">
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Persistent App Install Mock */}
      <div className="fixed bottom-6 right-6 z-[100] animate-in slide-in-from-bottom-8">
         <div className="bg-[#1A1C20] border border-slate-800 rounded-2xl p-4 flex items-center gap-4 shadow-2xl">
            <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-500 rounded-xl flex items-center justify-center font-bold text-slate-900">
               <Zap className="w-6 h-6 fill-current" />
            </div>
            <div>
               <p className="text-xs font-bold text-white">Install Nivesh AI</p>
               <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tight">Access Pro Terminal Anywhere</p>
            </div>
            <button className="bg-white text-slate-900 px-4 py-2 rounded-xl text-xs font-bold ml-2">Install</button>
         </div>
      </div>
    </div>
  );
}
