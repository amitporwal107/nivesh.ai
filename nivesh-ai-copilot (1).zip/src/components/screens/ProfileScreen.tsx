/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { 
  Settings, 
  ShieldCheck, 
  TrendingUp, 
  Briefcase, 
  FileText, 
  Moon, 
  Globe, 
  Bell, 
  ChevronRight,
  Brain,
  Info
} from 'lucide-react';
import { Persona } from '../../types';
import { cn } from '../../lib/utils';

export default function ProfileScreen({ 
  persona, 
  userData, 
  riskProfile,
  onUpdateUser
}: { 
  persona: Persona;
  userData: { name: string; mobile?: string } | null;
  riskProfile: string | null;
  onUpdateUser?: (data: { name: string; mobile?: string }) => void;
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(userData?.name || 'Amit Sharma');
  const [editedMobile, setEditedMobile] = useState(userData?.mobile || '');

  const handleSave = () => {
    if (isEditing) {
      onUpdateUser?.({ name: editedName, mobile: editedMobile });
    }
    setIsEditing(!isEditing);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-4xl mx-auto pb-12">
      <div className="flex flex-col md:flex-row items-center gap-6 dashboard-card p-8">
        <div className="relative">
          <div className="w-24 h-24 rounded-full bg-indigo-100 flex items-center justify-center text-3xl font-bold text-indigo-700 italic tracking-tighter border-4 border-white shadow-lg">
            {(editedName || 'Amit Sharma').split(' ').map(n => n[0]).join('')}
          </div>
          <button className="absolute bottom-0 right-0 p-1.5 bg-white rounded-full shadow-md border border-slate-100 text-slate-400 hover:text-indigo-600 transition-colors">
            <Settings className="w-4 h-4" />
          </button>
        </div>
        <div className="text-center md:text-left flex-1">
          {isEditing ? (
            <div className="space-y-3">
              <input 
                type="text" 
                value={editedName}
                onChange={(e) => setEditedName(e.target.value)}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                placeholder="Full Name"
              />
              <input 
                type="text" 
                value={editedMobile}
                onChange={(e) => setEditedMobile(e.target.value)}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                placeholder="Mobile Number"
              />
            </div>
          ) : (
            <>
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">{editedName}</h2>
              <p className="text-slate-500 font-medium tracking-tight">
                {editedMobile ? `${editedMobile} • ` : ''}amit.sharma@example.com
              </p>
            </>
          )}
          <div className="flex items-center justify-center md:justify-start gap-2 mt-3">
             <span className="bg-indigo-50 text-indigo-600 text-[10px] font-bold px-2 py-1 rounded-md uppercase tracking-wider">Premium Member</span>
             <span className="bg-emerald-50 text-emerald-600 text-[10px] font-bold px-2 py-1 rounded-md uppercase tracking-wider">Verified Identity</span>
          </div>
        </div>
        <button 
          onClick={handleSave}
          className="px-6 py-2.5 border border-slate-200 bg-white rounded-xl text-sm font-bold text-slate-700 shadow-sm hover:bg-slate-50 transition-all active:scale-95"
        >
          {isEditing ? 'Save Changes' : 'Edit Profile'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Risk Intelligence Card */}
        <div className="dashboard-card p-6 border-l-4 border-l-indigo-600">
           <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-3">
                 <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl">
                    <Brain className="w-6 h-6" />
                 </div>
                 <div>
                    <h3 className="font-bold text-slate-900 leading-none mb-1">Risk Intelligence</h3>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Neural Suitability</p>
                 </div>
              </div>
              <button className="text-[10px] font-bold text-indigo-600 underline uppercase tracking-widest">Retake Quiz</button>
           </div>

           <div className="space-y-4">
              <div className="flex items-center justify-between">
                 <span className="text-sm font-bold text-slate-600">Current Profile</span>
                 <span className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-lg text-xs font-bold">{riskProfile || 'Moderate'}</span>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl flex gap-3">
                 <Info className="w-4 h-4 text-slate-400 shrink-0" />
                 <p className="text-[11px] text-slate-500 font-medium leading-relaxed">
                   Based on your 15-question assessment, your portfolio is optimized for <b>{riskProfile || 'Moderate'}</b> growth with dynamic rebalancing.
                 </p>
              </div>
           </div>
        </div>

        {/* Investment Details */}
        <section className="dashboard-card overflow-hidden">
          <div className="p-5 border-b border-slate-50">
            <h3 className="font-bold text-slate-800 tracking-tight">Financial Status</h3>
          </div>
          <div className="p-2">
            {[
              { label: 'Investment Goal', value: 'Wealth Growth', icon: TrendingUp },
              { label: 'Time Horizon', value: '15-20 Years', icon: Briefcase },
              { label: 'Regulatory Docs', value: 'KYC Verified', icon: FileText },
            ].map(item => (
              <button key={item.label} className="w-full flex items-center justify-between p-4 hover:bg-slate-50 rounded-xl transition-colors group">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-slate-50 text-slate-400 group-hover:text-indigo-600 transition-colors">
                    <item.icon className="w-4 h-4" />
                  </div>
                  <span className="text-sm font-bold text-slate-700">{item.label}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-tight">{item.value}</span>
                  <ChevronRight className="w-4 h-4 text-slate-300" />
                </div>
              </button>
            ))}
          </div>
        </section>
      </div>

      <section className="dashboard-card overflow-hidden">
        <div className="p-5 border-b border-slate-50">
          <h3 className="font-bold text-slate-800 tracking-tight">Security & Preferences</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 p-2">
          {[
            { label: 'Biometric Login', value: 'Enabled', icon: ShieldCheck },
            { label: 'Cloud Data Sync', value: 'Automatic', icon: Globe },
            { label: 'App Theme', value: 'Slate Light', icon: Moon },
            { label: 'Notifications', value: 'Smart Alerts', icon: Bell },
          ].map(item => (
            <button key={item.label} className="flex items-center justify-between p-4 hover:bg-slate-50 rounded-xl transition-colors group">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-slate-50 text-slate-400 group-hover:text-indigo-600 transition-colors">
                  <item.icon className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-slate-700">{item.label}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-tight">{item.value}</span>
                <ChevronRight className="w-4 h-4 text-slate-300" />
              </div>
            </button>
          ))}
        </div>
      </section>

      <div className="dashboard-card p-6 border-rose-100 bg-rose-50/10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
           <div>
              <h4 className="font-bold text-rose-900 tracking-tight">Danger Zone</h4>
              <p className="text-xs text-rose-800 opacity-70 font-medium">Permanently delete your Nivesh account and all financial records.</p>
           </div>
           <button className="px-6 py-2.5 bg-rose-600 text-white rounded-xl text-sm font-bold shadow-md shadow-rose-100 hover:bg-rose-700 transition-all active:scale-95">
              Delete Account
           </button>
        </div>
      </div>
    </div>
  );
}
