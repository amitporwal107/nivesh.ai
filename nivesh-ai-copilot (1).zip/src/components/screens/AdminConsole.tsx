import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Database, 
  RefreshCcw, 
  Terminal, 
  Cpu, 
  Activity, 
  ShieldCheck, 
  HardDrive,
  Zap,
  Server,
  Code
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { getAdminStats, triggerScrape } from '../../services/aiService';

export default function AdminConsole() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [logs, setLogs] = useState<string[]>(["[SYSTEM] Initializing Nivesh Alpha AI Core...", "[SYSTEM] PostgreSQL Connection: OK", "[SYSTEM] Redis Cache: OK"]);

  useEffect(() => {
    const loadStats = async () => {
      const data = await getAdminStats();
      setStats(data);
      setLoading(false);
    };
    loadStats();
    
    const interval = setInterval(loadStats, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleAction = async (source: string) => {
    addLog(`[ACTION] Triggering ${source} scrape/refresh...`);
    const result = await triggerScrape(source);
    if (result) {
      addLog(`[SUCCESS] ${result.message}`);
    }
  };

  const addLog = (msg: string) => {
    setLogs(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev].slice(0, 50));
  };

  if (loading) return (
    <div className="flex items-center justify-center h-full">
      <RefreshCcw className="w-8 h-8 text-indigo-500 animate-spin" />
    </div>
  );

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-700">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-white italic tracking-tighter">NODE_CONTROL</h1>
          <p className="text-xs text-white/40 font-mono">System Oversight & Data Ingestion (Nivesh v2)</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Core Synchronized</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'POSTGRES_DB', value: stats.infrastructure.postgres, sub: 'NEON_CLOUD', icon: Database, color: stats.infrastructure.postgres === 'CONNECTED' ? 'text-emerald-400' : 'text-rose-400' },
          { label: 'REDIS_CACHE', value: stats.infrastructure.redis, sub: 'UPSTASH_V3', icon: Zap, color: stats.infrastructure.redis === 'CONNECTED' ? 'text-emerald-400' : 'text-rose-400' },
          { label: 'MF_COUNT', value: stats.database.mfMetadata, sub: 'METADATA_COLS: 58', icon: Server, color: 'text-indigo-400' },
          { label: 'NSE_FEED', value: 'STABLE', sub: 'LATENCY: 42ms', icon: Activity, color: 'text-indigo-400' }
        ].map((item, i) => (
          <div key={i} className="bg-[#1A1A1A] border border-white/5 p-5 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
              <p className="text-[9px] font-black text-white/20 uppercase tracking-widest">{item.label}</p>
              <item.icon className={cn("w-4 h-4", item.color)} />
            </div>
            <p className="text-2xl font-black text-white italic">{item.value}</p>
            <p className="text-[10px] text-white/40 font-mono mt-1">{item.sub}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Engine Controls */}
          <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-white/5 bg-white/[0.02] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-indigo-400" />
                <span className="text-[10px] font-black text-white uppercase tracking-widest">Ingestion Engines</span>
              </div>
            </div>
            <div className="divide-y divide-white/5">
              {[
                { name: 'GROWW_SCRAPER', status: stats.scrapers.groww.status, last: stats.scrapers.groww.lastRun, success: stats.scrapers.groww.successRate, action: 'Groww' },
                { name: 'AMFI_NAV_FETCHER', status: stats.scrapers.amfi.status, last: stats.scrapers.amfi.lastRun, success: stats.scrapers.amfi.successRate, action: 'AMFI' },
                { name: 'NSE_TECHNICAL_ENGINE', status: stats.scrapers.nse.status, last: stats.scrapers.nse.lastRun, success: stats.scrapers.nse.successRate, action: 'NSE' }
              ].map((engine, i) => (
                <div key={i} className="p-4 flex items-center justify-between group hover:bg-white/[0.01] transition-colors">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-2 h-2 rounded-full",
                      engine.status === 'LIVE' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
                    )} />
                    <div>
                      <p className="text-sm font-bold text-white tracking-tight">{engine.name}</p>
                      <p className="text-[10px] text-white/30 font-mono">Last Run: {engine.last} • Success: {engine.success}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => handleAction(engine.action)}
                    className="p-2 bg-white/5 border border-white/10 rounded-xl hover:bg-indigo-500/20 hover:border-indigo-500/40 transition-all text-white/40 hover:text-indigo-400"
                  >
                    <RefreshCcw className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* System Terminal */}
          <div className="bg-black border border-white/10 rounded-2xl overflow-hidden font-mono flex flex-col h-[300px]">
            <div className="p-3 border-b border-white/5 bg-[#1A1A1A] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-3 h-3 text-emerald-500" />
                <span className="text-[9px] font-black text-white/30 uppercase tracking-[0.2em]">Live Output Stream</span>
              </div>
              <div className="flex gap-1">
                <div className="w-2 h-2 rounded-full bg-red-500/20 border border-red-500/40" />
                <div className="w-2 h-2 rounded-full bg-amber-500/20 border border-amber-500/40" />
                <div className="w-2 h-2 rounded-full bg-emerald-500/20 border border-emerald-500/40" />
              </div>
            </div>
            <div className="flex-1 p-4 overflow-y-auto space-y-2 text-[11px] leading-relaxed">
              {logs.map((log, i) => (
                <div key={i} className={cn(
                  i === 0 ? "text-emerald-400" : "text-white/40",
                  log.includes('[ERROR]') && "text-rose-400"
                )}>
                  {log}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {/* Metadata Sidebar */}
          <div className="bg-[#1A1A1A] border border-white/10 rounded-2xl p-6">
            <h3 className="text-[10px] font-black text-white/30 uppercase tracking-widest mb-6">Database Schema</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Code className="w-4 h-4 text-indigo-400" />
                <div>
                  <p className="text-xs font-bold text-white tracking-tight">mutual_fund_metadata</p>
                  <p className="text-[10px] text-white/30 italic">58 specialized columns per fund</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <HardDrive className="w-4 h-4 text-emerald-400" />
                <div>
                  <p className="text-xs font-bold text-white tracking-tight">nav_history_5y</p>
                  <p className="text-[10px] text-white/30 italic">Daily backfill logic: backfill_amfi.py</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-2xl p-6">
            <ShieldCheck className="w-8 h-8 text-indigo-400 mb-4" />
            <h3 className="text-sm font-bold text-white mb-2">V3 Scoring Reliability</h3>
            <p className="text-xs text-white/60 leading-relaxed font-medium">
              The engine applies tiered guardrails before finalizing composite scores. Cache hit rate is monitored for latency spikes.
            </p>
            <div className="mt-4 flex items-center gap-3">
              <div className="flex-1 h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 w-[94%]" />
              </div>
              <span className="text-[10px] font-black text-indigo-400">94.2%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
