/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { Screen, Persona } from '../../types';
import { MOCK_MARKETS } from '../../constants';
import { 
  TrendingUp, 
  AlertCircle, 
  ArrowUpRight, 
  ArrowDownRight, 
  MessageSquare,
  ChevronRight,
  ShieldCheck,
  Briefcase,
  Zap
} from 'lucide-react';
import { cn } from '../../lib/utils';
import TradeTerminal from './TradeTerminal';
import AdvisorDashboard from './AdvisorDashboard';

export default function HomeDashboard({ persona, setScreen }: { persona: Persona; setScreen: (s: Screen) => void }) {
  if (persona === Persona.TRADER) {
    return <TradeTerminal />;
  }

  if (persona === Persona.MFD || persona === Persona.ADVISOR) {
    return <AdvisorDashboard persona={persona} setScreen={setScreen} />;
  }

  const getPersonalizedHeader = () => {
    return {
      title: 'Good Evening, Amit Sharma 👋',
      subtitle: 'Your personal wealth analysis is ready for review.',
      cta: 'Invest More',
      secondary: 'Goal Plan'
    };
  };

  const getKPIs = () => {
    return [
      { label: 'Total Wealth', value: '₹82,90,442', detail: '+18.4% XIRR', detailColor: 'text-emerald-600' },
      { label: 'Health Score', value: '86/100', detail: 'Above Peer Avg (72)', detailColor: 'text-emerald-600', progress: 86 },
      { label: 'Risk Budget', value: '85%', detail: 'Moderate High', detailColor: 'text-amber-500' },
      { label: 'Tax Savings', value: '₹1.12L', detail: 'Optimizable', detailColor: 'text-indigo-600' },
    ];
  };

  const header = getPersonalizedHeader();
  const kpis = getKPIs();

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi) => (
          <div key={kpi.label} className="bg-[#1A1A1A] border border-white/5 p-6 rounded-3xl shadow-xl hover:border-white/10 transition-all group overflow-hidden relative">
            <div className="absolute top-0 right-0 w-24 h-24 bg-white/5 rounded-full blur-2xl -mr-12 -mt-12 group-hover:bg-indigo-500/5 transition-colors" />
            <p className="text-[10px] font-bold text-white/30 uppercase tracking-[0.2em] mb-2 font-mono">{kpi.label}</p>
            <div className="flex items-end justify-between relative z-10">
              <h3 className="text-2xl font-black text-white tracking-tight">{kpi.value}</h3>
              {kpi.progress && (
                <div className="w-12 bg-white/5 h-1.5 rounded-full overflow-hidden mb-1.5 ml-2">
                  <div className="h-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]" style={{ width: `${kpi.progress}%` }} />
                </div>
              )}
            </div>
            <p className={cn("text-[10px] font-bold mt-3 uppercase tracking-tighter", kpi.detailColor.replace('text-emerald-600', 'text-emerald-400').replace('text-indigo-600', 'text-indigo-400'))}>{kpi.detail}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Insights Column */}
        <div className="lg:col-span-2 bg-[#1A1A1A] border border-white/5 rounded-[2.5rem] flex flex-col shadow-2xl overflow-hidden">
          <div className="p-8 border-b border-white/5 flex justify-between items-center bg-white/[0.01]">
            <h4 className="text-xl font-bold text-white tracking-tight">Intelligence Feed</h4>
            <div className="flex items-center gap-2 px-3 py-1 bg-rose-500/10 text-rose-500 text-[10px] font-bold rounded-lg border border-rose-500/20">
               3 ACTIONABLE SIGNALS
            </div>
          </div>
          <div className="p-8 space-y-6">
            <div className="p-6 rounded-[2rem] bg-indigo-500/5 border border-indigo-500/10 hover:bg-indigo-500/10 transition-all cursor-pointer group">
              <div className="flex items-start gap-5">
                <div className="bg-indigo-500/20 p-3 rounded-2xl text-indigo-400 shrink-0 group-hover:scale-110 transition-transform shadow-lg">
                  <AlertCircle className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-bold text-white text-base tracking-tight mb-1">Sector Concentration Risk Detected</p>
                  <p className="text-xs text-white/40 leading-relaxed font-medium">Your IT exposure is 14.2% higher than recommended. NIFTY IT exhibits distribution patterns. Rebalancing advice generated.</p>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-[2rem] bg-white/[0.02] border border-white/5 hover:bg-white/5 transition-all cursor-pointer group">
              <div className="flex items-start gap-5">
                <div className="bg-white/5 p-3 rounded-2xl text-white/40 shrink-0 group-hover:text-indigo-400 transition-all">
                  <Briefcase className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-bold text-white text-base tracking-tight mb-1">Fee Optimization Opportunity</p>
                  <p className="text-xs text-white/40 leading-relaxed font-medium">Overlapping holdings across 3 Mutual Funds. Consolidating into 'Direct' plans could save ₹14,200 annually.</p>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-[2rem] bg-emerald-500/5 border border-emerald-500/10 hover:bg-emerald-500/10 transition-all cursor-pointer group">
              <div className="flex items-start gap-5">
                <div className="bg-emerald-500/20 p-3 rounded-2xl text-emerald-400 shrink-0 group-hover:scale-110 transition-transform shadow-lg">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-bold text-white text-base tracking-tight mb-1">Tax Loss Harvesting (FY 2024)</p>
                  <p className="text-xs text-white/40 leading-relaxed font-medium">Offset short-term gains by realizing ₹45,000 in current unrealized losses. Potential tax benefit: ₹13,500.</p>
                </div>
              </div>
            </div>
          </div>
          <div className="p-6 border-t border-white/5 bg-white/[0.01] flex justify-end gap-8">
            <button className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em] hover:text-white/40 transition-colors">Dismiss Intelligence</button>
            <button className="text-[10px] font-bold text-indigo-400 uppercase tracking-[0.2em] hover:text-indigo-300 transition-colors">Apply Optimizations</button>
          </div>
        </div>

        {/* Market Signals / Quick Scanner */}
        <div className="bg-[#1A1A1A] border border-white/5 rounded-[2.5rem] flex flex-col shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl -mr-32 -mt-32" />
          <div className="p-8 border-b border-white/5 bg-white/[0.01]">
            <h4 className="text-xl font-bold text-white tracking-tight">Sentiment Radar</h4>
          </div>
          <div className="p-8 flex-1 space-y-8 relative z-10">
            <div className="flex items-center gap-5">
              <div className="w-14 h-14 bg-indigo-600 rounded-3xl flex items-center justify-center text-white shadow-xl shadow-indigo-600/30">
                <TrendingUp className="w-8 h-8" />
              </div>
              <div>
                <p className="text-lg font-black text-white italic">Strongly Bullish</p>
                <div className="flex items-center gap-2 mt-1">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest">Neural Confidence: 82.4%</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em] font-mono">Real-time Alpha Signals</p>
              {[
                { name: 'TATA MOTORS', target: '+6.25%', status: 'Bullish' },
                { name: 'HDFC AMC', target: '+4.50%', status: 'Accumulate' },
                { name: 'BPCL', target: '-1.82%', status: 'Distribution' },
              ].map((sig) => (
                <div key={sig.name} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-all cursor-pointer group">
                  <div className="flex flex-col">
                    <span className="text-sm font-bold text-white">{sig.name}</span>
                    <span className="text-[9px] font-bold text-white/30 uppercase tracking-tight">{sig.status}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={cn("text-base font-black", sig.target.startsWith('+') ? 'text-emerald-400' : 'text-rose-500')}>
                       {sig.target}
                    </span>
                    <ChevronRight className="w-4 h-4 text-white/10 group-hover:text-indigo-400 transition-all" />
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="p-6 border-t border-white/5">
            <button 
              onClick={() => setScreen('markets')}
              className="w-full text-[10px] font-bold text-indigo-400 uppercase tracking-[0.2em] py-3 rounded-xl hover:bg-white/5 transition-all text-center"
            >
              Enter Market Intelligence Hub
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
