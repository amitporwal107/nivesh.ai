/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Users, 
  Plus, 
  RefreshCw, 
  Phone, 
  TrendingUp, 
  TrendingDown, 
  Scale, 
  Bell, 
  ChevronRight,
  Info,
  Sparkles,
  Search,
  MessageSquare,
  FileText,
  ShieldCheck,
  Clock,
  ArrowUpRight
} from 'lucide-react';
import { Screen, Persona } from '../../types';
import { cn } from '../../lib/utils';

export default function AdvisorDashboard({ persona, setScreen }: { persona: Persona; setScreen: (s: Screen) => void }) {
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Metrics Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         <div className="bg-[#1A1A1A] border border-white/5 p-8 rounded-3xl shadow-xl hover:border-white/10 transition-all group overflow-hidden relative">
            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl -mr-12 -mt-12 group-hover:bg-emerald-500/10 transition-colors" />
            <p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em] mb-3">Portfolio Book</p>
            <h3 className="text-3xl font-black text-white">₹1.15 Cr</h3>
            <div className="flex items-center gap-2 mt-3 text-emerald-400 text-xs font-bold">
               <TrendingUp className="w-4 h-4" /> +2.4% this month
            </div>
         </div>
         <div className="bg-[#1A1A1A] border border-white/5 p-8 rounded-3xl shadow-xl hover:border-white/10 transition-all group overflow-hidden relative">
            <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full blur-2xl -mr-12 -mt-12 group-hover:bg-indigo-500/10 transition-colors" />
            <p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em] mb-3">Active Clients</p>
            <h3 className="text-3xl font-black text-white">42</h3>
            <p className="text-white/40 text-xs font-medium mt-3">4 new onboarded this week</p>
         </div>
         <div className="bg-[#1A1A1A] border border-white/5 p-8 rounded-3xl shadow-xl hover:border-white/10 transition-all group overflow-hidden relative">
            <p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em] mb-3">AUM Target</p>
            <div className="flex items-end gap-3">
               <h3 className="text-3xl font-black text-white">₹5.0 Cr</h3>
               <span className="text-indigo-400 text-xs font-bold mb-1.5 whitespace-nowrap">23% complete</span>
            </div>
            <div className="w-full bg-white/5 h-2 rounded-full mt-4 overflow-hidden">
               <div className="w-[23%] h-full bg-indigo-500 shadow-[0_0_12px_rgba(99,102,241,0.5)]" />
            </div>
         </div>
      </div>

      <div className="flex items-center justify-between pt-4">
         <div>
            <h2 className="text-xl font-bold text-white tracking-tight mb-1">Practice Intelligence</h2>
            <p className="text-sm text-white/40 font-medium">Proactive signals filtered by Nivesh AI Engine.</p>
            <button 
              onClick={() => setScreen('markets')}
              className="mt-2 text-[10px] font-bold text-indigo-400 uppercase tracking-widest hover:text-indigo-300 transition-colors flex items-center gap-1"
            >
              View Market Dashboard <ArrowUpRight className="w-3 h-3" />
            </button>
         </div>
         <button 
           onClick={handleRefresh}
           className="p-2.5 bg-[#2f2f2f] border border-white/10 rounded-xl text-white/60 hover:text-white transition-all"
         >
            <RefreshCw className={cn("w-4 h-4", isRefreshing && "animate-spin")} />
         </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Calls */}
        <div className="bg-[#1A1A1A] border border-white/5 rounded-[2.5rem] p-8 shadow-2xl hover:border-white/10 transition-all">
           <div className="flex items-start gap-4 mb-8">
              <div className="p-3 bg-white/5 text-indigo-400 rounded-2xl border border-white/5">
                <Phone className="w-6 h-6" />
              </div>
              <div>
                 <p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em] mb-1">Engagements Needed</p>
                 <h3 className="text-2xl font-bold text-white">0 High • 1 Medium priority</h3>
                 <p className="text-xs text-indigo-400/60 font-medium mt-1">Sorted by Nivesh Scoring Algorithm</p>
              </div>
           </div>

           <div className="space-y-6">
              <div className="flex items-center justify-between group cursor-pointer bg-white/5 p-4 rounded-2xl border border-transparent hover:border-white/10 transition-all">
                 <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                       <span className="font-bold text-white text-lg">Priyanka Mantri</span>
                       <span className="px-2 py-0.5 bg-amber-500/10 text-amber-500 text-[10px] font-bold rounded-lg uppercase border border-amber-500/20">MEDIUM</span>
                    </div>
                    <p className="text-sm text-white/40 font-medium">Low Portfolio Health Score (48/100)</p>
                 </div>
                 <div className="flex items-center gap-3">
                    <span className="text-lg font-bold text-white">₹1.15 Cr</span>
                    <ChevronRight className="w-5 h-5 text-white/20 group-hover:text-indigo-400 transition-all" />
                 </div>
              </div>

              <div className="flex items-center justify-between group cursor-pointer bg-white/5 p-4 rounded-2xl border border-transparent hover:border-white/10 transition-all opacity-60">
                 <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                       <span className="font-bold text-white text-lg">Ahaan Porwal</span>
                       <span className="px-2 py-0.5 bg-white/5 text-white/40 text-[10px] font-bold rounded-lg uppercase border border-white/10">STABLE</span>
                    </div>
                    <p className="text-sm text-white/20 font-medium">Health score regular (64/100)</p>
                 </div>
                 <div className="flex items-center gap-3 text-white/20">
                    <span className="text-lg font-bold">—</span>
                    <ChevronRight className="w-5 h-5 group-hover:text-indigo-400 transition-all" />
                 </div>
              </div>
           </div>
        </div>

        {/* Rebalance Opportunities */}
        <div className="bg-[#1A1A1A] border border-white/5 rounded-[2.5rem] p-8 shadow-2xl hover:border-white/10 transition-all">
           <div className="flex items-start gap-4 mb-8">
              <div className="p-3 bg-white/5 text-amber-400 rounded-2xl border border-white/5">
                 <Scale className="w-6 h-6" />
              </div>
              <div>
                 <p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em] mb-1">Wealth Protection</p>
                 <h3 className="text-2xl font-bold text-white">1 Critical Drift ≥10.0pp</h3>
                 <p className="text-xs text-amber-400/60 font-medium tracking-tight">Actionable rebalance opportunities detected</p>
              </div>
           </div>
           
           <div className="group cursor-pointer bg-amber-500/5 p-6 rounded-3xl border border-amber-500/20 hover:bg-amber-500/10 transition-all">
              <div className="flex items-center justify-between mb-4">
                 <div className="flex items-center gap-3">
                    <span className="font-bold text-white text-xl">Priyanka Mantri</span>
                    <span className="px-2 py-0.5 bg-amber-500/20 text-amber-500 text-[10px] font-bold rounded-lg uppercase">ACTION REQUIRED</span>
                 </div>
                 <span className="text-xl font-bold text-amber-500 underline decoration-amber-500/30 underline-offset-4">19.2pp Drift</span>
              </div>
              <div className="flex items-center gap-4 text-sm text-white/60">
                 <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-amber-500 rounded-full" />
                    Gold: 28% <span className="text-white/20 mx-1">/</span> Target: 9%
                 </div>
                 <div className="ml-auto flex items-center gap-1 text-white/40 hover:text-white transition-colors">
                    Analyze Impact <ArrowUpRight className="w-3 h-3" />
                 </div>
              </div>
           </div>

           <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="p-4 bg-white/5 rounded-2xl border border-white/5 text-center">
                 <p className="text-[10px] font-bold text-white/40 uppercase mb-1">Avg Drift</p>
                 <p className="text-lg font-bold text-white">3.4pp</p>
              </div>
              <div className="p-4 bg-white/5 rounded-2xl border border-white/5 text-center">
                 <p className="text-[10px] font-bold text-white/40 uppercase mb-1">Total Impact</p>
                 <p className="text-lg font-bold text-white">₹14.2k</p>
              </div>
           </div>
        </div>
      </div>

      {/* Today's Actions Hub */}
      <section className="bg-[#1A1A1A] border border-white/5 rounded-[3rem] p-12 shadow-2xl relative overflow-hidden group">
         {/* Background Decoration */}
         <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-indigo-500/5 rounded-full -mr-[200px] -mt-[200px] blur-[80px]" />

         <div className="flex items-start gap-6 mb-12 relative z-10">
            <div className="p-5 bg-indigo-500 text-white rounded-[1.5rem] shadow-2xl shadow-indigo-500/40">
               <Sparkles className="w-8 h-8" />
            </div>
            <div>
               <h3 className="text-3xl font-bold text-white tracking-tight">Intelligent Actions Hub</h3>
               <p className="text-base text-white/40 font-medium">Nivesh Copilot has identified 3 risk-reward optimizations.</p>
            </div>
         </div>

         <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center relative z-10">
            <div className="lg:col-span-8 space-y-4">
              {[
                { title: "Priyanka Mantri", note: "Portfolio score is critical (48/100)", level: "Critical", score: "57", icon: ShieldCheck, color: "rose" },
                { title: "Ahaan Porwal", note: "Quarterly review session stale by 12 days", level: "Medium", score: "34", icon: Clock, color: "amber" }
              ].map((action, i) => (
                <div key={i} className="flex items-center justify-between p-6 bg-white/5 hover:bg-white/10 rounded-[2rem] border border-white/5 transition-all group/item">
                   <div className="flex items-center gap-6">
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center border",
                        action.color === 'rose' ? "bg-rose-500/10 text-rose-500 border-rose-500/20" : "bg-amber-500/10 text-amber-500 border-amber-500/20"
                      )}>
                         <action.icon className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="text-xl font-bold text-white">{action.title}</h4>
                        <p className="text-sm text-white/40 font-medium mt-1">{action.note}</p>
                      </div>
                   </div>
                   <div className="flex items-center gap-4">
                      <div className="text-right hidden md:block">
                         <p className="text-[10px] font-bold text-white/30 uppercase">Priority Score</p>
                         <p className="text-lg font-bold text-white">{action.score}</p>
                      </div>
                      <ChevronRight className="w-6 h-6 text-white/20 group-hover/item:translate-x-1 transition-all" />
                   </div>
                </div>
              ))}
            </div>

            <div className="lg:col-span-4 flex flex-col gap-4">
               <button className="flex items-center justify-center gap-3 bg-amber-500 text-[#171717] px-8 py-5 rounded-[2rem] font-bold text-base shadow-2xl shadow-amber-500/20 hover:scale-[1.02] active:scale-95 transition-all">
                  <Scale className="w-6 h-6" /> Rebalance Book
               </button>
               <button className="flex items-center justify-center gap-3 bg-indigo-600 text-white px-8 py-5 rounded-[2rem] font-bold text-base shadow-2xl shadow-indigo-600/30 hover:scale-[1.02] active:scale-95 transition-all ring-1 ring-white/20">
                  <Sparkles className="w-6 h-6" /> Run AI Review
               </button>
               <div className="mt-4 p-5 bg-white/5 rounded-3xl border border-white/5 text-center">
                  <p className="text-sm text-white/40 leading-relaxed italic">"Nivesh AI automates up to 14 hours of advisory research weekly."</p>
               </div>
            </div>
         </div>
      </section>
    </div>
  );
}
