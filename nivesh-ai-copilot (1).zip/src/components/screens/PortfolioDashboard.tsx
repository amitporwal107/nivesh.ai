/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PieChart, Pie, Cell, ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Persona } from '../../types';
import { 
  TrendingUp, 
  ArrowUpRight, 
  Filter, 
  Download, 
  Share2, 
  Sparkles, 
  Shield, 
  PieChart as LucidePieChart,
  RefreshCcw,
  Upload,
  FileText,
  Mail,
  X,
  History,
  CheckCircle2
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { uploadCasFile } from '../../services/aiService';

const DATA = [
  { name: 'Equity', value: 65, color: '#4F46E5' },
  { name: 'Debt', value: 20, color: '#10B981' },
  { name: 'Gold', value: 10, color: '#F59E0B' },
  { name: 'Cash', value: 5, color: '#94A3B8' },
];

const PERFORMANCE_DATA = [
  { date: 'Jan', value: 68.2 },
  { date: 'Feb', value: 72.4 },
  { date: 'Mar', value: 70.1 },
  { date: 'Apr', value: 75.8 },
  { date: 'May', value: 79.2 },
  { date: 'Jun', value: 82.9 },
];

export default function PortfolioDashboard({ 
  persona, 
  riskProfile 
}: { 
  persona: Persona;
  riskProfile: string | null;
}) {
  const isBusiness = persona === Persona.MFD || persona === Persona.ADVISOR;
  const isTrader = persona === Persona.TRADER;
  const [isUpdating, setIsUpdating] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [availableEmails, setAvailableEmails] = useState<any[]>([]);
  const [selectedTokens, setSelectedTokens] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchCasList = async (tokens: any) => {
    try {
      const res = await fetch('/api/cas/gmail-list', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ access_token: tokens.access_token })
      });
      const data = await res.json();
      if (data.success) {
        setAvailableEmails(data.emails);
        setShowEmailModal(true);
      }
    } catch (error) {
      console.error('Failed to list CAS emails:', error);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleSelectEmail = async (messageId: string, attachmentId: string) => {
    try {
      setIsUpdating(true);
      setShowEmailModal(false);
      const res = await fetch('/api/cas/gmail-fetch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          access_token: selectedTokens.access_token,
          messageId,
          attachmentId
        })
      });
      const result = await res.json();
      if (result.success) {
        alert(`Successfully synchronized ${result.holdings.length} holdings from selected CAS!`);
      }
    } catch (error) {
      console.error('Failed to fetch selected CAS:', error);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleGmailSync = async () => {
    try {
      setIsUpdating(true);
      const res = await fetch('/api/auth/google/url');
      const { url } = await res.json();
      
      const width = 600;
      const height = 700;
      const left = window.screenX + (window.innerWidth - width) / 2;
      const top = window.screenY + (window.innerHeight - height) / 2;
      
      const authWindow = window.open(
        url,
        'google_auth',
        `width=${width},height=${height},left=${left},top=${top}`
      );

      if (!authWindow) {
        alert('Please allow popups to connect your Gmail account.');
        setIsUpdating(false);
        return;
      }

      const messageHandler = async (event: MessageEvent) => {
        if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
          const { tokens } = event.data;
          setSelectedTokens(tokens);
          fetchCasList(tokens);
          window.removeEventListener('message', messageHandler);
        }
      };

      window.addEventListener('message', messageHandler);
    } catch (error) {
      console.error('Gmail sync error:', error);
      setIsUpdating(false);
    }
  };

  const handleCasUpdate = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsUpdating(true);
      const result = await uploadCasFile(file);
      if (result && result.success) {
        // In a real app we would update the portfolio state here
        alert(`Successfully synchronized ${result.holdings.length} holdings from CAS!`);
      }
      setIsUpdating(false);
    }
  };

  // Ideal matrices based on user provided data
  const ALLOCATION_MATRIX: Record<string, any> = {
    'Conservative': { equity: 25, debt: 55, gold: 10, cash: 10 },
    'Moderately Conservative': { equity: 40, debt: 40, gold: 10, cash: 10 },
    'Moderate': { equity: 60, debt: 25, gold: 10, cash: 5 },
    'Aggressive': { equity: 80, debt: 10, gold: 5, cash: 5 },
    'Very Aggressive': { equity: 95, debt: 0, gold: 2, cash: 3 },
  };

  const target = riskProfile ? (ALLOCATION_MATRIX[riskProfile] || ALLOCATION_MATRIX['Moderate']) : ALLOCATION_MATRIX['Moderate'];

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Action Bar */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-white italic tracking-tighter">PORTFOLIO_ANALYTICS</h2>
          <p className="text-[10px] text-white/30 font-mono">Consolidated View • Updated Live</p>
        </div>
        <div className="flex items-center gap-3">
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept=".pdf" 
            onChange={handleCasUpdate} 
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={isUpdating}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-[10px] font-black text-indigo-400 uppercase tracking-widest hover:bg-indigo-500/20 transition-all"
          >
            {isUpdating ? <RefreshCcw className="w-3 h-3 animate-spin" /> : <Upload className="w-3 h-3" />}
            Refresh via PDF
          </button>
          <button 
            onClick={handleGmailSync}
            disabled={isUpdating}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-[10px] font-black text-emerald-400 uppercase tracking-widest hover:bg-emerald-500/20 transition-all"
          >
            {isUpdating ? <RefreshCcw className="w-3 h-3 animate-spin" /> : <Mail className="w-3 h-3" />}
            Sync via Gmail
          </button>
          <button className="p-2 bg-white/5 border border-white/10 rounded-xl text-white/40 hover:text-white transition-all">
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Portfolio Stats Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#1A1A1A] border border-white/5 rounded-3xl p-8 shadow-xl relative overflow-hidden group">
           <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-3xl -mr-16 -mt-16 group-hover:bg-indigo-500/10 transition-colors" />
           <p className="text-[10px] font-bold text-white/30 uppercase tracking-[0.3em] mb-3 font-mono">Consolidated Net Worth</p>
           <div className="flex items-baseline gap-3">
              <h1 className="text-4xl font-black text-white tracking-tight">
                 {isBusiness ? '₹42.84 Cr' : isTrader ? '+₹42,500' : '₹82.90 L'}
              </h1>
              <span className="text-sm font-bold text-emerald-400 flex items-center gap-1">
                 <ArrowUpRight className="w-3 h-3" /> 
                 {isBusiness ? '12.4%' : isTrader ? '2.4%' : '18.4%'}
              </span>
           </div>
        </div>

        <div className="bg-[#1A1A1A] border border-white/5 rounded-3xl p-8 shadow-xl relative overflow-hidden group">
           <p className="text-[10px] font-bold text-white/30 uppercase tracking-[0.3em] mb-3 font-mono">Portfolio CAGR</p>
           <div className="flex items-baseline gap-3">
              <h3 className="text-4xl font-black text-white tracking-tight">18.2%</h3>
              <span className="text-white/20 text-[10px] font-bold uppercase tracking-widest whitespace-nowrap">vs 15.4% Benchmark</span>
           </div>
        </div>

        <div className="bg-[#1A1A1A] border border-white/5 rounded-3xl p-8 shadow-xl relative overflow-hidden group">
           <p className="text-[10px] font-bold text-white/30 uppercase tracking-[0.3em] mb-3 font-mono">Risk Exposure</p>
           <div className="flex items-center gap-4">
              <h3 className="text-3xl font-black text-white uppercase tracking-tighter">{riskProfile || 'Aggressive'}</h3>
              <div className="flex gap-1.5">
                 {[1, 2, 3, 4, 5].map(i => (
                    <div key={i} className={cn("w-2 h-6 rounded-full transition-colors", i <= 4 ? "bg-amber-400 shadow-lg shadow-amber-400/20" : "bg-white/5")} />
                 ))}
              </div>
           </div>
        </div>
      </div>

      {/* Highlights Overlay Panel */}
      <section className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'Alpha Score', value: '+4.2', sub: 'vs Peers' },
          { label: 'Volatility', value: 'Low', sub: 'Market Cap Agnostic' },
          { label: 'Beta', value: '0.92', sub: 'Neutral Bias' },
          { label: 'Liquidity', value: 'High', sub: '92% 1-Day exit' }
        ].map((stat, i) => (
          <div key={i} className="bg-[#1A1A1A] border border-white/5 p-6 rounded-[2rem] hover:border-white/10 transition-all">
             <p className="text-[10px] font-bold text-white/30 uppercase tracking-widest mb-1">{stat.label}</p>
             <p className="text-2xl font-black text-white mb-1 leading-none">{stat.value}</p>
             <p className="text-[10px] text-white/20 font-bold uppercase tracking-tight">{stat.sub}</p>
          </div>
        ))}
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Asset Allocation */}
        <section className="lg:col-span-12 xl:col-span-5 bg-[#1A1A1A] border border-white/10 rounded-[2.5rem] p-8 flex flex-col shadow-2xl">
          <h3 className="text-xl font-bold text-white tracking-tight mb-8 flex items-center gap-2">
             <LucidePieChart className="w-5 h-5 text-indigo-400" /> Structural Allocation
          </h3>
          <div className="h-64 relative flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={DATA}
                  cx="50%"
                  cy="50%"
                  innerRadius={65}
                  outerRadius={85}
                  paddingAngle={5}
                  dataKey="value"
                  stroke="none"
                >
                  {DATA.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-3xl font-bold text-white">82%</span>
              <span className="text-[10px] text-white/40 font-bold uppercase tracking-widest mt-1">Equity Weight</span>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3 mt-10">
            {DATA.map((item) => (
              <div key={item.name} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 group hover:bg-white/10 transition-all cursor-pointer">
                <div className="flex items-center gap-4">
                  <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                  <div>
                    <div className="text-sm font-bold text-white">{item.name}</div>
                    <div className="text-[10px] font-bold text-white/20 uppercase tracking-tight">Target: {target[item.name.toLowerCase()]}%</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold text-white">{item.value}%</div>
                  <div className={cn(
                    "text-[10px] font-bold",
                    Math.abs(item.value - target[item.name.toLowerCase()]) > 5 ? "text-rose-500" : "text-emerald-500"
                  )}>
                    {item.value > target[item.name.toLowerCase()] ? '+' : ''}{item.value - target[item.name.toLowerCase()]}% Drift
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Performance Chart */}
        <section className="lg:col-span-12 xl:col-span-7 bg-[#1A1A1A] border border-white/5 rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl -mr-32 -mt-32" />
          <div className="flex items-center justify-between mb-10 relative z-10">
             <h3 className="text-xl font-bold text-white tracking-tight">Portfolio Alpha Dynamics</h3>
             <div className="flex gap-2">
                {['6M', '1Y', 'ALL'].map(t => (
                  <button key={t} className="px-3 py-1 bg-white/5 rounded-lg text-[10px] font-bold text-white/40 hover:text-white transition-all uppercase tracking-widest">
                    {t}
                  </button>
                ))}
             </div>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={PERFORMANCE_DATA}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ffffff08" />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#ffffff40', fontWeight: 600 }}
                  dy={10}
                />
                <YAxis hide domain={['dataMin - 5', 'dataMax + 5']} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#171717', 
                    borderRadius: '16px', 
                    border: '1px solid rgba(255,255,255,0.05)', 
                    boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
                    padding: '12px' 
                  }}
                  itemStyle={{ color: '#fff', fontSize: '12px', fontWeight: 'bold' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#6366f1" 
                  strokeWidth={4}
                  fillOpacity={1} 
                  fill="url(#colorValue)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          
          {/* Key Insights Bar */}
          <div className="mt-10 p-6 bg-indigo-500/5 rounded-3xl border border-indigo-500/10 border-dashed">
             <div className="flex items-center gap-4">
                <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-xl">
                   <Shield className="w-6 h-6" />
                </div>
                <div className="flex-1">
                   <h4 className="text-sm font-bold text-white mb-1">AI Protection Insight</h4>
                   <p className="text-xs text-white/40 leading-relaxed font-medium">Hedging active via Put options in Nifty 50. Protection active for 5.4% downturn.</p>
                </div>
             </div>
          </div>
        </section>
      </div>

      {/* Top Holdings Table */}
      <section className="bg-[#1A1A1A] border border-white/5 rounded-[2.5rem] overflow-hidden shadow-2xl">
        <div className="p-8 border-b border-white/5 flex items-center justify-between bg-white/[0.01]">
          <div>
            <h3 className="text-xl font-bold text-white tracking-tight">Key Portfolio Holdings</h3>
            <p className="text-xs text-white/30 font-medium">Top concentration by weightage</p>
          </div>
          <button className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 transition-all uppercase tracking-widest bg-indigo-500/10 px-4 py-2 rounded-xl border border-indigo-500/20">View Detail Report</button>
        </div>
        <div className="overflow-x-auto px-4 pb-4">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-transparent">
                <th className="px-6 py-4 text-[10px] font-bold text-white/30 uppercase tracking-[0.2em]">Holding Name</th>
                <th className="px-6 py-4 text-[10px] font-bold text-white/30 uppercase tracking-[0.2em]">Live Weight</th>
                <th className="px-6 py-4 text-[10px] font-bold text-white/30 uppercase tracking-[0.2em]">Avg Cost</th>
                <th className="px-6 py-4 text-[10px] font-bold text-white/30 uppercase tracking-[0.2em]">Total Returns</th>
                <th className="px-6 py-4 text-[10px] font-bold text-white/30 uppercase tracking-[0.2em]">AI Signal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.03]">
              {[
                { name: 'HDFC Bank', weight: '12.4%', cost: '1,642', returns: '+14.2%', insight: 'Core Asset', trend: 'stable' },
                { name: 'Reliance Ind.', weight: '9.8%', cost: '2,845', returns: '+22.1%', insight: 'Overweight', trend: 'hold' },
                { name: 'Infosys Ltd.', weight: '7.2%', cost: '1,510', returns: '-4.3%', insight: 'Sell Signal', trend: 'weak' },
              ].map((holding) => (
                <tr key={holding.name} className="group hover:bg-white/[0.02] transition-colors">
                  <td className="px-6 py-6">
                    <div className="font-bold text-white text-base">{holding.name}</div>
                  </td>
                  <td className="px-6 py-6 text-sm font-bold text-white/60">{holding.weight}</td>
                  <td className="px-6 py-6 text-sm font-bold text-white/60">₹{holding.cost}</td>
                  <td className={cn("px-6 py-6 text-base font-bold", holding.returns.startsWith('+') ? 'text-emerald-400' : 'text-rose-500')}>
                    {holding.returns}
                  </td>
                  <td className="px-6 py-6">
                    <span className={cn(
                      "text-[10px] px-3 py-1.5 rounded-lg font-bold uppercase tracking-widest border",
                      holding.insight === 'Core Asset' ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' :
                      holding.insight === 'Overweight' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' :
                      'bg-rose-500/10 text-rose-500 border-rose-500/20'
                    )}>
                      {holding.insight}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Gmail CAS Selection Modal */}
      <AnimatePresence>
        {showEmailModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowEmailModal(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-xl bg-[#111111] border border-white/10 rounded-[2.5rem] shadow-2xl flex flex-col overflow-hidden max-h-[80vh]"
            >
              <div className="p-8 border-b border-white/5 flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-white tracking-tight">Select CAS Statement</h3>
                  <p className="text-[10px] text-white/30 font-bold uppercase tracking-widest mt-1">Found {availableEmails.length} matching emails</p>
                </div>
                <button 
                  onClick={() => setShowEmailModal(false)}
                  className="p-2 hover:bg-white/5 rounded-xl transition-colors text-white/40"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
                {availableEmails.length === 0 ? (
                  <div className="p-12 text-center">
                    <History className="w-12 h-12 text-white/10 mx-auto mb-4" />
                    <p className="text-white/40 font-medium">No CAS statements found in your Gmail account.</p>
                    <p className="text-[10px] text-white/20 uppercase tracking-widest mt-2">Try uploading the PDF manually</p>
                  </div>
                ) : (
                  availableEmails.map((email) => (
                    <div key={email.id} className="bg-white/[0.02] border border-white/5 rounded-2xl p-6 hover:bg-white/[0.04] transition-all group">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-xl">
                            <Mail className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-sm font-bold text-white group-hover:text-indigo-400 transition-colors line-clamp-1">{email.subject}</div>
                            <div className="text-[10px] text-white/30 font-medium mt-0.5">{email.date}</div>
                          </div>
                        </div>
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                      
                      <div className="space-y-2">
                        {email.attachments.map((att: any) => (
                          <button
                            key={att.id}
                            onClick={() => handleSelectEmail(email.id, att.id)}
                            className="w-full flex items-center justify-between px-4 py-3 bg-white/5 border border-white/5 rounded-xl text-[10px] font-bold text-white/60 hover:text-white hover:bg-white/10 hover:border-white/20 transition-all uppercase tracking-widest"
                          >
                            <span className="flex items-center gap-2">
                              <FileText className="w-3 h-3 text-indigo-400" />
                              {att.filename}
                            </span>
                            <span className="text-indigo-400">Select & Parse</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  ))
                )}
              </div>
              
              <div className="p-6 bg-white/[0.01] border-t border-white/5 text-center">
                <p className="text-[10px] text-white/20 font-medium italic">
                  Note: Nivesh Alpha AI only accesses these specific CAS emails to securely update your portfolio.
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
