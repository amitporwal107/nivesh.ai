/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { 
  Briefcase, 
  TrendingUp, 
  Globe, 
  ShieldCheck, 
  Zap, 
  ArrowRight 
} from 'lucide-react';
import { Persona } from '../types';
import { cn } from '../lib/utils';

export default function PersonaSelection({ onSelect }: { onSelect: (persona: Persona) => void }) {
  const personas = [
    {
      type: Persona.RETAIL_INVESTOR,
      title: 'Retail Investor',
      description: 'Long-term wealth building with AI-guided portfolio rebalancing.',
      icon: Briefcase,
      color: 'bg-emerald-50 text-emerald-600',
      accent: 'border-emerald-100',
      tag: 'Most Popular'
    },
    {
      type: Persona.TRADER,
      title: 'Pro Trader',
      description: 'High-frequency signals, market regime tracking, and technical setups.',
      icon: TrendingUp,
      color: 'bg-amber-50 text-amber-600',
      accent: 'border-amber-100',
      tag: 'Active'
    },
    {
      type: Persona.MFD,
      title: 'Distributor',
      description: 'Client portfolio tracking, goal suitability, and aum management.',
      icon: Globe,
      color: 'bg-indigo-50 text-indigo-600',
      accent: 'border-indigo-100'
    },
    {
      type: Persona.ADVISOR,
      title: 'Financial Advisor',
      description: 'Multi-client dashboard with institutional-grade risk analytics.',
      icon: ShieldCheck,
      color: 'bg-slate-50 text-slate-600',
      accent: 'border-slate-200'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 py-20 animate-in fade-in duration-1000">
      <div className="max-w-4xl w-full">
        <header className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 border border-indigo-100 rounded-full text-indigo-600 text-[10px] font-bold uppercase tracking-widest mb-6">
            <Zap className="w-3 h-3 fill-indigo-600" /> Intelligence Engine Ready
          </div>
          <h2 className="text-4xl font-bold text-slate-900 tracking-tight mb-3">Choose your workspace</h2>
          <p className="text-slate-500 font-medium max-w-md mx-auto">Select the persona that best matches your financial objectives and operational workflow.</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {personas.map((p) => (
            <motion.button
              key={p.type}
              whileHover={{ y: -4, scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onSelect(p.type)}
              className={cn(
                "dashboard-card p-6 flex flex-col text-left group transition-all",
                "hover:border-indigo-400 hover:shadow-indigo-100 focus:outline-none"
              )}
            >
              <div className="flex justify-between items-start mb-6">
                <div className={cn("p-3 rounded-2xl", p.color)}>
                  <p.icon className="w-6 h-6" />
                </div>
                {p.tag && (
                  <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-slate-400 border border-slate-200 px-2.5 py-1 rounded-full group-hover:bg-indigo-50 group-hover:text-indigo-600 group-hover:border-indigo-100 transition-colors">
                    {p.tag}
                  </span>
                )}
              </div>
              
              <h3 className="text-xl font-bold text-slate-800 tracking-tight mb-2">{p.title}</h3>
              <p className="text-sm font-medium text-slate-500 leading-relaxed mb-8 flex-1">
                {p.description}
              </p>
              
              <div className="flex items-center text-xs font-bold text-indigo-600 uppercase tracking-widest">
                Start Session
                <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
              </div>
            </motion.button>
          ))}
        </div>

        <p className="mt-12 text-center text-xs font-bold text-slate-400 uppercase tracking-[0.2em] italic">
          Powering over ₹5,000 Cr in managed assets globally
        </p>
      </div>
    </div>
  );
}
