/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from 'motion/react';
import React from 'react';
import { 
  Plus, 
  LayoutDashboard, 
  MessageSquare, 
  Briefcase, 
  BarChart3, 
  Target, 
  Users, 
  User, 
  Settings,
  Zap,
  ChevronLeft,
  ChevronRight,
  Info,
  Sparkles,
  History,
  Grid,
  Bell,
  ArrowRight,
  Terminal
} from 'lucide-react';
import { cn } from '../lib/utils';
import { Persona, Screen } from '../types';
import { PERSONA_SUGGESTIONS } from '../constants';

interface AILayoutProps {
  children: React.ReactNode;
  activeScreen: Screen;
  setScreen: (screen: Screen) => void;
  persona: Persona | null;
  onOpenSwitcher: () => void;
  onAISubmit?: (text: string) => void;
}

export default function AILayout({ 
  children, 
  activeScreen, 
  setScreen, 
  persona,
  onOpenSwitcher,
  onAISubmit
}: AILayoutProps) {
  const [globalInput, setGlobalInput] = React.useState('');
  
  const handleGlobalSubmit = () => {
    if (!globalInput.trim()) return;
    onAISubmit?.(globalInput);
    setGlobalInput('');
  };
  
  const getNavItems = () => {
    switch (persona) {
      case Persona.TRADER:
        return [
          { id: 'home' as Screen, label: 'Trade Terminal', icon: Zap },
          { id: 'markets' as Screen, label: 'Alpha Signals', icon: BarChart3 },
          { id: 'portfolio' as Screen, label: 'Live Portfolio', icon: Briefcase },
          { id: 'copilot' as Screen, label: 'Strategy Chat', icon: MessageSquare },
        ];
      case Persona.MFD:
      case Persona.ADVISOR:
      case Persona.PORTFOLIO_MANAGER:
        return [
          { id: 'home' as Screen, label: 'Advisor Home', icon: LayoutDashboard },
          { id: 'portfolio' as Screen, label: 'Client Book', icon: Briefcase },
          { id: 'admin' as Screen, label: 'System Control', icon: Terminal },
          { id: 'goals' as Screen, label: 'Client Goals', icon: Target },
          { id: 'markets' as Screen, label: 'Product Lab', icon: BarChart3 },
          { id: 'copilot' as Screen, label: 'Advisory Chat', icon: MessageSquare },
        ];
      default:
        return [
          { id: 'home' as Screen, label: 'Dashboard', icon: LayoutDashboard },
          { id: 'portfolio' as Screen, label: 'My Wealth', icon: Briefcase },
          { id: 'markets' as Screen, label: 'Market Hub', icon: BarChart3 },
          { id: 'family' as Screen, label: 'Family Hub', icon: Users },
          { id: 'copilot' as Screen, label: 'Wealth Chat', icon: MessageSquare },
        ];
    }
  };

  const navItems = getNavItems();

  return (
    <div className="flex h-screen bg-[#212121] text-[#ECECF1] overflow-hidden font-sans">
      {/* ChatGPT Style Sidebar */}
      <aside className="w-[260px] bg-[#171717] flex flex-col shrink-0">
        <div className="p-3">
          <button 
            onClick={() => setScreen('copilot')}
            className="w-full h-11 flex items-center gap-3 px-3 rounded-lg border border-white/20 hover:bg-white/5 transition-colors group mb-6"
          >
            <div className="p-1 bg-white/10 rounded-md">
                <Plus className="w-4 h-4 text-white" />
            </div>
            <span className="text-sm font-medium">New Insight</span>
            <div className="ml-auto hidden group-hover:block border border-white/20 px-1 py-0.5 rounded text-[10px] text-white/50">
               ⌘N
            </div>
          </button>

          <div className="space-y-4">
             <div>
                <p className="px-3 text-[10px] font-bold text-white/40 uppercase tracking-widest mb-2">Workspaces</p>
                <div className="space-y-0.5">
                   {navItems.map(item => (
                     <button
                        key={item.id}
                        onClick={() => setScreen(item.id)}
                        className={cn(
                          "w-full h-10 flex items-center gap-3 px-3 rounded-lg text-sm font-medium transition-colors relative transition-all",
                          activeScreen === item.id 
                            ? "bg-[#212121] text-white" 
                            : "text-[#ECECF1]/70 hover:bg-[#212121]"
                        )}
                     >
                        <item.icon className={cn("w-4 h-4", activeScreen === item.id ? "text-indigo-400" : "text-white/40")} />
                        <span>{item.label}</span>
                        {activeScreen === item.id && (
                          <motion.div layoutId="active-pill" className="absolute right-2 w-1 h-4 bg-indigo-500 rounded-full" />
                        )}
                     </button>
                   ))}
                </div>
             </div>

             <div>
                <p className="px-3 text-[10px] font-bold text-white/40 uppercase tracking-widest mb-2">Recent Queries</p>
                <div className="space-y-0.5 opacity-60">
                   {[
                     "Compare HDFC vs ICICI",
                     "Portfolio drift analysis",
                     "Tax loss harvesting op...",
                     "Nifty 50 signals"
                   ].map(chat => (
                     <button key={chat} className="w-full h-9 flex items-center gap-3 px-3 rounded-lg text-[13px] text-white/70 hover:bg-[#212121] truncate transition-colors">
                        <History className="w-4 h-4 text-white/20 shrink-0" />
                        <span className="truncate">{chat}</span>
                     </button>
                   ))}
                </div>
             </div>
          </div>
        </div>

        <div className="mt-auto p-3 bg-[#171717] border-t border-white/5">
           <button 
             onClick={onOpenSwitcher}
             className="w-full p-3 rounded-xl hover:bg-white/5 flex items-center gap-3 transition-colors mb-2"
           >
              <div className="w-8 h-8 rounded-lg bg-indigo-600/20 flex items-center justify-center font-bold text-indigo-400 border border-indigo-500/20">
                {persona?.[0]}
              </div>
              <div className="text-left">
                 <p className="text-xs font-bold text-white">{persona === Persona.MFD ? 'MFD Console' : 'Advisor Lab'}</p>
                 <p className="text-[10px] text-white/40 font-bold uppercase tracking-tight">Switch Persona</p>
              </div>
              <ChevronRight className="w-4 h-4 text-white/20 ml-auto" />
           </button>
           
           <div className="flex items-center justify-between px-2 pt-2">
              <button className="p-2 hover:bg-white/5 rounded-lg text-white/40 hover:text-white transition-all">
                <Settings className="w-4 h-4" />
              </button>
              <button className="p-2 hover:bg-white/5 rounded-lg text-white/40 hover:text-white transition-all">
                <User className="w-4 h-4" />
              </button>
              <div className="flex items-center gap-2 px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-md">
                 <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                 <span className="text-[9px] font-bold text-emerald-500 uppercase tracking-widest">Live</span>
              </div>
           </div>
        </div>
      </aside>

      {/* Main Workspace */}
      <main className="flex-1 bg-[#0f0f0f] flex flex-col h-screen overflow-hidden relative">
        {/* Minimal Header */}
        <header className="h-16 flex items-center justify-between px-8 bg-[#0f0f0f]/80 backdrop-blur-xl border-b border-white/5 shrink-0 z-50">
           <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-3 py-1 bg-white/5 rounded-full border border-white/10">
                 <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                 <span className="text-[10px] font-bold uppercase tracking-wider text-white/40 leading-none">System Live</span>
              </div>
              <div className="h-4 w-[1px] bg-white/10 mx-2" />
              <h2 className="text-sm font-bold text-white tracking-tight">
                {activeScreen.toUpperCase()}
              </h2>
           </div>
           
           <div className="flex items-center gap-4">
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-lg">
                 <Sparkles className="w-3 h-3 text-indigo-400" />
                 <span className="text-[10px] font-black uppercase tracking-tighter text-indigo-300">Neural Alpha</span>
              </div>
              
              <div className="flex items-center gap-3">
                 <button className="text-white/40 hover:text-white transition-colors relative p-2">
                    <Bell className="w-4 h-4" />
                    <span className="absolute top-2 right-2 w-1.5 h-1.5 bg-rose-500 rounded-full border border-[#0f0f0f]" />
                 </button>
                 <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-[10px] font-bold border border-white/10 shadow-lg">
                    AP
                 </div>
              </div>
           </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto custom-scrollbar relative">
           <div className={cn(
             "mx-auto p-6 md:p-10",
             activeScreen === 'copilot' ? "max-w-4xl" : "max-w-6xl"
           )}>
              {children}
           </div>
           {/* Buffer for floating input */}
           <div className="h-40" />
        </div>

        {/* ChatGPT Style Floating Input */}
        <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-[#0f0f0f] via-[#0f0f0f] to-transparent z-40">
           <div className="max-w-3xl mx-auto">
              <div className="relative group">
                 <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500/20 to-purple-600/20 rounded-[2rem] blur-xl opacity-0 group-focus-within:opacity-100 transition-opacity duration-700" />
                 <div className="relative bg-[#1A1A1A] border border-white/10 rounded-[1.8rem] shadow-2xl p-2 pr-14 focus-within:border-white/20 transition-all ring-1 ring-white/5">
                    <input 
                      type="text" 
                      value={globalInput}
                      onChange={(e) => setGlobalInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleGlobalSubmit()}
                      placeholder="Ask Nivesh Copilot to analyze, trade or rebalance..."
                      className="w-full bg-transparent px-6 py-4 text-[15px] text-white font-medium outline-none placeholder:text-white/20"
                    />
                    <button 
                      onClick={handleGlobalSubmit}
                      disabled={!globalInput.trim()}
                      className={cn(
                        "absolute right-2.5 top-1/2 -translate-y-1/2 w-11 h-11 rounded-[1.2rem] flex items-center justify-center transition-all shadow-xl active:scale-95 group-hover:scale-105",
                        globalInput.trim() ? "bg-indigo-600 text-white" : "bg-white/5 text-white/20"
                      )}
                    >
                       <ArrowRight className="w-5 h-5" />
                    </button>
                 </div>
              </div>
              <div className="mt-4 flex items-center justify-center gap-4 flex-wrap">
                 {(persona ? PERSONA_SUGGESTIONS[persona] : ['Market Trends', 'Portfolio Risk', 'Yield Analysis']).slice(0, 3).map((action) => (
                    <button 
                      key={action}
                      onClick={() => setGlobalInput(action)}
                      className="text-[9px] font-bold text-white/30 uppercase tracking-widest hover:text-indigo-400 hover:bg-white/5 px-3 py-1.5 rounded-lg border border-transparent hover:border-white/5 transition-all"
                    >
                       {action}
                    </button>
                 ))}
                 <div className="w-1 h-1 bg-white/10 rounded-full" />
                 <p className="text-[10px] font-bold text-white/10 uppercase tracking-[0.2em]">{persona ? `${persona.toUpperCase()} MODE` : 'Nivesh Pro Alpha'}</p>
              </div>
           </div>
        </div>
      </main>
    </div>
  );
}
