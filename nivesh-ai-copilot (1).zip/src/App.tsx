/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import SplashScreen from './components/SplashScreen';
import LoginScreen from './components/LoginScreen';
import PersonaSelection from './components/PersonaSelection';
import { TopBar, BottomNav, Sidebar, MarketTicker } from './components/Navigation';
import { Persona, Screen, ChatMessage } from './types';

// Screen Imports
import HomeDashboard from './components/screens/HomeDashboard';
import AdvisorDashboard from './components/screens/AdvisorDashboard';
import CopilotChat from './components/screens/CopilotChat';
import PortfolioDashboard from './components/screens/PortfolioDashboard';
import MarketDashboard from './components/screens/MarketDashboard';
import ProfileScreen from './components/screens/ProfileScreen';
import OnboardingScreen from './components/screens/OnboardingScreen';
import RiskProfileScreen from './components/screens/RiskProfileScreen';
import GoalSettingScreen from './components/screens/GoalSettingScreen';
import FamilyDashboard from './components/screens/FamilyDashboard';
import AdminConsole from './components/screens/AdminConsole';

import NativeLayout from './components/NativeLayout';

export default function App() {
  const [screen, setScreen] = useState<Screen>('splash');
  const [persona, setPersona] = useState<Persona | null>(null);
  const [userData, setUserData] = useState<{ name: string; mobile?: string } | null>(null);
  const [riskProfile, setRiskProfile] = useState<string | null>(null);

  const handleSplashComplete = () => {
    setScreen('login');
  };

  const handleLoginComplete = (data: any) => {
    console.log('User Logined:', data);
    setUserData(data);
    setScreen('persona-selection');
  };

  const handlePersonaSelect = (selectedPersona: Persona) => {
    setPersona(selectedPersona);
    setScreen('onboarding');
  };

  const handleRiskProfileComplete = (profile: string) => {
    console.log('Risk Profile Selected:', profile);
    setRiskProfile(profile);
    setScreen('home');
  };

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hello Amit. I've analyzed your client book for this morning. You have 2 high-priority rebalancing opportunities and 4 quarterly reviews pending. Would you like me to generate the priority outreach list?",
      timestamp: new Date(),
      type: 'summary'
    }
  ]);

  const handleGlobalAISubmit = (text: string) => {
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMsg]);
    setScreen('copilot');

    // Simulate AI Response
    setTimeout(() => {
      let aiContent = "I've analyzed your request. I recommend reviewing the latest sectoral rotation data which shows a shift towards Defensive assets.";
      
      if (text.toLowerCase().includes('portfolio')) {
        aiContent = "Opening your Portfolio Performance Dashboard. Your current CAGR is outperforming the benchmark by 2.4%.";
      } else if (text.toLowerCase().includes('trader') || text.toLowerCase().includes('markets')) {
        aiContent = "Analyzing live alpha signals. I've detected a bullish breakout pattern in the Nifty 50 IT index.";
      }

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: aiContent,
        timestamp: new Date(),
        type: 'recommendation'
      };
      setMessages(prev => [...prev, aiMsg]);
    }, 1000);
  };

  const renderScreen = () => {
    switch (screen) {
      case 'home':
        return persona === Persona.ADVISOR || persona === Persona.MFD 
          ? <AdvisorDashboard persona={persona!} setScreen={setScreen} /> 
          : <HomeDashboard persona={persona!} setScreen={setScreen} />;
      case 'copilot':
        return <CopilotChat persona={persona!} messages={messages} setMessages={setMessages} />;
      case 'portfolio':
        return <PortfolioDashboard persona={persona!} riskProfile={riskProfile} />;
      case 'markets':
        return <MarketDashboard persona={persona!} />;
      case 'admin':
        return <AdminConsole />;
      case 'profile':
        return <ProfileScreen 
          persona={persona!} 
          userData={userData} 
          riskProfile={riskProfile} 
          onUpdateUser={(data) => setUserData(data)}
        />;
      case 'goals':
        return <GoalSettingScreen persona={persona!} />;
      case 'family':
        return <FamilyDashboard persona={persona!} />;
      default:
        return null;
    }
  };


  return (
    <div className="min-h-screen bg-[#212121] flex flex-col font-sans text-white overflow-hidden">
      <AnimatePresence mode="wait">
        {screen === 'splash' && (
          <motion.div key="splash" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <SplashScreen onComplete={handleSplashComplete} />
          </motion.div>
        )}

        {screen === 'login' && (
          <motion.div key="login" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <LoginScreen onComplete={handleLoginComplete} />
          </motion.div>
        )}

        {screen === 'persona-selection' && (
          <motion.div key="persona" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <PersonaSelection onSelect={handlePersonaSelect} />
          </motion.div>
        )}

        {screen === 'onboarding' && (
          <motion.div key="onboarding" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <OnboardingScreen 
              persona={persona!} 
              onComplete={() => setScreen('risk-profile')} 
            />
          </motion.div>
        )}

        {screen === 'risk-profile' && (
          <motion.div key="risk" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <RiskProfileScreen 
              persona={persona!} 
              onComplete={handleRiskProfileComplete} 
            />
          </motion.div>
        )}


        {['home', 'copilot', 'portfolio', 'markets', 'profile', 'goals', 'family', 'admin'].includes(screen) && (
          <motion.div
            key="app-shell"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex-1 flex flex-col h-screen overflow-hidden"
          >
            <NativeLayout 
               activeScreen={screen as Screen} 
               setScreen={setScreen} 
               persona={persona}
               onOpenSwitcher={() => setScreen('persona-selection')}
               onAISubmit={handleGlobalAISubmit}
            >
              <AnimatePresence mode="wait">
                <motion.div
                  key={screen}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3, ease: 'easeOut' }}
                  className="w-full h-full"
                >
                  {renderScreen()}
                </motion.div>
              </AnimatePresence>
            </NativeLayout>
            <MarketTicker />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

