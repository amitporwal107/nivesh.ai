/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum Persona {
  NEW_INVESTOR = 'New Investor',
  RETAIL_INVESTOR = 'Retail Investor',
  TRADER = 'Trader',
  MF_INVESTOR = 'Mutual Fund Investor',
  MFD = 'Mutual Fund Advisor / MFD',
  ADVISOR = 'Financial Advisor',
  PORTFOLIO_ANALYST = 'Portfolio Analyst',
  PORTFOLIO_MANAGER = 'Portfolio Manager',
  RISK_ANALYST = 'Risk Analyst',
  MARKET_ANALYST = 'Market Analyst',
  RESEARCH_ANALYST = 'Research Analyst',
  WEALTH_MANAGER = 'Wealth Manager',
}

export type Screen = 'home' | 'copilot' | 'portfolio' | 'markets' | 'profile' | 'onboarding' | 'persona-selection' | 'splash' | 'login' | 'risk-profile' | 'goals' | 'family' | 'admin';

export interface PortfolioData {
  value: number;
  change: number;
  changePercent: number;
  healthScore: number;
  diversificationScore: number;
  riskAlignmentScore: number;
  taxEfficiencyScore: number;
  allocations: { name: string; value: number; color: string }[];
}

export interface MarketData {
  symbol: string;
  price: string;
  change: string;
  changePercent: number;
  isUp: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  type?: 'summary' | 'metrics' | 'recommendation' | 'text' | 'template';
  payload?: any;
}
