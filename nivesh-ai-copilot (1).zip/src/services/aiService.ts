/**
 * Frontend service to communicate with the Nivesh AI Backend
 */

export interface MarketIntelligence {
  regime: string;
  bias: string;
  riskScore: number;
  vix: number;
  topTrades: Array<{
    ticker: string;
    status: string;
    entry: number;
    target: number;
    sl: number;
  }>;
  sectors: {
    strong: string[];
    weak: string[];
  };
}

export const fetchMarketIntelligence = async (): Promise<MarketIntelligence> => {
  try {
    const response = await fetch('/api/market-intelligence');
    if (!response.ok) throw new Error('Failed to fetch market intelligence');
    return await response.json();
  } catch (error) {
    console.error('Error fetching market intelligence:', error);
    // Return fallback data matching the README spec
    return {
      regime: "TRANSITION",
      bias: "Neutral",
      riskScore: 0.5,
      vix: 15.5,
      topTrades: [],
      sectors: { strong: [], weak: [] }
    };
  }
};

export const getPortfolioScore = async (holdings: any[]) => {
  try {
    const response = await fetch('/api/score/portfolio', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ holdings })
    });
    return await response.json();
  } catch (error) {
    console.error('Error calculating portfolio score:', error);
    return null;
  }
};

export const getAdminStats = async () => {
  try {
    const response = await fetch('/api/admin/stats');
    return await response.json();
  } catch (error) {
    console.error('Error fetching admin stats:', error);
    return null;
  }
};

export const triggerScrape = async (source: string) => {
  try {
    const response = await fetch('/api/admin/trigger-scrape', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ source })
    });
    return await response.json();
  } catch (error) {
    console.error('Error triggering scrape:', error);
    return null;
  }
};

export const uploadCasFile = async (file: File) => {
  const formData = new FormData();
  formData.append('file', file);
  try {
    const response = await fetch('/api/cas/upload', {
      method: 'POST',
      body: formData
    });
    return await response.json();
  } catch (error) {
    console.error('Error uploading CAS:', error);
    return null;
  }
};

export const syncGmailCas = async (accessToken: string) => {
  try {
    const response = await fetch('/api/cas/gmail-sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ access_token: accessToken })
    });
    return await response.json();
  } catch (error) {
    console.error('Error syncing Gmail CAS:', error);
    return null;
  }
};

export const verifyGoogleToken = async (idToken: string) => {
  try {
    const response = await fetch('/api/auth/google/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ idToken })
    });
    return await response.json();
  } catch (error) {
    console.error('Error verifying Google token:', error);
    return null;
  }
};
